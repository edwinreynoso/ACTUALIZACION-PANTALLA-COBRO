// Cobro rapido: resumen, filtros, busqueda, tarjetas de cuentas y el panel donde se cobra (el cobro de siempre, /cobro/ticket).
(function () {
    'use strict';
    const raiz = document.getElementById('rp');
    if (!raiz) return;
    const $ = id => document.getElementById(id);

    const caja = raiz.dataset.caja || '';
    const urlLista = raiz.dataset.url + '?handler=Lista' + (caja ? '&pos_id=' + encodeURIComponent(caja) : '');
    let tickets = [];
    let clientes = [];                      // clientes asignados a las cuentas (ticketId global -> cliente)
    let area = 'Todas', caja_f = 'Todas', usuario = 'Todos', estado = 'Todas', orden = 'precuenta', busca = '', abierto = null, ocupadoHasta = 0, ultima = Date.now(), fallo = false;

    try { tickets = JSON.parse(raiz.dataset.inicial || '[]'); } catch { tickets = []; }
    try { clientes = JSON.parse(raiz.dataset.clientes || '[]'); } catch { clientes = []; }
    const clienteDe = t => clientes.find(c => String(c.ticketId).toLowerCase() === String(t.globalId).toLowerCase());

    // Aviso cuando una cuenta pasa a "precuenta pedida": sonido (se puede apagar; el navegador lo recuerda), mensaje y la tarjeta parpadea unos segundos.
    let sonido = true, ctxAudio = null, primeraCarga = true;
    try { sonido = localStorage.getItem('rp-sonido') !== '0'; } catch { /* sin almacenamiento: queda encendido */ }
    const precuentasVistas = new Set(), nuevas = new Map();

    const esc = t => String(t ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const plano = t => String(t ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
    const moneda = n => '$' + Number(n || 0).toLocaleString('es-DO', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    const dur = m => m >= 1440 ? Math.floor(m / 1440) + ' d ' + Math.floor((m % 1440) / 60) + ' h' : m >= 60 ? Math.floor(m / 60) + ' h ' + ('0' + (m % 60)).slice(-2) + ' min' : m + ' min';
    const iniciales = n => (String(n || '?').trim().split(/\s+/).map(p => p[0]).join('').slice(0, 2) || '?').toUpperCase();
    const colorArea = nombre => { let h = 0; for (const c of String(nombre)) h = (h * 31 + c.charCodeAt(0)) % 5; return 'a' + h; };

    const ICO_RELOJ = '<svg viewBox="0 0 24 24" width="15" height="15" aria-hidden="true"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2"/><path d="M12 7v5l3 2" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
    const ICO_IMPRESORA = '<svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path d="M7 9V3h10v6M7 14H5a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-2M7 14h10v7H7z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>';
    const ICO_FLECHA = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    const ICO_VACIO = '<svg viewBox="0 0 24 24" width="56" height="56" aria-hidden="true"><path d="M19.5 3.5 18 2l-1.5 1.5L15 2l-1.5 1.5L12 2l-1.5 1.5L9 2 7.5 3.5 6 2 4.5 3.5 3 2v20l1.5-1.5L6 22l1.5-1.5L9 22l1.5-1.5L12 22l1.5-1.5L15 22l1.5-1.5L18 22l1.5-1.5L21 22V2zM8 8h8M8 12h8M8 16h5" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';

    function resalta(texto) {
        const t = String(texto ?? '');
        if (!busca) return esc(t);
        const i = plano(t).indexOf(plano(busca));
        if (i < 0) return esc(t);
        return esc(t.slice(0, i)) + '<mark>' + esc(t.slice(i, i + busca.length)) + '</mark>' + esc(t.slice(i + busca.length));
    }

    function coincide(t, ignorar) {
        if (ignorar !== 'area' && area !== 'Todas' && t.centroVenta !== area) return false;
        if (ignorar !== 'caja' && caja_f !== 'Todas' && t.caja !== caja_f) return false;
        if (ignorar !== 'usuario' && usuario === 'Mis') { if (!t.miCuenta) return false; }
        else if (ignorar !== 'usuario' && usuario !== 'Todos' && t.usuario !== usuario) return false;
        if (ignorar !== 'estado' && estado === 'Precuenta' && !t.precuenta) return false;
        if (!busca) return true;
        return plano([t.mesa, '#' + t.ticketId, t.ticketId, t.etiqueta, t.usuario, t.centroVenta].join(' ')).includes(plano(busca));
    }

    function visibles() {
        const v = tickets.filter(t => coincide(t));
        v.sort((a, b) => {
            if (orden === 'monto') return b.total - a.total;
            if (orden === 'precuenta' && a.precuenta !== b.precuenta) return a.precuenta ? -1 : 1;
            return b.minutos - a.minutos;
        });
        return v;
    }

    // Resumen: lo que hay ahora, lo que falta por cobrar y quienes estan por pagar (esta ultima tambien filtra).
    function kpis() {
        const v = tickets.filter(t => coincide(t, 'estado'));
        const suma = v.reduce((s, t) => s + t.total, 0);
        const pre = v.filter(t => t.precuenta);
        const sumaPre = pre.reduce((s, t) => s + t.total, 0);
        $('rp-kpis').innerHTML =
            `<div class="rp-kpi"><small>Cuentas abiertas</small><b class="num">${v.length}</b><span>${area === 'Todas' ? 'en todas las áreas' : 'en ' + esc(area)}</span></div>` +
            `<div class="rp-kpi"><small>Por cobrar</small><b class="num">${moneda(suma)}</b><span>total de las cuentas que ve</span></div>` +
            `<button type="button" class="rp-kpi pre${estado === 'Precuenta' ? ' on' : ''}${pre.length ? '' : ' cero'}" data-e="${estado === 'Precuenta' ? 'Todas' : 'Precuenta'}" aria-pressed="${estado === 'Precuenta'}">` +
            `<small>Por pagar · precuenta pedida</small><b class="num">${pre.length}</b><span>${pre.length ? moneda(sumaPre) + ' · toque para ' + (estado === 'Precuenta' ? 'ver todas' : 'verlas solas') : 'ninguna por ahora'}</span></button>`;
    }

    function tabs() {
        const base = tickets.filter(t => coincide(t, 'area'));
        const areas = [...new Set(tickets.map(t => t.centroVenta))].filter(Boolean).sort();
        const item = (valor, texto) => `<button type="button" role="tab" class="rp-tab${valor === area ? ' on' : ''}" data-a="${esc(valor)}" aria-selected="${valor === area}">${esc(texto)}<small>${valor === 'Todas' ? base.length : base.filter(t => t.centroVenta === valor).length}</small></button>`;
        $('rp-f-areas').innerHTML = item('Todas', 'Todas las áreas') + areas.map(a => item(a, a)).join('');
    }

    function cajas() {
        const nombres = [...new Set(tickets.map(t => t.caja))].filter(Boolean).sort();
        const caja = $('rp-f-cajas');
        caja.hidden = nombres.length < 2;                                   // con una sola caja no hay nada que elegir
        if (nombres.length < 2) { caja_f = 'Todas'; return; }
        const base = tickets.filter(t => coincide(t, 'caja'));
        caja.innerHTML = '<span class="rp-u-rot">Caja</span>' +
            `<button type="button" class="rp-chip todos${caja_f === 'Todas' ? ' on' : ''}" data-c="Todas">Todas<small>${base.length}</small></button>` +
            nombres.map(n => `<button type="button" class="rp-chip todos${caja_f === n ? ' on' : ''}" data-c="${esc(n)}">${esc(n)}<small>${base.filter(t => t.caja === n).length}</small></button>`).join('');
    }

    function usuarios() {
        const base = tickets.filter(t => coincide(t, 'usuario'));
        const users = [...new Set(tickets.map(t => t.usuario))].filter(Boolean).sort();
        const mias = base.filter(t => t.miCuenta).length;
        $('rp-f-users').innerHTML = '<span class="rp-u-rot">Usuario</span>' +
            `<button type="button" class="rp-chip todos${usuario === 'Todos' ? ' on' : ''}" data-u="Todos">Todos<small>${base.length}</small></button>` +
            (tickets.some(t => t.miCuenta) ? `<button type="button" class="rp-chip todos${usuario === 'Mis' ? ' on' : ''}" data-u="Mis">Mis cuentas<small>${mias}</small></button>` : '') +
            users.map(u => `<button type="button" class="rp-chip${usuario === u ? ' on' : ''}" data-u="${esc(u)}" title="${esc(u)}"><span class="rp-av">${esc(iniciales(u))}</span>${esc(u.split(' ')[0])}<small>${base.filter(t => t.usuario === u).length}</small></button>`).join('');
    }

    function tarjeta(t, i) {
        const pre = t.precuenta;
        const mucho = t.minutos >= 90;
        const hace = pre && t.minutosPrecuenta != null ? ` · hace ${dur(t.minutosPrecuenta)}` : '';
        const barra = Math.min(100, Math.round(t.minutos / 120 * 100));
        const cli = clienteDe(t);
        return `<div class="rp-cta${pre ? ' pre' : ''}${mucho ? ' mucho' : ''}${(nuevas.get(t.globalId) || 0) > Date.now() ? ' nueva' : ''}${abierto && abierto.globalId === t.globalId ? ' sel' : ''}" style="animation-delay:${Math.min(i, 12) * 18}ms">` +
            `<span class="rp-calor" aria-hidden="true"><i style="width:${barra}%"></i></span>` +
            `<button type="button" class="rp-cuerpo" data-id="${esc(t.globalId)}" aria-label="Cobrar ${esc(t.mesa)}">` +
            `<div class="rp-c1"><div class="rp-mesa">${resalta(t.mesa)}</div><div class="rp-ctx"><span class="rp-area ${colorArea(t.centroVenta)}">${esc(t.centroVenta)}</span><span class="rp-tx num">#${resalta(t.ticketId)}</span></div></div>` +
            `<div class="rp-et${t.etiqueta ? '' : ' vacia'}">${t.etiqueta ? resalta(t.etiqueta) : 'Sin etiqueta'}</div>` +
            (pre ? `<span class="rp-badge">${ICO_IMPRESORA}Va a pagar${esc(hace)}</span>` : '') +
            (cli ? `<span class="rp-cli" title="${esc(cli.rnc)}">${ICO_CLIENTE}${esc(cli.nombre || cli.rnc)}</span>` : '') +
            `<div class="rp-c3"><div class="rp-meta"><div class="rp-u"><span class="rp-av">${esc(iniciales(t.usuario))}</span><span>${resalta(t.usuario || '—')}</span></div>` +
            `<div class="rp-tiempo${mucho ? ' larga' : ''}">${ICO_RELOJ}${dur(t.minutos)} abierta</div></div><div class="rp-total num">${moneda(t.total)}</div></div>` +
            `</button>` +
            `<div class="rp-cobra"><button type="button" class="rp-pre-btn rp-cli-btn" data-cli="${esc(t.globalId)}" title="${cli ? 'Cambiar o quitar el cliente de esta cuenta' : 'Asignar un cliente a esta cuenta'}">${ICO_CLIENTE}${cli ? 'Cliente' : 'Asignar cliente'}</button>` +
            `<button type="button" class="rp-pre-btn" data-pre="${esc(t.globalId)}" title="${pre ? 'Imprimir otra vez la precuenta' : 'Imprimir la precuenta de esta cuenta'}">${ICO_IMPRESORA}${pre ? 'Reimprimir' : 'Precuenta'}</button>` +
            `<button type="button" class="rp-cobrar-btn" data-id="${esc(t.globalId)}"><span>Cobrar</span>${ICO_FLECHA}</button></div></div>`;
    }

    function lista() {
        const v = visibles();
        if (!v.length) {
            $('rp-rejilla').innerHTML = `<div class="rp-vacio">${ICO_VACIO}<b>${tickets.length ? 'Ninguna cuenta coincide' : 'No hay cuentas abiertas'}</b>${tickets.length ? 'Pruebe con otro número de mesa o quite un filtro.' : 'Cuando abran una mesa en Ágora aparece aquí.'}</div>`;
            return;
        }
        $('rp-rejilla').innerHTML = v.map(tarjeta).join('');
    }

    function todo() {
        kpis(); tabs(); cajas(); usuarios(); lista();
        $('rp-campo').classList.toggle('con', !!busca);
    }

    // ---------------------------------------------------------------- teclado tactil
    function armarTeclado() {
        const letras = [...new Set(tickets.map(t => (t.mesa || '').trim()[0]).filter(c => c && /[A-Za-z]/.test(c)).map(c => c.toUpperCase()))].sort().slice(0, 6);
        let h = '789456123'.split('').map(d => `<button type="button" class="rp-tk" data-k="${d}">${d}</button>`).join('');
        h += letras.map(l => `<button type="button" class="rp-tk let" data-k="${l}">${l}</button>`).join('');
        h += '<button type="button" class="rp-tk" data-k="0">0</button><button type="button" class="rp-tk sec" data-k="DEL" aria-label="Borrar">⌫</button><button type="button" class="rp-tk sec" data-k="C">Limpiar</button>';
        $('rp-teclado').innerHTML = h;
    }

    // ---------------------------------------------------------------- pedir la precuenta desde la tarjeta

    async function pedirPrecuenta(boton) {
        const t = tickets.find(x => x.globalId === boton.dataset.pre); if (!t || boton.disabled) return;
        boton.disabled = true;
        try {
            const datos = new URLSearchParams({ ticket: t.globalId });
            const r = await fetch(raiz.dataset.url + '?handler=Precuenta' + (caja ? '&pos_id=' + encodeURIComponent(caja) : ''), { method: 'POST', body: datos });
            if (!r.ok) throw new Error('HTTP ' + r.status);
            const j = await r.json();
            toast(j.ok ? `${j.mensaje} · ${t.mesa}` : j.mensaje, j.ok);
            if (j.ok) { ocupadoHasta = 0; setTimeout(() => actualizar(true), 2500); }     // la tarjeta pasa a precuenta en cuanto la base la registra
        } catch (ex) { toast('No se pudo pedir la precuenta: ' + ex.message); }
        finally { boton.disabled = false; }
    }

    // ---------------------------------------------------------------- asignar cliente desde la tarjeta (los clientes ya creados en Agora)
    const ICO_CLIENTE = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><circle cx="12" cy="8" r="4" fill="none" stroke="currentColor" stroke-width="2"/><path d="M4 21c1-4 4-6 8-6s7 2 8 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
    const dlgCli = $('rp-dlg-cliente');
    let cliCuenta = null, cliElegido = null;

    function asignarCliente(t) {
        cliCuenta = t; cliElegido = null;
        const actual = clienteDe(t);
        $('rp-cli-mesa').textContent = `${t.centroVenta} · ${t.mesa}` + (actual ? ` — cliente actual: ${actual.nombre || actual.rnc}` : '');
        $('rp-cli-q').value = ''; $('rp-cli-res').innerHTML = ''; $('rp-cli-ok').disabled = true;
        $('rp-cli-quitar').hidden = !actual;
        if (!dlgCli.open) dlgCli.showModal();
        $('rp-cli-q').focus();
        buscarClientes();                 // sin texto: los primeros clientes
    }

    async function buscarClientes() {
        cliElegido = null; $('rp-cli-ok').disabled = true;
        const r = $('rp-cli-res'); r.innerHTML = '<div class="rp-dlg-cargando">Buscando…</div>';
        try {
            const resp = await fetch(raiz.dataset.url + '?handler=Clientes&texto=' + encodeURIComponent($('rp-cli-q').value.trim()) + (caja ? '&pos_id=' + encodeURIComponent(caja) : ''), { cache: 'no-store' });
            if (!resp.ok) throw new Error('HTTP ' + resp.status);
            r.innerHTML = await resp.text();
            const hallados = r.querySelectorAll('.resultado');
            if (hallados.length === 1) marcarCliente(hallados[0]);
        } catch (ex) { r.textContent = 'No se pudo buscar: ' + ex.message; }
    }

    function marcarCliente(el) {
        $('rp-cli-res').querySelectorAll('.resultado.seleccionado').forEach(x => x.classList.remove('seleccionado'));
        el.classList.add('seleccionado');
        cliElegido = { rnc: el.dataset.rnc, nombre: el.dataset.razon, correo: el.dataset.correo || '', telefono: el.dataset.telefono || '' };
        $('rp-cli-ok').disabled = false;
    }

    async function guardarCliente(cliente) {
        if (!cliCuenta) return;
        const t = cliCuenta;
        const datos = new URLSearchParams({ ticket: t.globalId, rnc: cliente ? cliente.rnc : '', nombre: cliente ? cliente.nombre : '', correo: cliente ? cliente.correo : '', telefono: cliente ? cliente.telefono : '' });
        try {
            const resp = await fetch(raiz.dataset.url + '?handler=AsignarCliente' + (caja ? '&pos_id=' + encodeURIComponent(caja) : ''), { method: 'POST', body: datos });
            if (!resp.ok) throw new Error('HTTP ' + resp.status);
            const j = await resp.json();
            if (!j.ok) { toast(j.mensaje || 'No se pudo guardar el cliente'); return; }
            clientes = clientes.filter(c => String(c.ticketId).toLowerCase() !== String(t.globalId).toLowerCase());
            if (cliente) clientes.push({ ticketId: t.globalId, rnc: cliente.rnc, nombre: cliente.nombre, correo: cliente.correo, telefono: cliente.telefono });
            dlgCli.close(); lista();
            toast(cliente ? `${cliente.nombre || cliente.rnc} asignado a ${t.mesa}` : `Cliente quitado de ${t.mesa}`, true);
        } catch (ex) { toast('No se pudo guardar el cliente: ' + ex.message); }
    }

    $('rp-cli-buscar').addEventListener('click', buscarClientes);
    $('rp-cli-q').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); if (cliElegido && $('rp-cli-q').value.trim() === '') guardarCliente(cliElegido); else buscarClientes(); } });
    $('rp-cli-res').addEventListener('click', e => { const el = e.target.closest('.resultado'); if (el) marcarCliente(el); });
    $('rp-cli-res').addEventListener('dblclick', e => { const el = e.target.closest('.resultado'); if (el) { marcarCliente(el); guardarCliente(cliElegido); } });
    $('rp-cli-ok').addEventListener('click', () => { if (cliElegido) guardarCliente(cliElegido); });
    $('rp-cli-quitar').addEventListener('click', () => guardarCliente(null));
    $('rp-cli-cancelar').addEventListener('click', () => dlgCli.close());

    // ---------------------------------------------------------------- precuenta nueva: sonido y aviso

    function pitar() {
        if (!sonido) return;
        try {
            ctxAudio = ctxAudio || new (window.AudioContext || window.webkitAudioContext)();
            if (ctxAudio.state === 'suspended') ctxAudio.resume();
            const t0 = ctxAudio.currentTime;
            [[880, 0], [1175, 0.2]].forEach(([f, d]) => {
                const o = ctxAudio.createOscillator(), g = ctxAudio.createGain();
                o.type = 'sine'; o.frequency.value = f;
                g.gain.setValueAtTime(0.0001, t0 + d); g.gain.exponentialRampToValueAtTime(0.35, t0 + d + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t0 + d + 0.4);
                o.connect(g); g.connect(ctxAudio.destination); o.start(t0 + d); o.stop(t0 + d + 0.45);
            });
        } catch { /* sin audio: queda el aviso en pantalla */ }
    }

    // El navegador solo deja sonar despues de un toque: el primer toque en la pantalla lo habilita.
    document.addEventListener('pointerdown', () => { try { ctxAudio = ctxAudio || new (window.AudioContext || window.webkitAudioContext)(); if (ctxAudio.state === 'suspended') ctxAudio.resume(); } catch { /* sin audio */ } }, { once: true });

    function pintarSonido() {
        const b = $('rp-sonido'); if (!b) return;
        b.setAttribute('aria-pressed', sonido); b.classList.toggle('mudo', !sonido);
        $('rp-sonido-t').textContent = sonido ? 'Sonido' : 'Silencio';
    }

    function detectarPrecuentas() {
        const ahora = new Set(tickets.filter(t => t.precuenta).map(t => t.globalId));
        if (!primeraCarga) {
            const nuevos = tickets.filter(t => t.precuenta && !precuentasVistas.has(t.globalId));
            if (nuevos.length) {
                nuevos.forEach(t => nuevas.set(t.globalId, Date.now() + 8000));
                pitar();
                toast((nuevos.length === 1 ? 'Pidieron la precuenta: ' : 'Pidieron la precuenta: ') + nuevos.map(t => `${t.centroVenta} ${t.mesa}`).join(', '));
                setTimeout(lista, 8200);                                   // quita el parpadeo
            }
        }
        const hubo = !primeraCarga && tickets.some(t => t.precuenta && !precuentasVistas.has(t.globalId));
        precuentasVistas.clear(); ahora.forEach(x => precuentasVistas.add(x));
        primeraCarga = false;
        return hubo;
    }

    // ---------------------------------------------------------------- carga y actualizacion
    function aviso(texto) { const a = $('rp-aviso'); a.hidden = !texto; a.textContent = texto || ''; }
    function toast(texto, ok) { const e = $('rp-toast'); e.textContent = texto; e.className = 'rp-toast on' + (ok ? ' ok' : ''); clearTimeout(toast.t); toast.t = setTimeout(() => { e.className = 'rp-toast'; }, 3500); }
    function vivo() {
        const s = Math.max(0, Math.round((Date.now() - ultima) / 1000));
        $('rp-vivo').classList.toggle('mal', fallo);
        $('rp-vivo-t').textContent = fallo ? 'Sin conexión · reintentando' : s < 5 ? 'En vivo' : `En vivo · actualizado hace ${s} s`;
    }

    async function actualizar(manual) {
        if (!manual && (abierto || Date.now() < ocupadoHasta)) return;
        const b = $('rp-act'); if (manual) { b.classList.remove('girando'); void b.offsetWidth; b.classList.add('girando'); }
        try {
            const r = await fetch(urlLista, { cache: 'no-store' });
            if (!r.ok) throw new Error('HTTP ' + r.status);
            const j = await r.json();
            if (!j.ok) { fallo = true; aviso(j.mensaje); vivo(); return; }
            fallo = false; aviso(''); ultima = Date.now();
            const antes = JSON.stringify([tickets.map(t => [t.globalId, t.precuenta, t.total, t.etiqueta]), clientes.map(c => [c.ticketId, c.rnc])]);
            tickets = j.tickets || [];
            if (Array.isArray(j.clientes)) clientes = j.clientes;
            const huboPrecuenta = detectarPrecuentas();
            if (manual || antes !== JSON.stringify([tickets.map(t => [t.globalId, t.precuenta, t.total, t.etiqueta]), clientes.map(c => [c.ticketId, c.rnc])])) { armarTeclado(); todo(); }
            vivo();
            if (manual && !huboPrecuenta) toast('Lista actualizada');          // si hay precuenta nueva, queda ese aviso
        } catch (ex) { fallo = true; aviso('No se pudo actualizar la lista: ' + ex.message); vivo(); }
    }

    // ---------------------------------------------------------------- panel de cobro
    function abrir(t) {
        abierto = t;
        $('rp-p-mesa').textContent = `${t.centroVenta} · ${t.mesa}`;
        $('rp-p-et').textContent = `${t.etiqueta ? t.etiqueta + ' · ' : ''}Transacción #${t.ticketId} · ${t.usuario || 'sin usuario'}`;
        $('rp-p-pre').hidden = !t.precuenta;
        $('rp-p-total').textContent = moneda(t.total);
        const q = new URLSearchParams({ ticket: t.globalId, centro: t.saleCenterId, ubicacion: t.mesa, boton: '1' });
        if (caja) q.set('pos_id', caja);
        $('rp-marco').src = '/cobro/ticket?' + q.toString();
        $('rp-panel').classList.add('abierto'); $('rp-panel').setAttribute('aria-hidden', 'false');
        $('rp-velo').hidden = false;
        lista();
    }
    // Nota de credito sin salir de aqui: la pantalla de notas de credito (otro puerto del mismo equipo) se abre en el mismo panel.
    function abrirNotaCredito() {
        const puerto = (raiz.dataset.nc || '5287');
        abierto = null;
        $('rp-p-mesa').textContent = 'Nota de crédito';
        $('rp-p-et').textContent = 'Buscar la factura, devolver o anular';
        $('rp-p-pre').hidden = true; $('rp-p-total').textContent = '';
        $('rp-marco').src = location.protocol + '//' + location.hostname + ':' + puerto + '/';
        $('rp-panel').classList.add('abierto'); $('rp-panel').setAttribute('aria-hidden', 'false');
        $('rp-velo').hidden = false;
    }
    function cerrar() {
        abierto = null;
        $('rp-panel').classList.remove('abierto'); $('rp-panel').setAttribute('aria-hidden', 'true');
        $('rp-velo').hidden = true;
        $('rp-marco').src = 'about:blank';
        lista();
    }

    // El cobro avisa por mensaje: "Volver" (applyFlow none) o cobro terminado (afterClose).
    window.addEventListener('message', e => {
        if (e.origin !== location.origin || !e.data || e.data.type !== 'agora:pos:close-window' || !abierto) return;
        const t = abierto;
        if (e.data.applyFlow === 'afterClose') {
            tickets = tickets.filter(x => x.globalId !== t.globalId);
            ocupadoHasta = Date.now() + 2500;
            cerrar(); armarTeclado(); todo();
            toast(`Cuenta cobrada · ${t.mesa} · ${moneda(t.total)}`, true);
            setTimeout(() => actualizar(true), 2600);
        } else {
            cerrar();
            actualizar(false);
        }
    });


    // ---------------------------------------------------------------- reimprimir una factura ya hecha
    // Busca facturas por cliente, RNC, numero o NCF; muestra el detalle; la reimprime como copia (por el servicio de impresion de esta caja) o la manda por correo.
    const dlgRe = $('rp-dlg-reimp');
    const ESPERA_IMPRESION = 20000;
    let reFactura = null, reSocket = null;
    const pos = caja ? '&pos_id=' + encodeURIComponent(caja) : '';
    const urlRe = h => raiz.dataset.url + '?handler=' + h + pos;
    const reMsg = (t, ok) => { const m = $('rp-re-msg'); m.textContent = t || ''; m.className = 'rp-re-msg' + (t ? (ok ? ' ok' : ' mal') : ''); };

    function abrirReimpresion() {
        reFactura = null; $('rp-re-det').hidden = true; $('rp-re-lista').hidden = true; $('rp-re-imprimir').hidden = true; $('rp-re-res').hidden = false;
        $('rp-re-q').value = ''; reMsg('');
        if (!dlgRe.open) dlgRe.showModal();
        $('rp-re-q').focus();
        buscarFacturas();                      // sin texto: las mas recientes
    }

    async function buscarFacturas() {
        const r = $('rp-re-res'); r.hidden = false; $('rp-re-det').hidden = true; $('rp-re-lista').hidden = true; $('rp-re-imprimir').hidden = true;
        r.innerHTML = '<div class="rp-dlg-cargando">Buscando…</div>';
        try {
            const resp = await fetch(urlRe('Facturas') + '&texto=' + encodeURIComponent($('rp-re-q').value.trim()) + '&dias=' + encodeURIComponent($('rp-re-dias').value), { cache: 'no-store' });
            if (!resp.ok) throw new Error('HTTP ' + resp.status);
            const j = await resp.json();
            if (!j.ok) { r.innerHTML = '<div class="alerta">' + esc(j.mensaje) + '</div>'; return; }
            if (!j.facturas.length) { r.innerHTML = '<div class="rp-re-vacio">No hay facturas con ese dato en el período elegido.</div>'; return; }
            r.innerHTML = j.facturas.map(f =>
                `<button type="button" class="rp-re-fila" data-serie="${esc(f.serie)}" data-numero="${f.numero}">` +
                `<b>${esc(f.serie)}-${String(f.numero).padStart(6, '0')} · ${esc(f.cliente || 'Consumidor final')}</b><span class="rp-re-monto">${moneda(f.total)}</span>` +
                `<span class="rp-re-sec">${esc(f.fecha)}${f.rnc ? ' · RNC ' + esc(f.rnc) : ''}${f.ncf ? ' · ' + esc(f.ncf) : ''}${f.tipo ? ' · ' + esc(f.tipo) : ''}</span><span></span></button>`).join('')
                + (j.total > j.facturas.length ? `<div class="rp-re-vacio">Se muestran las ${j.facturas.length} más recientes de ${j.total}. Escriba más del dato para acotar.</div>` : '');
        } catch (ex) { r.innerHTML = '<div class="alerta">No se pudo buscar: ' + esc(ex.message) + '</div>'; }
    }

    async function verFactura(serie, numero) {
        reMsg('Cargando…', true);
        try {
            const resp = await fetch(urlRe('Factura') + '&serie=' + encodeURIComponent(serie) + '&numero=' + numero, { cache: 'no-store' });
            if (!resp.ok) throw new Error('HTTP ' + resp.status);
            const j = await resp.json();
            if (!j.ok) { reMsg(j.mensaje); return; }
            reFactura = j; const f = j.resumen;
            $('rp-re-cab').innerHTML = `<div><b>${esc(f.serie)}-${String(f.numero).padStart(6, '0')}</b> · ${esc(f.fecha)}${f.usuario ? ' · ' + esc(f.usuario) : ''}</div>` +
                `<div>${esc(f.cliente || 'Consumidor final')}${f.rnc ? ' · RNC ' + esc(f.rnc) : ''}</div>` +
                (f.fiscal ? `<div class="rp-re-ncf">${esc(f.tipo)} · ${esc(f.ncf)} — se imprime como COPIA del documento</div>` : '<div>Sin comprobante fiscal — se imprime como reimpresión</div>');
            $('rp-re-lineas').innerHTML = f.lineas.map(l => `<div class="rp-re-linea"><span>${Number(l.cantidad).toLocaleString('es-DO', { maximumFractionDigits: 2 })}</span><span>${esc(l.descripcion)}</span><span>${moneda(l.importe)}</span></div>`).join('');
            $('rp-re-tot').innerHTML = `<span>Subtotal ${moneda(f.subtotal)}</span><span>Impuestos ${moneda(f.impuestos)}</span>` + (f.propina ? `<span>Propina ${moneda(f.propina)}</span>` : '') + (f.descuento ? `<span>Descuento ${moneda(f.descuento)}</span>` : '') +
                `<b>Total ${moneda(f.total)}</b>` + (f.pagos.length ? `<span>Pagó con: ${f.pagos.map(p => esc(p.forma) + ' ' + moneda(p.monto)).join(', ')}</span>` : '');
            $('rp-re-res').hidden = true; $('rp-re-det').hidden = false; $('rp-re-lista').hidden = false; $('rp-re-imprimir').hidden = false;
            $('rp-re-correo').value = ''; reMsg('');
        } catch (ex) { reMsg('No se pudo leer la factura: ' + ex.message); }
    }

    function conectarImpresionRe() {
        return new Promise((resolver, rechazar) => {
            if (reSocket && reSocket.readyState === WebSocket.OPEN) return resolver(reSocket);
            const url = raiz.dataset.socket;
            if (!url) return rechazar(new Error('Esta caja no tiene servicio de impresión configurado'));
            try { reSocket = new WebSocket(`ws://${url}/servicioimpresion`); } catch (ex) { return rechazar(ex); }
            const espera = setTimeout(() => { rechazar(new Error('EL SERVICIO DE IMPRESION NO RESPONDIO A TIEMPO')); try { reSocket.close(); } catch { /* ya cerrado */ } }, ESPERA_IMPRESION);
            reSocket.onopen = () => { clearTimeout(espera); resolver(reSocket); };
            reSocket.onerror = () => { clearTimeout(espera); rechazar(new Error('EL SERVICIO DE IMPRESION NO ESTA DISPONIBLE')); };
        });
    }

    async function imprimirCopia() {
        if (!reFactura) return;
        const b = $('rp-re-imprimir'); b.disabled = true; reMsg('Enviando a la impresora…', true);
        try {
            const s = await conectarImpresionRe();
            const respuesta = await new Promise((resolver, rechazar) => {
                const espera = setTimeout(() => rechazar(new Error('EL SERVICIO DE IMPRESION NO RESPONDIO A TIEMPO')), ESPERA_IMPRESION);
                s.onmessage = e => { clearTimeout(espera); try { resolver(JSON.parse(e.data)); } catch (ex) { rechazar(ex); } };
                s.onclose = () => { clearTimeout(espera); rechazar(new Error('EL SERVICIO DE IMPRESION CERRO LA CONEXION')); };
                s.send(JSON.stringify(reFactura.impresion));
            });
            const ok = respuesta.Exito ?? respuesta.exito;
            reMsg(ok ? 'Copia enviada a la impresora' : (respuesta.Mensaje ?? respuesta.mensaje ?? 'No se pudo imprimir'), !!ok);
        } catch (ex) { reMsg(ex.message); }
        finally { b.disabled = false; }
    }

    async function enviarCorreo() {
        if (!reFactura) return;
        const correo = $('rp-re-correo').value.trim();
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo)) { reMsg('Escriba un correo válido'); $('rp-re-correo').focus(); return; }
        const b = $('rp-re-enviar'); b.disabled = true; reMsg('Enviando el PDF…', true);
        try {
            const resp = await fetch(urlRe('Correo'), { method: 'POST', body: new URLSearchParams({ serie: reFactura.resumen.serie, numero: reFactura.resumen.numero, correo }) });
            if (!resp.ok) throw new Error('HTTP ' + resp.status);
            const j = await resp.json();
            reMsg(j.mensaje || (j.ok ? 'Enviado' : 'No se pudo enviar'), !!j.ok);
        } catch (ex) { reMsg('No se pudo enviar: ' + ex.message); }
        finally { b.disabled = false; }
    }

    $('rp-re-buscar').addEventListener('click', buscarFacturas);
    $('rp-re-dias').addEventListener('change', buscarFacturas);
    $('rp-re-q').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); buscarFacturas(); } });
    $('rp-re-res').addEventListener('click', e => { const f = e.target.closest('.rp-re-fila'); if (f) verFactura(f.dataset.serie, Number(f.dataset.numero)); });
    $('rp-re-lista').addEventListener('click', () => { reFactura = null; reMsg(''); $('rp-re-det').hidden = true; $('rp-re-lista').hidden = true; $('rp-re-imprimir').hidden = true; $('rp-re-res').hidden = false; });
    $('rp-re-imprimir').addEventListener('click', imprimirCopia);
    $('rp-re-enviar').addEventListener('click', enviarCorreo);
    $('rp-re-cerrar').addEventListener('click', () => dlgRe.close());
    dlgRe.addEventListener('close', () => { try { if (reSocket) reSocket.close(); } catch { /* ya cerrado */ } reSocket = null; });

    // ---------------------------------------------------------------- eventos
    document.addEventListener('click', e => {
        const b = e.target.closest('button'); if (!b) return;
        if (b.dataset.a) { area = b.dataset.a; todo(); return; }
        if (b.dataset.u) { usuario = b.dataset.u; todo(); return; }
        if (b.dataset.c) { caja_f = b.dataset.c; todo(); return; }
        if (b.dataset.e) { estado = b.dataset.e; todo(); return; }
        if (b.dataset.o) { orden = b.dataset.o; document.querySelectorAll('.rp-orden button').forEach(x => x.classList.toggle('on', x === b)); lista(); return; }
        if (b.dataset.id && (b.classList.contains('rp-cuerpo') || b.classList.contains('rp-cobrar-btn'))) { const t = tickets.find(x => x.globalId === b.dataset.id); if (t) abrir(t); return; }
        if (b.dataset.pre) { pedirPrecuenta(b); return; }
        if (b.dataset.cli) { const t = tickets.find(x => x.globalId === b.dataset.cli); if (t) asignarCliente(t); return; }
        if (b.id === 'rp-nc') { abrirNotaCredito(); return; }
        if (b.id === 'rp-reimp') { abrirReimpresion(); return; }
        if (b.id === 'rp-volver') { cerrar(); actualizar(true); return; }
        if (b.id === 'rp-limpiar') { busca = ''; $('rp-q').value = ''; todo(); return; }
        if (b.id === 'rp-act') { actualizar(true); return; }
        if (b.id === 'rp-sonido') { sonido = !sonido; try { localStorage.setItem('rp-sonido', sonido ? '1' : '0'); } catch { /* sin almacenamiento */ } pintarSonido(); if (sonido) pitar(); return; }
        if (b.id === 'rp-tecl') { const on = $('rp-teclado').classList.toggle('on'); b.classList.toggle('on', on); b.setAttribute('aria-pressed', on); return; }
        if (b.dataset.k) {
            const k = b.dataset.k;
            if (k === 'DEL') busca = busca.slice(0, -1); else if (k === 'C') busca = ''; else busca += k;
            $('rp-q').value = busca; todo();
        }
    });
    $('rp-velo').addEventListener('click', () => { cerrar(); actualizar(true); });
    $('rp-q').addEventListener('input', function () { busca = this.value.trim(); todo(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && abierto) { cerrar(); actualizar(true); } });

    armarTeclado();
    detectarPrecuentas();                                                       // lo que ya estaba pidiendo precuenta al abrir no suena
    pintarSonido();
    todo();
    vivo();
    if (raiz.dataset.error) aviso(raiz.dataset.error);
    setInterval(() => actualizar(false), 10000);
    setInterval(vivo, 1000);
})();
