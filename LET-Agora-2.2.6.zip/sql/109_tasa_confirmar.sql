﻿-- 109_tasa_confirmar.sql
-- dbo.LetRegistrarTasa acepta @Confirmado: una tasa que cambia mas de 25% se rechaza (posible error de digitacion) salvo que quien la cambia la confirme.
-- Incluye @PorAdministrador de 108. Misma definicion que 003_monedas.sql, repetida para que una actualizacion desde el portal la aplique.
IF OBJECT_ID(N'[dbo].[LetRegistrarTasa]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetRegistrarTasa] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetRegistrarTasa] (@Moneda CHAR(3), @Tasa DECIMAL(12,4), @Usuario NVARCHAR(100) = NULL, @Pin NVARCHAR(40) = NULL, @PorAdministrador BIT = 0, @Confirmado BIT = 0)
AS
BEGIN
    SET NOCOUNT ON;
    -- La tasa la cambia un supervisor (usuario con permiso de cambiar la tasa y su PIN: LetFlujoInternoUsuarioGuardar ... @PuedeCambiarTasa = 1) o, desde el portal,
    -- un administrador ya autenticado (@PorAdministrador = 1; el portal solo lo pide con rol ADMIN y deja el usuario en la auditoria). @Usuario queda en el historial.
    DECLARE @AutOk BIT = 1, @AutMotivo NVARCHAR(200);
    IF @PorAdministrador = 0
    BEGIN
        EXEC dbo.LetFlujoInternoAutenticar @Usuario, @Pin, 'TASA', @AutOk OUTPUT, @AutMotivo OUTPUT;
        IF @AutOk = 0 BEGIN SELECT CAST(0 AS BIT) AS Ok, @AutMotivo + N' (la tasa la cambia un supervisor con permiso de tasa o un administrador del portal)' AS Mensaje; RETURN; END
    END
    SET @Moneda = UPPER(LTRIM(RTRIM(@Moneda)));
    IF NOT EXISTS (SELECT 1 FROM dbo.LetMoneda WHERE Codigo = @Moneda AND Activa = 1) BEGIN SELECT CAST(0 AS BIT) AS Ok, N'La moneda no existe o esta inactiva' AS Mensaje; RETURN; END
    IF @Tasa IS NULL OR @Tasa <= 0 OR @Tasa > 100000 BEGIN SELECT CAST(0 AS BIT) AS Ok, N'La tasa debe ser mayor que 0 (pesos por 1 ' + @Moneda + N')' AS Mensaje; RETURN; END
    -- Una tasa que se aleja mas de 25% de la anterior casi siempre es un error de digitacion (580 en vez de 58): se rechaza salvo que quien la cambia
    -- la confirme (@Confirmado = 1; el portal lo pide con una pregunta).
    DECLARE @Anterior DECIMAL(12,4) = dbo.LetTasaVigente(@Moneda, GETDATE());
    IF @Anterior IS NOT NULL AND @Confirmado = 0 AND (@Tasa > @Anterior * 1.25 OR @Tasa < @Anterior * 0.75)
    BEGIN SELECT CAST(0 AS BIT) AS Ok, N'La tasa cambia mas de 25% respecto a la anterior (' + CONVERT(NVARCHAR(20), @Anterior) + N'): revise que este bien escrita' AS Mensaje; RETURN; END

    BEGIN TRANSACTION;
    INSERT dbo.LetTasaCambio (Moneda, Tasa, Usuario) VALUES (@Moneda, @Tasa, LEFT(@Usuario, 60));
    UPDATE m SET Rate = @Tasa FROM dbo.LETMetodoPagos m JOIN dbo.LetMonedaFormaPago x ON x.AgoraPaymentId = m.AgoraPaymentId WHERE x.Moneda = @Moneda;
    IF @Moneda = 'USD'
    BEGIN
        IF OBJECT_ID(N'dbo.LetPrecuentaConfiguracion', N'U') IS NOT NULL
            EXEC sp_executesql N'UPDATE dbo.LetPrecuentaConfiguracion SET TasaDolar = @t', N'@t DECIMAL(12,4)', @Tasa;
        IF OBJECT_ID(N'dbo.MonitorParametros', N'U') IS NOT NULL
            EXEC sp_executesql N'UPDATE dbo.MonitorParametros SET TasaDolar = @t', N'@t DECIMAL(12,2)', @Tasa;
    END
    COMMIT TRANSACTION;
    SELECT CAST(1 AS BIT) AS Ok, N'Tasa registrada: 1 ' + @Moneda + N' = RD$ ' + CONVERT(NVARCHAR(20), @Tasa) AS Mensaje;
END
GO
