// Cobro rapido: lista de cuentas abiertas, filtros, busqueda y el panel donde se cobra (el cobro de siempre, /cobro/ticket).
(function () {
    'use strict';
    const raiz = document.getElementById('rp');
    if (!raiz) return;
    const $ = id => document.getElementById(id);

    const caja = raiz.dataset.caja || '';
    const urlLista = raiz.dataset.url + '?handler=Lista' + (caja ? '&pos_id=' + encodeURIComponent(caja) : '');
    let tickets = [];
    let area = 'Todas', usuario = 'Todos', estado = 'Todas', orden = 'precuenta', busca = '', abierto = null, ocupadoHasta = 0;

    try { tickets = JSON.parse(raiz.dataset.inicial || '[]'); } catch { tickets = []; }

    const esc = t => String(t ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const plano = t => String(t ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
    const moneda = n => '$' + Number(n || 0).toLocaleString('es-DO', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    const dur = m => m >= 1440 ? Math.floor(m / 1440) + ' d ' + Math.floor((m % 1440) / 60) + ' h' : m >= 60 ? Math.floor(m / 60) + ' h ' + ('0' + (m % 60)).slice(-2) + ' min' : m + ' min';
    const iniciales = n => (String(n || '?').trim().split(/\s+/).map(p => p[0]).join('').slice(0, 2) || '?').toUpperCase();
    const colorArea = nombre => { let h = 0; for (const c of String(nombre)) h = (h * 31 + c.charCodeAt(0)) % 5; return 'a' + h; };

    function resalta(texto) {
        const t = String(texto ?? '');
        if (!busca) return esc(t);
        const i = plano(t).indexOf(plano(busca));
        if (i < 0) return esc(t);
        return esc(t.slice(0, i)) + '<mark>' + esc(t.slice(i, i + busca.length)) + '</mark>' + esc(t.slice(i + busca.length));
    }

    function coincide(t) {
        if (area !== 'Todas' && t.centroVenta !== area) return false;
        if (usuario !== 'Todos' && t.usuario !== usuario) return false;
        if (estado === 'Precuenta' && !t.precuenta) return false;
        if (estado === 'Sin precuenta' && t.precuenta) return false;
        if (!busca) return true;
        return plano([t.mesa, '#' + t.ticketId, t.ticketId, t.etiqueta, t.usuario, t.centroVenta].join(' ')).includes(plano(busca));
    }

    function visibles() {
        const v = tickets.filter(coincide);
        v.sort((a, b) => {
            if (orden === 'monto') return b.total - a.total;
            if (orden === 'precuenta' && a.precuenta !== b.precuenta) return a.precuenta ? -1 : 1;
            return b.minutos - a.minutos;
        });
        return v;
    }

    function fila(rot, items, activo, attr, clase) {
        return `<span class="rp-rot">${rot}</span>` + items.map(([valor, texto, n, extra]) =>
            `<button type="button" class="rp-chip${clase && valor === 'Precuenta' ? ' pre' : ''}${valor === activo ? ' on' : ''}" ${attr}="${esc(valor)}">${extra || ''}${esc(texto)}<small>${n}</small></button>`).join('');
    }

    function filtros() {
        // Cada fila cuenta con los otros filtros aplicados.
        const sinArea = tickets.filter(t => (usuario === 'Todos' || t.usuario === usuario) && (estado === 'Todas' || (estado === 'Precuenta' ? t.precuenta : !t.precuenta)));
        const areas = [...new Set(tickets.map(t => t.centroVenta))].filter(Boolean).sort();
        $('rp-f-areas').innerHTML = fila('Área', [['Todas', 'Todas', sinArea.length]].concat(areas.map(a => [a, a, sinArea.filter(t => t.centroVenta === a).length])), area, 'data-a');

        const sinUser = tickets.filter(t => (area === 'Todas' || t.centroVenta === area) && (estado === 'Todas' || (estado === 'Precuenta' ? t.precuenta : !t.precuenta)));
        const users = [...new Set(tickets.map(t => t.usuario))].filter(Boolean).sort();
        $('rp-f-users').innerHTML = fila('Usuario', [['Todos', 'Todos', sinUser.length]].concat(users.map(u => [u, u.split(' ')[0], sinUser.filter(t => t.usuario === u).length, `<span class="rp-av">${esc(iniciales(u))}</span>`])), usuario, 'data-u');

        const sinEst = tickets.filter(t => (area === 'Todas' || t.centroVenta === area) && (usuario === 'Todos' || t.usuario === usuario));
        $('rp-f-estado').innerHTML = fila('Estado', [['Todas', 'Todas', sinEst.length], ['Precuenta', 'Precuenta pedida', sinEst.filter(t => t.precuenta).length], ['Sin precuenta', 'Sin precuenta', sinEst.filter(t => !t.precuenta).length]], estado, 'data-e', true);
    }

    function lista() {
        const v = visibles();
        const suma = v.reduce((s, t) => s + t.total, 0);
        const pre = v.filter(t => t.precuenta).length;
        $('rp-res').innerHTML = `<b>${v.length} cuenta${v.length === 1 ? '' : 's'}</b>${pre ? ` · <b>${pre}</b> con precuenta` : ''} · pendiente <b class="num">${moneda(suma)}</b>`;
        if (!v.length) {
            $('rp-rejilla').innerHTML = `<div class="rp-vacio"><b>${tickets.length ? 'No hay cuentas con ese filtro' : 'No hay cuentas abiertas'}</b>${tickets.length ? 'Pruebe con otro número de mesa o quite la búsqueda.' : 'Cuando abran una mesa en Ágora aparece aquí.'}</div>`;
            return;
        }
        $('rp-rejilla').innerHTML = v.map(t => {
            const pre = t.precuenta;
            const hace = pre && t.minutosPrecuenta != null ? ` · hace ${dur(t.minutosPrecuenta)}` : '';
            return `<button type="button" class="rp-cta${pre ? ' pre' : ''}${abierto && abierto.globalId === t.globalId ? ' sel' : ''}" data-id="${esc(t.globalId)}">` +
                `<div class="rp-top"><span class="rp-area ${colorArea(t.centroVenta)}">${esc(t.centroVenta)}</span><span class="rp-tx num">#${resalta(t.ticketId)}</span></div>` +
                (pre ? `<span class="rp-badge"><svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path d="M7 9V3h10v6M7 14H5a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-2M7 14h10v7H7z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>Precuenta${esc(hace)}</span>` : '') +
                `<div class="rp-mesa">${resalta(t.mesa)}</div>` +
                `<div class="rp-et${t.etiqueta ? '' : ' vacia'}">${t.etiqueta ? resalta(t.etiqueta) : 'Sin etiqueta'}</div>` +
                `<div class="rp-pie"><div><div class="rp-u"><span class="rp-av">${esc(iniciales(t.usuario))}</span><span>${resalta((t.usuario || '').split(' ')[0] || '—')}</span></div>` +
                `<div class="rp-tiempo${t.minutos >= 60 ? ' larga' : ''}">Abierta ${dur(t.minutos)}</div></div><div class="rp-total num">${moneda(t.total)}</div></div></button>`;
        }).join('');
    }

    function todo() {
        filtros(); lista();
        $('rp-campo').classList.toggle('con', !!busca);
        $('rp-sub').textContent = tickets.length ? `${tickets.length} cuentas abiertas` : 'Cuentas abiertas';
    }

    // ---------------------------------------------------------------- teclado tactil
    function armarTeclado() {
        const letras = [...new Set(tickets.map(t => (t.mesa || '').trim()[0]).filter(c => c && /[A-Za-z]/.test(c)).map(c => c.toUpperCase()))].sort().slice(0, 6);
        let h = '789456123'.split('').map(d => `<button type="button" class="rp-tk" data-k="${d}">${d}</button>`).join('');
        h += letras.map(l => `<button type="button" class="rp-tk let" data-k="${l}">${l}</button>`).join('');
        h += '<button type="button" class="rp-tk" data-k="0">0</button><button type="button" class="rp-tk sec" data-k="DEL" aria-label="Borrar">⌫</button><button type="button" class="rp-tk sec" data-k="C">Limpiar</button>';
        $('rp-teclado').innerHTML = h;
    }

    // ---------------------------------------------------------------- carga y actualizacion
    function aviso(texto) { const a = $('rp-aviso'); a.hidden = !texto; a.textContent = texto || ''; }
    function toast(texto, ok) { const e = $('rp-toast'); e.textContent = texto; e.className = 'rp-toast on' + (ok ? ' ok' : ''); clearTimeout(toast.t); toast.t = setTimeout(() => { e.className = 'rp-toast'; }, 3500); }

    async function actualizar(manual) {
        if (!manual && (abierto || Date.now() < ocupadoHasta)) return;
        try {
            const r = await fetch(urlLista, { cache: 'no-store' });
            if (!r.ok) throw new Error('HTTP ' + r.status);
            const j = await r.json();
            if (!j.ok) { aviso(j.mensaje); return; }
            aviso('');
            tickets = j.tickets || [];
            armarTeclado(); todo();
            if (manual) toast('Lista actualizada');
        } catch (ex) { aviso('No se pudo actualizar la lista: ' + ex.message); }
    }

    // ---------------------------------------------------------------- panel de cobro
    function abrir(t) {
        abierto = t;
        $('rp-p-mesa').textContent = `${t.centroVenta} · ${t.mesa}`;
        $('rp-p-et').textContent = `${t.etiqueta ? t.etiqueta + ' · ' : ''}Transacción #${t.ticketId} · ${t.usuario || 'sin usuario'}`;
        $('rp-p-pre').hidden = !t.precuenta;
        const q = new URLSearchParams({ ticket: t.globalId, centro: t.saleCenterId, ubicacion: t.mesa, boton: '1' });
        if (caja) q.set('pos_id', caja);
        $('rp-marco').src = '/cobro/ticket?' + q.toString();
        $('rp-panel').classList.add('abierto'); $('rp-panel').setAttribute('aria-hidden', 'false');
        $('rp-velo').hidden = false;
        lista();
    }
    function cerrar() {
        abierto = null;
        $('rp-panel').classList.remove('abierto'); $('rp-panel').setAttribute('aria-hidden', 'true');
        $('rp-velo').hidden = true;
        $('rp-marco').src = 'about:blank';
        lista();
    }

    // El cobro avisa por mensaje: "Volver" (applyFlow none) o cobro terminado (afterClose).
    window.addEventListener('message', e => {
        if (e.origin !== location.origin || !e.data || e.data.type !== 'agora:pos:close-window' || !abierto) return;
        const t = abierto;
        if (e.data.applyFlow === 'afterClose') {
            tickets = tickets.filter(x => x.globalId !== t.globalId);
            ocupadoHasta = Date.now() + 2500;
            cerrar(); armarTeclado(); todo();
            toast(`Cuenta cobrada · ${t.mesa} · ${moneda(t.total)}`, true);
            setTimeout(() => actualizar(true), 2600);
        } else {
            cerrar();
            actualizar(false);
        }
    });

    // ---------------------------------------------------------------- eventos
    document.addEventListener('click', e => {
        const b = e.target.closest('button'); if (!b) return;
        if (b.dataset.a) { area = b.dataset.a; todo(); return; }
        if (b.dataset.u) { usuario = b.dataset.u; todo(); return; }
        if (b.dataset.e) { estado = b.dataset.e; todo(); return; }
        if (b.dataset.o) { orden = b.dataset.o; document.querySelectorAll('.rp-orden button').forEach(x => x.classList.toggle('on', x === b)); lista(); return; }
        if (b.classList.contains('rp-cta')) { const t = tickets.find(x => x.globalId === b.dataset.id); if (t) abrir(t); return; }
        if (b.id === 'rp-volver') { cerrar(); actualizar(true); return; }
        if (b.id === 'rp-limpiar') { busca = ''; $('rp-q').value = ''; todo(); return; }
        if (b.id === 'rp-act') { actualizar(true); return; }
        if (b.id === 'rp-tecl') { const on = $('rp-teclado').classList.toggle('on'); b.classList.toggle('on', on); b.setAttribute('aria-pressed', on); return; }
        if (b.dataset.k) {
            const k = b.dataset.k;
            if (k === 'DEL') busca = busca.slice(0, -1); else if (k === 'C') busca = ''; else busca += k;
            $('rp-q').value = busca; todo();
        }
    });
    $('rp-velo').addEventListener('click', () => { cerrar(); actualizar(true); });
    $('rp-q').addEventListener('input', function () { busca = this.value.trim(); todo(); });
    // En un equipo tactil el teclado del sistema tapa la lista: el campo usa el teclado de la pantalla (inputmode none);
    // con teclado fisico se escribe igual.
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && abierto) { cerrar(); actualizar(true); } });

    armarTeclado();
    todo();
    if (raiz.dataset.error) aviso(raiz.dataset.error);
    setInterval(() => actualizar(false), 10000);
})();
