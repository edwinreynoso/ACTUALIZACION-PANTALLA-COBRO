﻿-- 110_cliente_forma_pago_interno.sql
-- dbo.LetFlujoInternoCerrar: una venta con un cliente de 'Clientes y formas de pago' que paga con SU forma de pago se cierra como operacion interna (serie F)
-- y no se envia a e-Fiscal Cloud, sin exigir el cierre operativo de la caja ni el permiso del cajero. Misma definicion que 008_flujo_interno.sql,
-- repetida para que una actualizacion desde el portal la aplique.
IF OBJECT_ID(N'[dbo].[LetFlujoInternoCerrar]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetFlujoInternoCerrar] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetFlujoInternoCerrar] (@Serie NVARCHAR(10), @Numero INT)
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Usuario NVARCHAR(100), @PosId INT, @Rnc VARCHAR(20), @Nombre NVARCHAR(200), @Forma INT, @Imprimir CHAR(1),
            @ClienteOk BIT, @FormaOk BIT, @Habilitado BIT, @Permiso BIT;
    SELECT @Usuario = Usuario, @PosId = PosId, @Rnc = Rnc, @Nombre = ClienteNombre, @Forma = FormaActivadora, @Imprimir = Imprimir,
           @ClienteOk = Cliente, @FormaOk = FormaPago, @Habilitado = Habilitado, @Permiso = Permiso
      FROM dbo.LetFlujoInternoEvalua(@Serie, @Numero);

    IF @ClienteOk IS NULL OR @ClienteOk = 0 OR @FormaOk = 0 RETURN;      -- cierre habitual
    IF EXISTS (SELECT 1 FROM dbo.LetOperacionInterna WHERE Serie = @Serie AND Numero = @Numero) RETURN;   -- ya cerrada: no se repite

    DECLARE @ColaId INT = (SELECT Id FROM dbo.LetFE_Cola WHERE Serie = @Serie AND Numero = @Numero AND Documento = 'F');
    IF @ColaId IS NULL
    BEGIN
        RAISERROR(N'EL CIERRE OPERATIVO INTERNO NECESITA LA INTEGRACION CON e-FISCAL CLOUD (EL COMPROBANTE DEBE QUEDAR PENDIENTE DE FISCALIZAR). AVISE A SOPORTE', 16, 1);
        RETURN;
    END

    -- El comprobante queda pendiente: el puente solo toma PENDIENTE y ENVIANDO.
    UPDATE dbo.LetFE_Cola SET Estado = 'DIFERIDO', UltimoError = N'Operacion interna pendiente de fiscalizar', Actualizado = GETDATE()
     WHERE Id = @ColaId AND Estado = 'PENDIENTE' AND Encf IS NULL;

    INSERT dbo.LetOperacionInterna (Serie, Numero, ColaId, ClienteRnc, ClienteNombre, IdFormaPagoActivadora, PosId, Usuario, Subtotal, Itbis, Propina, Total, Lineas, Imprimir)
    SELECT f.Serie, f.Numero, @ColaId, @Rnc, @Nombre, @Forma, f.PosId, f.Usuario, f.BaseImponible, f.Impuestos, ISNULL(f.Propina, 0), f.TotalNeto,
           (SELECT CASE WHEN ISJSON(q.Json) = 1 THEN JSON_QUERY(q.Json, '$.items') END FROM dbo.LetFE_Cola q WHERE q.Id = @ColaId), @Imprimir
      FROM dbo.Factura f WHERE f.Serie = @Serie AND f.Numero = @Numero;

    EXEC dbo.LetFlujoInternoAuditar @Serie, @Numero, @Usuario, 'CIERRE', N'Cierre operativo interno: fiscalizacion pendiente';
END
GO
