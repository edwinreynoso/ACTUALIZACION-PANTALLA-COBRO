// Cobro rapido: resumen, filtros, busqueda, tarjetas de cuentas y el panel donde se cobra (el cobro de siempre, /cobro/ticket).
(function () {
    'use strict';
    const raiz = document.getElementById('rp');
    if (!raiz) return;
    const $ = id => document.getElementById(id);

    const caja = raiz.dataset.caja || '';
    const urlLista = raiz.dataset.url + '?handler=Lista' + (caja ? '&pos_id=' + encodeURIComponent(caja) : '');
    let tickets = [];
    let area = 'Todas', usuario = 'Todos', estado = 'Todas', orden = 'precuenta', busca = '', abierto = null, ocupadoHasta = 0, ultima = Date.now(), fallo = false;

    try { tickets = JSON.parse(raiz.dataset.inicial || '[]'); } catch { tickets = []; }

    const esc = t => String(t ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const plano = t => String(t ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
    const moneda = n => '$' + Number(n || 0).toLocaleString('es-DO', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    const dur = m => m >= 1440 ? Math.floor(m / 1440) + ' d ' + Math.floor((m % 1440) / 60) + ' h' : m >= 60 ? Math.floor(m / 60) + ' h ' + ('0' + (m % 60)).slice(-2) + ' min' : m + ' min';
    const iniciales = n => (String(n || '?').trim().split(/\s+/).map(p => p[0]).join('').slice(0, 2) || '?').toUpperCase();
    const colorArea = nombre => { let h = 0; for (const c of String(nombre)) h = (h * 31 + c.charCodeAt(0)) % 5; return 'a' + h; };

    const ICO_RELOJ = '<svg viewBox="0 0 24 24" width="15" height="15" aria-hidden="true"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2"/><path d="M12 7v5l3 2" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
    const ICO_IMPRESORA = '<svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path d="M7 9V3h10v6M7 14H5a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-2M7 14h10v7H7z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>';
    const ICO_FLECHA = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    const ICO_VACIO = '<svg viewBox="0 0 24 24" width="56" height="56" aria-hidden="true"><path d="M19.5 3.5 18 2l-1.5 1.5L15 2l-1.5 1.5L12 2l-1.5 1.5L9 2 7.5 3.5 6 2 4.5 3.5 3 2v20l1.5-1.5L6 22l1.5-1.5L9 22l1.5-1.5L12 22l1.5-1.5L15 22l1.5-1.5L18 22l1.5-1.5L21 22V2zM8 8h8M8 12h8M8 16h5" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';

    function resalta(texto) {
        const t = String(texto ?? '');
        if (!busca) return esc(t);
        const i = plano(t).indexOf(plano(busca));
        if (i < 0) return esc(t);
        return esc(t.slice(0, i)) + '<mark>' + esc(t.slice(i, i + busca.length)) + '</mark>' + esc(t.slice(i + busca.length));
    }

    function coincide(t, ignorar) {
        if (ignorar !== 'area' && area !== 'Todas' && t.centroVenta !== area) return false;
        if (ignorar !== 'usuario' && usuario !== 'Todos' && t.usuario !== usuario) return false;
        if (ignorar !== 'estado' && estado === 'Precuenta' && !t.precuenta) return false;
        if (!busca) return true;
        return plano([t.mesa, '#' + t.ticketId, t.ticketId, t.etiqueta, t.usuario, t.centroVenta].join(' ')).includes(plano(busca));
    }

    function visibles() {
        const v = tickets.filter(t => coincide(t));
        v.sort((a, b) => {
            if (orden === 'monto') return b.total - a.total;
            if (orden === 'precuenta' && a.precuenta !== b.precuenta) return a.precuenta ? -1 : 1;
            return b.minutos - a.minutos;
        });
        return v;
    }

    // Resumen: lo que hay ahora, lo que falta por cobrar y quienes estan por pagar (esta ultima tambien filtra).
    function kpis() {
        const v = tickets.filter(t => coincide(t, 'estado'));
        const suma = v.reduce((s, t) => s + t.total, 0);
        const pre = v.filter(t => t.precuenta);
        const sumaPre = pre.reduce((s, t) => s + t.total, 0);
        $('rp-kpis').innerHTML =
            `<div class="rp-kpi"><small>Cuentas abiertas</small><b class="num">${v.length}</b><span>${area === 'Todas' ? 'en todas las áreas' : 'en ' + esc(area)}</span></div>` +
            `<div class="rp-kpi"><small>Por cobrar</small><b class="num">${moneda(suma)}</b><span>total de las cuentas que ve</span></div>` +
            `<button type="button" class="rp-kpi pre${estado === 'Precuenta' ? ' on' : ''}${pre.length ? '' : ' cero'}" data-e="${estado === 'Precuenta' ? 'Todas' : 'Precuenta'}" aria-pressed="${estado === 'Precuenta'}">` +
            `<small>Por pagar · precuenta pedida</small><b class="num">${pre.length}</b><span>${pre.length ? moneda(sumaPre) + ' · toque para ' + (estado === 'Precuenta' ? 'ver todas' : 'verlas solas') : 'ninguna por ahora'}</span></button>`;
    }

    function tabs() {
        const base = tickets.filter(t => coincide(t, 'area'));
        const areas = [...new Set(tickets.map(t => t.centroVenta))].filter(Boolean).sort();
        const item = (valor, texto) => `<button type="button" role="tab" class="rp-tab${valor === area ? ' on' : ''}" data-a="${esc(valor)}" aria-selected="${valor === area}">${esc(texto)}<small>${valor === 'Todas' ? base.length : base.filter(t => t.centroVenta === valor).length}</small></button>`;
        $('rp-f-areas').innerHTML = item('Todas', 'Todas las áreas') + areas.map(a => item(a, a)).join('');
    }

    function usuarios() {
        const base = tickets.filter(t => coincide(t, 'usuario'));
        const users = [...new Set(tickets.map(t => t.usuario))].filter(Boolean).sort();
        $('rp-f-users').innerHTML = '<span class="rp-u-rot">Usuario</span>' +
            `<button type="button" class="rp-chip todos${usuario === 'Todos' ? ' on' : ''}" data-u="Todos">Todos<small>${base.length}</small></button>` +
            users.map(u => `<button type="button" class="rp-chip${usuario === u ? ' on' : ''}" data-u="${esc(u)}" title="${esc(u)}"><span class="rp-av">${esc(iniciales(u))}</span>${esc(u.split(' ')[0])}<small>${base.filter(t => t.usuario === u).length}</small></button>`).join('');
    }

    function tarjeta(t, i) {
        const pre = t.precuenta;
        const mucho = t.minutos >= 90;
        const hace = pre && t.minutosPrecuenta != null ? ` · hace ${dur(t.minutosPrecuenta)}` : '';
        const barra = Math.min(100, Math.round(t.minutos / 120 * 100));
        return `<button type="button" class="rp-cta${pre ? ' pre' : ''}${mucho ? ' mucho' : ''}${abierto && abierto.globalId === t.globalId ? ' sel' : ''}" data-id="${esc(t.globalId)}" style="animation-delay:${Math.min(i, 12) * 18}ms">` +
            `<span class="rp-calor" aria-hidden="true"><i style="width:${barra}%"></i></span>` +
            `<div class="rp-c1"><div class="rp-mesa">${resalta(t.mesa)}</div><div class="rp-ctx"><span class="rp-area ${colorArea(t.centroVenta)}">${esc(t.centroVenta)}</span><span class="rp-tx num">#${resalta(t.ticketId)}</span></div></div>` +
            `<div class="rp-et${t.etiqueta ? '' : ' vacia'}">${t.etiqueta ? resalta(t.etiqueta) : 'Sin etiqueta'}</div>` +
            (pre ? `<span class="rp-badge">${ICO_IMPRESORA}Va a pagar${esc(hace)}</span>` : '') +
            `<div class="rp-c3"><div class="rp-meta"><div class="rp-u"><span class="rp-av">${esc(iniciales(t.usuario))}</span><span>${resalta(t.usuario || '—')}</span></div>` +
            `<div class="rp-tiempo${mucho ? ' larga' : ''}">${ICO_RELOJ}${dur(t.minutos)} abierta</div></div><div class="rp-total num">${moneda(t.total)}</div></div>` +
            `<div class="rp-cobra"><span>Cobrar esta cuenta</span>${ICO_FLECHA}</div></button>`;
    }

    function lista() {
        const v = visibles();
        if (!v.length) {
            $('rp-rejilla').innerHTML = `<div class="rp-vacio">${ICO_VACIO}<b>${tickets.length ? 'Ninguna cuenta coincide' : 'No hay cuentas abiertas'}</b>${tickets.length ? 'Pruebe con otro número de mesa o quite un filtro.' : 'Cuando abran una mesa en Ágora aparece aquí.'}</div>`;
            return;
        }
        $('rp-rejilla').innerHTML = v.map(tarjeta).join('');
    }

    function todo() {
        kpis(); tabs(); usuarios(); lista();
        $('rp-campo').classList.toggle('con', !!busca);
    }

    // ---------------------------------------------------------------- teclado tactil
    function armarTeclado() {
        const letras = [...new Set(tickets.map(t => (t.mesa || '').trim()[0]).filter(c => c && /[A-Za-z]/.test(c)).map(c => c.toUpperCase()))].sort().slice(0, 6);
        let h = '789456123'.split('').map(d => `<button type="button" class="rp-tk" data-k="${d}">${d}</button>`).join('');
        h += letras.map(l => `<button type="button" class="rp-tk let" data-k="${l}">${l}</button>`).join('');
        h += '<button type="button" class="rp-tk" data-k="0">0</button><button type="button" class="rp-tk sec" data-k="DEL" aria-label="Borrar">⌫</button><button type="button" class="rp-tk sec" data-k="C">Limpiar</button>';
        $('rp-teclado').innerHTML = h;
    }

    // ---------------------------------------------------------------- carga y actualizacion
    function aviso(texto) { const a = $('rp-aviso'); a.hidden = !texto; a.textContent = texto || ''; }
    function toast(texto, ok) { const e = $('rp-toast'); e.textContent = texto; e.className = 'rp-toast on' + (ok ? ' ok' : ''); clearTimeout(toast.t); toast.t = setTimeout(() => { e.className = 'rp-toast'; }, 3500); }
    function vivo() {
        const s = Math.max(0, Math.round((Date.now() - ultima) / 1000));
        $('rp-vivo').classList.toggle('mal', fallo);
        $('rp-vivo-t').textContent = fallo ? 'Sin conexión · reintentando' : s < 5 ? 'En vivo' : `En vivo · actualizado hace ${s} s`;
    }

    async function actualizar(manual) {
        if (!manual && (abierto || Date.now() < ocupadoHasta)) return;
        const b = $('rp-act'); if (manual) { b.classList.remove('girando'); void b.offsetWidth; b.classList.add('girando'); }
        try {
            const r = await fetch(urlLista, { cache: 'no-store' });
            if (!r.ok) throw new Error('HTTP ' + r.status);
            const j = await r.json();
            if (!j.ok) { fallo = true; aviso(j.mensaje); vivo(); return; }
            fallo = false; aviso(''); ultima = Date.now();
            const antes = JSON.stringify(tickets.map(t => [t.globalId, t.precuenta, t.total, t.etiqueta]));
            tickets = j.tickets || [];
            if (manual || antes !== JSON.stringify(tickets.map(t => [t.globalId, t.precuenta, t.total, t.etiqueta]))) { armarTeclado(); todo(); }
            vivo();
            if (manual) toast('Lista actualizada');
        } catch (ex) { fallo = true; aviso('No se pudo actualizar la lista: ' + ex.message); vivo(); }
    }

    // ---------------------------------------------------------------- panel de cobro
    function abrir(t) {
        abierto = t;
        $('rp-p-mesa').textContent = `${t.centroVenta} · ${t.mesa}`;
        $('rp-p-et').textContent = `${t.etiqueta ? t.etiqueta + ' · ' : ''}Transacción #${t.ticketId} · ${t.usuario || 'sin usuario'}`;
        $('rp-p-pre').hidden = !t.precuenta;
        $('rp-p-total').textContent = moneda(t.total);
        const q = new URLSearchParams({ ticket: t.globalId, centro: t.saleCenterId, ubicacion: t.mesa, boton: '1' });
        if (caja) q.set('pos_id', caja);
        $('rp-marco').src = '/cobro/ticket?' + q.toString();
        $('rp-panel').classList.add('abierto'); $('rp-panel').setAttribute('aria-hidden', 'false');
        $('rp-velo').hidden = false;
        lista();
    }
    function cerrar() {
        abierto = null;
        $('rp-panel').classList.remove('abierto'); $('rp-panel').setAttribute('aria-hidden', 'true');
        $('rp-velo').hidden = true;
        $('rp-marco').src = 'about:blank';
        lista();
    }

    // El cobro avisa por mensaje: "Volver" (applyFlow none) o cobro terminado (afterClose).
    window.addEventListener('message', e => {
        if (e.origin !== location.origin || !e.data || e.data.type !== 'agora:pos:close-window' || !abierto) return;
        const t = abierto;
        if (e.data.applyFlow === 'afterClose') {
            tickets = tickets.filter(x => x.globalId !== t.globalId);
            ocupadoHasta = Date.now() + 2500;
            cerrar(); armarTeclado(); todo();
            toast(`Cuenta cobrada · ${t.mesa} · ${moneda(t.total)}`, true);
            setTimeout(() => actualizar(true), 2600);
        } else {
            cerrar();
            actualizar(false);
        }
    });

    // ---------------------------------------------------------------- eventos
    document.addEventListener('click', e => {
        const b = e.target.closest('button'); if (!b) return;
        if (b.dataset.a) { area = b.dataset.a; todo(); return; }
        if (b.dataset.u) { usuario = b.dataset.u; todo(); return; }
        if (b.dataset.e) { estado = b.dataset.e; todo(); return; }
        if (b.dataset.o) { orden = b.dataset.o; document.querySelectorAll('.rp-orden button').forEach(x => x.classList.toggle('on', x === b)); lista(); return; }
        if (b.classList.contains('rp-cta')) { const t = tickets.find(x => x.globalId === b.dataset.id); if (t) abrir(t); return; }
        if (b.id === 'rp-volver') { cerrar(); actualizar(true); return; }
        if (b.id === 'rp-limpiar') { busca = ''; $('rp-q').value = ''; todo(); return; }
        if (b.id === 'rp-act') { actualizar(true); return; }
        if (b.id === 'rp-tecl') { const on = $('rp-teclado').classList.toggle('on'); b.classList.toggle('on', on); b.setAttribute('aria-pressed', on); return; }
        if (b.dataset.k) {
            const k = b.dataset.k;
            if (k === 'DEL') busca = busca.slice(0, -1); else if (k === 'C') busca = ''; else busca += k;
            $('rp-q').value = busca; todo();
        }
    });
    $('rp-velo').addEventListener('click', () => { cerrar(); actualizar(true); });
    $('rp-q').addEventListener('input', function () { busca = this.value.trim(); todo(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && abierto) { cerrar(); actualizar(true); } });

    armarTeclado();
    todo();
    vivo();
    if (raiz.dataset.error) aviso(raiz.dataset.error);
    setInterval(() => actualizar(false), 10000);
    setInterval(vivo, 1000);
})();
