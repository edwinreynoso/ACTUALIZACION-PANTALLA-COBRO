-- 120_cobro_rapido.sql
-- Cobro rapido: las cuentas abiertas de todas las areas de negocio, con la etiqueta de la mesa, el usuario asignado, el total y si ya
-- pidieron la precuenta (el cliente esta por pagar). Solo lectura. No lleva variables del instalador.
--   Precuenta = la pantalla de precuentas ya registro una para esa cuenta (LetPrecuenta) o Agora la imprimio (Ticket.PrintCount > 0).
--   Se listan las cuentas con consumo que no estan congeladas (las congeladas ya estan en medio de un cobro en Agora).

IF OBJECT_ID(N'[dbo].[LetCobroRapidoTickets]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetCobroRapidoTickets] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetCobroRapidoTickets]
AS
BEGIN
    SET NOCOUNT ON;
    SELECT CONVERT(VARCHAR(36), t.GlobalId) AS GlobalId,
           t.Id AS TicketId,
           t.SaleCenterId,
           ISNULL(t.SaleCenterName, N'') AS CentroVenta,
           ISNULL(t.SaleLocationName, N'') AS Mesa,
           ISNULL(t.FriendlyName, N'') AS Etiqueta,
           ISNULL(NULLIF(op.Name, N''), N'') AS Usuario,
           t.OpenerUserId AS UsuarioId,
           CASE WHEN t.CurrentUserId IS NULL THEN CAST(0 AS BIT) ELSE CAST(1 AS BIT) END AS EnUso,
           t.CreationDate AS Creacion,
           CASE WHEN DATEDIFF(MINUTE, t.CreationDate, GETDATE()) < 0 THEN 0 ELSE DATEDIFF(MINUTE, t.CreationDate, GETDATE()) END AS Minutos,
           CONVERT(DECIMAL(12,2), t.Net) AS Total,
           CASE WHEN p.TicketId IS NOT NULL OR ISNULL(t.PrintCount, 0) > 0 THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT) END AS Precuenta,
           p.Fecha AS FechaPrecuenta,
           CASE WHEN p.Fecha IS NULL THEN NULL
                WHEN DATEDIFF(MINUTE, p.Fecha, GETDATE()) < 0 THEN 0
                ELSE DATEDIFF(MINUTE, p.Fecha, GETDATE()) END AS MinutosPrecuenta
      FROM dbo.Ticket t
      LEFT JOIN dbo.[User] op ON op.Id = t.OpenerUserId
     OUTER APPLY (SELECT TOP (1) x.TicketId, x.Fecha
                    FROM dbo.LetPrecuenta x
                   WHERE x.TicketId = t.Id AND x.Fecha >= DATEADD(MINUTE, -5, t.CreationDate)
                   ORDER BY x.Id DESC) p
     WHERE t.FrozenDate IS NULL
       AND EXISTS (SELECT 1 FROM dbo.TicketLine l WHERE l.TicketId = t.Id AND l.IsCancelled = 0)
     ORDER BY t.CreationDate, t.Id;
END
GO
