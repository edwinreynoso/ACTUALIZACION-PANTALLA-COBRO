/* =====================================================================================================
   123_cuadre_informe.sql  -  Secciones OPCIONALES del ticket del cuadre de caja. Solo lee.
   dbo.LetCuadreInforme(@PosId, @Desde, @Hasta, @Secciones, @Max): lo que paso en esa caja entre la apertura del turno y la hora del cuadre.
   @Secciones es una lista separada por comas con lo que se pide (las demas salen vacias y no se consultan):
     productos   1) ventas por producto: cantidad y monto (los mas vendidos primero, hasta @Max)
     categorias  2) ventas por categoria (familia de Agora): cantidad, monto y porcentaje
     anulaciones 3) lineas anuladas: producto, cantidad, monto, motivo, quien y en que mesa
     devoluciones 4) notas de credito / devoluciones del periodo
     mesas       5) cuentas que SIGUEN ABIERTAS ahora: mesa, etiqueta, usuario y monto (no depende de la caja)
     efectivo    6) movimientos de efectivo (entradas y salidas de caja)
   Los montos de venta son los de la factura de Agora (NetAmount, con impuestos y propina). No lleva variables del instalador.
   ===================================================================================================== */
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'dbo.LetCuadreInforme') IS NULL EXEC (N'CREATE PROCEDURE dbo.LetCuadreInforme AS RETURN 0')
GO
ALTER PROCEDURE dbo.LetCuadreInforme @PosId INT, @Desde DATETIME, @Hasta DATETIME, @Secciones VARCHAR(200) = '', @Max INT = 40
AS
BEGIN
    SET NOCOUNT ON;
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    DECLARE @S VARCHAR(220) = ',' + REPLACE(ISNULL(@Secciones, ''), ' ', '') + ',';
    IF @Max IS NULL OR @Max < 1 SET @Max = 40;
    IF @Max > 200 SET @Max = 200;

    /* 1) Ventas por producto */
    IF CHARINDEX(',productos,', @S) > 0
        SELECT TOP (@Max) d.SaleFormatName AS Producto, SUM(d.Quantity) AS Cantidad, SUM(d.NetAmount) AS Monto
          FROM dbo.InvoiceLineDetails d
         WHERE d.IsLine = 1 AND d.PosId = @PosId AND d.InvoiceCreationDate >= @Desde AND d.InvoiceCreationDate <= @Hasta AND d.NetAmount >= 0
         GROUP BY d.SaleFormatName
         ORDER BY SUM(d.NetAmount) DESC, d.SaleFormatName;
    ELSE SELECT CAST(NULL AS NVARCHAR(200)) AS Producto, CAST(NULL AS DECIMAL(18,2)) AS Cantidad, CAST(NULL AS DECIMAL(18,2)) AS Monto WHERE 1 = 0;

    /* 2) Ventas por categoria (familia) */
    IF CHARINDEX(',categorias,', @S) > 0
        SELECT ISNULL(NULLIF(LTRIM(RTRIM(d.Family)), N''), N'(sin categoria)') AS Categoria, SUM(d.Quantity) AS Cantidad, SUM(d.NetAmount) AS Monto
          FROM dbo.InvoiceLineDetails d
         WHERE d.IsLine = 1 AND d.PosId = @PosId AND d.InvoiceCreationDate >= @Desde AND d.InvoiceCreationDate <= @Hasta AND d.NetAmount >= 0
         GROUP BY ISNULL(NULLIF(LTRIM(RTRIM(d.Family)), N''), N'(sin categoria)')
         ORDER BY SUM(d.NetAmount) DESC;
    ELSE SELECT CAST(NULL AS NVARCHAR(200)) AS Categoria, CAST(NULL AS DECIMAL(18,2)) AS Cantidad, CAST(NULL AS DECIMAL(18,2)) AS Monto WHERE 1 = 0;

    /* 3) Lineas anuladas del periodo en esa caja */
    IF CHARINDEX(',anulaciones,', @S) > 0
        SELECT TOP (200) l.ProductName AS Producto, ABS(l.Quantity) AS Cantidad, ABS(l.TotalAmount) AS Monto, ISNULL(l.CancelReason, N'') AS Motivo,
               ISNULL(u.Name, N'') AS Usuario, ISNULL(t.SaleLocationName, N'') AS Mesa, ISNULL(t.FriendlyName, N'') AS Etiqueta, l.CancelledAt AS Hora
          FROM dbo.TicketLine l
          JOIN dbo.Ticket t ON t.Id = l.TicketId
          LEFT JOIN dbo.[User] u ON u.Id = l.CancelUserId
         WHERE l.IsCancelled = 1 AND t.OpenerPosId = @PosId AND l.CancelledAt >= @Desde AND l.CancelledAt <= @Hasta
         ORDER BY l.CancelledAt;
    ELSE SELECT CAST(NULL AS NVARCHAR(200)) AS Producto, CAST(NULL AS DECIMAL(18,2)) AS Cantidad, CAST(NULL AS DECIMAL(18,2)) AS Monto, CAST(NULL AS NVARCHAR(200)) AS Motivo,
                CAST(NULL AS NVARCHAR(100)) AS Usuario, CAST(NULL AS NVARCHAR(100)) AS Mesa, CAST(NULL AS NVARCHAR(100)) AS Etiqueta, CAST(NULL AS DATETIME) AS Hora WHERE 1 = 0;

    /* 4) Devoluciones y notas de credito (facturas negativas) del periodo en esa caja */
    IF CHARINDEX(',devoluciones,', @S) > 0
        SELECT TOP (200) i.Serie + N'-' + CONVERT(NVARCHAR(12), i.Number) AS Documento, ABS(i.Net) AS Monto,
               ISNULL(o.Serie + N'-' + CONVERT(NVARCHAR(12), o.Number), N'') AS Afecta, ISNULL(u.Name, N'') AS Usuario, i.CreationDate AS Hora
          FROM dbo.Invoice i
          LEFT JOIN dbo.Invoice o ON o.Id = i.RelatedInvoiceId
          LEFT JOIN dbo.[User] u ON u.Id = i.UserId
         WHERE i.Net < 0 AND i.PosId = @PosId AND i.CreationDate >= @Desde AND i.CreationDate <= @Hasta
         ORDER BY i.CreationDate;
    ELSE SELECT CAST(NULL AS NVARCHAR(40)) AS Documento, CAST(NULL AS DECIMAL(18,2)) AS Monto, CAST(NULL AS NVARCHAR(40)) AS Afecta, CAST(NULL AS NVARCHAR(100)) AS Usuario, CAST(NULL AS DATETIME) AS Hora WHERE 1 = 0;

    /* 5) Cuentas que siguen abiertas (de todo el negocio): mesa, etiqueta, usuario y monto */
    IF CHARINDEX(',mesas,', @S) > 0
        SELECT TOP (200) ISNULL(t.SaleCenterName, N'') AS Area, ISNULL(t.SaleLocationName, N'') AS Mesa, ISNULL(t.FriendlyName, N'') AS Etiqueta, ISNULL(u.Name, N'') AS Usuario,
               CONVERT(DECIMAL(18,2), t.Net) AS Monto, t.CreationDate AS Apertura
          FROM dbo.Ticket t
          LEFT JOIN dbo.[User] u ON u.Id = t.OpenerUserId
         WHERE t.FrozenDate IS NULL AND EXISTS (SELECT 1 FROM dbo.TicketLine l WHERE l.TicketId = t.Id AND l.IsCancelled = 0)
         ORDER BY t.SaleCenterName, t.SaleLocationName, t.Id;
    ELSE SELECT CAST(NULL AS NVARCHAR(100)) AS Area, CAST(NULL AS NVARCHAR(100)) AS Mesa, CAST(NULL AS NVARCHAR(100)) AS Etiqueta, CAST(NULL AS NVARCHAR(100)) AS Usuario,
                CAST(NULL AS DECIMAL(18,2)) AS Monto, CAST(NULL AS DATETIME) AS Apertura WHERE 1 = 0;

    /* 6) Movimientos de efectivo de la caja en el periodo (el signo es el que guarda Agora: negativo = sale de la caja) */
    IF CHARINDEX(',efectivo,', @S) > 0 AND OBJECT_ID(N'dbo.CashTransaction', N'U') IS NOT NULL
        EXEC sp_executesql N'SELECT TOP (200) ISNULL(c.Description, N'''') AS Descripcion, ISNULL(c.Provider, N'''') AS Proveedor, CONVERT(DECIMAL(18,2), c.Amount) AS Monto, ISNULL(u.Name, N'''') AS Usuario, c.Date AS Hora
                               FROM dbo.CashTransaction c LEFT JOIN dbo.[User] u ON u.Id = c.UserId
                              WHERE c.PosId = @p AND c.Date >= @d AND c.Date <= @h ORDER BY c.Date',
                            N'@p INT, @d DATETIME, @h DATETIME', @PosId, @Desde, @Hasta;
    ELSE SELECT CAST(NULL AS NVARCHAR(200)) AS Descripcion, CAST(NULL AS NVARCHAR(200)) AS Proveedor, CAST(NULL AS DECIMAL(18,2)) AS Monto, CAST(NULL AS NVARCHAR(100)) AS Usuario, CAST(NULL AS DATETIME) AS Hora WHERE 1 = 0;
END
GO
