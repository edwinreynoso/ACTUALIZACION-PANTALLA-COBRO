﻿-- 118_cierre_agora.sql
-- Cerrar la JORNADA de Agora desde el cuadre de caja (OPCIONAL, apagado por defecto). No escribe en las tablas de cierre de Agora: adelanta unos minutos la hora del
-- CIERRE AUTOMATICO de Agora (dbo.Workplace.AutoCloseTime) para que sea el propio servidor de Agora quien cierre la jornada, con su logica completa (turno, saldos, informe,
-- auditoria "Forzado cierre de jornada"), y devuelve esa hora a su valor original en cuanto cierra (o a los 12 minutos si no cerro). Nunca deja la hora cambiada:
-- LetCierreAgoraRevisar (que llama el servicio cada pocos segundos) la restaura y solo lo hace si nadie mas la cambio. No lleva variables del instalador.

IF COL_LENGTH(N'dbo.LetCuadreConfig', N'CierreAgora') IS NULL
    ALTER TABLE dbo.LetCuadreConfig ADD CierreAgora BIT NOT NULL CONSTRAINT DF_LetCuadreConfig_CierreAgora DEFAULT (0)
GO

IF OBJECT_ID(N'dbo.LetCierreAgora', N'U') IS NULL
CREATE TABLE dbo.LetCierreAgora (
    Id            INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_LetCierreAgora PRIMARY KEY,
    CuadreId      INT           NOT NULL,
    Usuario       NVARCHAR(100) NULL,
    WorkplaceId   INT           NOT NULL,
    JornadaId     INT           NOT NULL,                -- dbo.SystemCloseOut.Id de la jornada que se cierra
    HoraOriginal  DATETIME      NULL,                    -- AutoCloseTime antes del cambio (se restaura)
    HoraPuesta    DATETIME      NULL,                    -- la que se puso para adelantar el cierre
    Solicitada    DATETIME      NOT NULL CONSTRAINT DF_LetCierreAgora_Solicitada DEFAULT (GETDATE()),
    Estado        VARCHAR(10)   NOT NULL,                -- PENDIENTE, CERRADA o VENCIDA
    Cerrada       DATETIME      NULL,                    -- cuando cerro Agora
    Restaurada    BIT           NOT NULL CONSTRAINT DF_LetCierreAgora_Restaurada DEFAULT (0),
    Resuelta      DATETIME      NULL
)
GO

-- Los avisos de siempre: LetCuadreActivo devuelve Activo (primera columna, como antes) y ahora tambien CierreAgora.
IF OBJECT_ID(N'[dbo].[LetCuadreActivo]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetCuadreActivo] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetCuadreActivo]
AS
BEGIN
    SET NOCOUNT ON;
    SELECT CAST(ISNULL((SELECT Activo FROM dbo.LetCuadreConfig WHERE Id = 1), 0) AS BIT) AS Activo,
           CAST(ISNULL((SELECT CierreAgora FROM dbo.LetCuadreConfig WHERE Id = 1), 0) AS BIT) AS CierreAgora;
END
GO

IF OBJECT_ID(N'[dbo].[LetCuadreCierreAgoraConfigurar]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetCuadreCierreAgoraConfigurar] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetCuadreCierreAgoraConfigurar] (@Activo BIT)
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE dbo.LetCuadreConfig SET CierreAgora = @Activo, Cambio = GETDATE() WHERE Id = 1;
    IF @@ROWCOUNT = 0 INSERT dbo.LetCuadreConfig (Id, Activo, CierreAgora) VALUES (1, 0, @Activo);
    SELECT CAST(1 AS BIT) AS Ok, CASE WHEN @Activo = 1 THEN N'Cierre de la jornada de Agora desde el cuadre ACTIVADO' ELSE N'Cierre de la jornada de Agora desde el cuadre DESACTIVADO: se cierra en Agora como siempre' END AS Mensaje;
END
GO

-- Lo que la pantalla necesita saber: si el cierre en Agora esta activo, a que hora cierra Agora solo y cuantos tickets abiertos hay.
IF OBJECT_ID(N'[dbo].[LetCuadreOpciones]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetCuadreOpciones] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetCuadreOpciones]
AS
BEGIN
    SET NOCOUNT ON;
    SELECT CAST(ISNULL((SELECT Activo FROM dbo.LetCuadreConfig WHERE Id = 1), 0) AS BIT) AS Activo,
           CAST(ISNULL((SELECT CierreAgora FROM dbo.LetCuadreConfig WHERE Id = 1), 0) AS BIT) AS CierreAgora,
           (SELECT TOP (1) CONVERT(VARCHAR(5), AutoCloseTime, 108) FROM dbo.Workplace ORDER BY Id) AS HoraAuto,
           (SELECT COUNT(*) FROM dbo.Ticket) AS TicketsAbiertos,
           (SELECT TOP (1) CAST(BusinessDay AS DATE) FROM dbo.SystemCloseOut WHERE CloseDate IS NULL ORDER BY Id DESC) AS JornadaAbierta;
END
GO

-- Restaura la hora del cierre automatico cuando Agora ya cerro la jornada (o cuando pasaron 12 minutos). Solo la restaura si todavia vale la que se puso
-- (si alguien la cambio a mano, no se toca). Es barata: el servicio la llama cada pocos segundos y tambien al ver el estado.
IF OBJECT_ID(N'[dbo].[LetCierreAgoraRevisar]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetCierreAgoraRevisar] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetCierreAgoraRevisar]
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM dbo.LetCierreAgora WHERE Estado = 'PENDIENTE') RETURN;
    DECLARE @Id INT, @W INT, @Orig DATETIME, @Puesta DATETIME, @J INT, @Sol DATETIME, @Cerrada DATETIME, @Filas INT;
    DECLARE cur CURSOR LOCAL FAST_FORWARD FOR
        SELECT Id, WorkplaceId, HoraOriginal, HoraPuesta, JornadaId, Solicitada FROM dbo.LetCierreAgora WHERE Estado = 'PENDIENTE' ORDER BY Id;
    OPEN cur; FETCH NEXT FROM cur INTO @Id, @W, @Orig, @Puesta, @J, @Sol;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SELECT @Cerrada = CloseDate FROM dbo.SystemCloseOut WHERE Id = @J;
        IF @Cerrada IS NOT NULL OR DATEDIFF(MINUTE, @Sol, GETDATE()) >= 12
        BEGIN
            UPDATE dbo.Workplace SET AutoCloseTime = @Orig WHERE Id = @W AND ISNULL(AutoCloseTime, '19000101') = ISNULL(@Puesta, '19000101');
            SET @Filas = @@ROWCOUNT;
            UPDATE dbo.LetCierreAgora SET Estado = CASE WHEN @Cerrada IS NOT NULL THEN 'CERRADA' ELSE 'VENCIDA' END, Cerrada = @Cerrada, Restaurada = CASE WHEN @Filas > 0 THEN 1 ELSE 0 END, Resuelta = GETDATE() WHERE Id = @Id;
        END
        FETCH NEXT FROM cur INTO @Id, @W, @Orig, @Puesta, @J, @Sol;
    END
    CLOSE cur; DEALLOCATE cur;
END
GO

-- Pide el cierre: valida la contrasena del POS, que el cuadre sea de JORNADA, reciente y de la jornada que esta abierta en Agora, y adelanta 2 minutos el cierre automatico.
IF OBJECT_ID(N'[dbo].[LetCierreAgoraSolicitar]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetCierreAgoraSolicitar] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetCierreAgoraSolicitar] (@CuadreId INT, @Pin NVARCHAR(40))
AS
BEGIN
    SET NOCOUNT ON;
    EXEC dbo.LetCierreAgoraRevisar;
    IF ISNULL((SELECT CierreAgora FROM dbo.LetCuadreConfig WHERE Id = 1), 0) = 0
    BEGIN SELECT CAST(0 AS BIT) AS Ok, N'El cierre de la jornada de Agora desde el cuadre no esta activado' AS Mensaje, CAST(NULL AS INT) AS Id; RETURN; END

    DECLARE @U TABLE (Ok BIT, UsuarioId INT, Usuario NVARCHAR(100), Mensaje NVARCHAR(200));
    INSERT @U EXEC dbo.LetCuadreUsuario @Pin;
    DECLARE @Usuario NVARCHAR(100) = (SELECT Usuario FROM @U WHERE Ok = 1);
    IF @Usuario IS NULL
    BEGIN SELECT CAST(0 AS BIT) AS Ok, ISNULL((SELECT TOP (1) Mensaje FROM @U), N'Contrasena incorrecta') AS Mensaje, CAST(NULL AS INT) AS Id; RETURN; END

    DECLARE @Tipo VARCHAR(10), @Jornada DATE, @Fecha DATETIME;
    SELECT @Tipo = Tipo, @Jornada = Jornada, @Fecha = Fecha FROM dbo.LetCuadre WHERE Id = @CuadreId;
    IF @Tipo IS NULL BEGIN SELECT CAST(0 AS BIT) AS Ok, N'No existe ese cuadre' AS Mensaje, CAST(NULL AS INT) AS Id; RETURN; END
    IF @Tipo <> 'JORNADA' BEGIN SELECT CAST(0 AS BIT) AS Ok, N'Solo un cuadre de cierre de jornada puede cerrar la jornada en Agora' AS Mensaje, CAST(NULL AS INT) AS Id; RETURN; END
    IF @Fecha < DATEADD(HOUR, -6, GETDATE()) BEGIN SELECT CAST(0 AS BIT) AS Ok, N'Ese cuadre es de hace mas de 6 horas: haga uno nuevo' AS Mensaje, CAST(NULL AS INT) AS Id; RETURN; END

    DECLARE @J INT, @JDia DATE;
    SELECT TOP (1) @J = Id, @JDia = CAST(BusinessDay AS DATE) FROM dbo.SystemCloseOut WHERE CloseDate IS NULL ORDER BY Id DESC;
    IF @J IS NULL BEGIN SELECT CAST(0 AS BIT) AS Ok, N'No hay una jornada abierta en Agora (ya esta cerrada)' AS Mensaje, CAST(NULL AS INT) AS Id; RETURN; END
    IF @JDia <> @Jornada BEGIN SELECT CAST(0 AS BIT) AS Ok, N'El cuadre es de otra jornada distinta de la que esta abierta en Agora' AS Mensaje, CAST(NULL AS INT) AS Id; RETURN; END

    DECLARE @Pend INT = (SELECT TOP (1) Id FROM dbo.LetCierreAgora WHERE Estado = 'PENDIENTE' ORDER BY Id DESC);
    IF @Pend IS NOT NULL BEGIN SELECT CAST(1 AS BIT) AS Ok, N'Ya hay un cierre en curso: Agora cerrara la jornada en un momento' AS Mensaje, @Pend AS Id; RETURN; END

    DECLARE @W INT, @Orig DATETIME;
    SELECT TOP (1) @W = Id, @Orig = AutoCloseTime FROM dbo.Workplace ORDER BY Id;
    IF @W IS NULL BEGIN SELECT CAST(0 AS BIT) AS Ok, N'No se encontro el lugar de trabajo de Agora' AS Mensaje, CAST(NULL AS INT) AS Id; RETURN; END
    DECLARE @Nueva DATETIME = CAST('1900-01-01 ' + CONVERT(CHAR(8), DATEADD(MINUTE, 2, GETDATE()), 108) AS DATETIME);

    DECLARE @Nuevo INT;
    BEGIN TRANSACTION;
    UPDATE dbo.Workplace SET AutoCloseTime = @Nueva WHERE Id = @W;
    INSERT dbo.LetCierreAgora (CuadreId, Usuario, WorkplaceId, JornadaId, HoraOriginal, HoraPuesta, Estado) VALUES (@CuadreId, @Usuario, @W, @J, @Orig, @Nueva, 'PENDIENTE');
    SET @Nuevo = SCOPE_IDENTITY();
    COMMIT;
    SELECT CAST(1 AS BIT) AS Ok, N'Agora cerrara la jornada en un par de minutos' AS Mensaje, @Nuevo AS Id;
END
GO

-- El estado de un cierre (primero revisa y restaura si ya cerro).
IF OBJECT_ID(N'[dbo].[LetCierreAgoraEstado]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetCierreAgoraEstado] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetCierreAgoraEstado] (@Id INT)
AS
BEGIN
    SET NOCOUNT ON;
    EXEC dbo.LetCierreAgoraRevisar;
    SELECT Id, Estado, Solicitada, Cerrada, Restaurada,
           CASE Estado WHEN 'PENDIENTE' THEN N'Esperando a que Agora cierre la jornada...'
                       WHEN 'CERRADA' THEN N'Agora cerro la jornada'
                       ELSE N'Agora no cerro la jornada en 12 minutos: se restauro la hora del cierre automatico. Cierrela en el POS de Agora' END AS Mensaje
      FROM dbo.LetCierreAgora WHERE Id = @Id;
END
GO
