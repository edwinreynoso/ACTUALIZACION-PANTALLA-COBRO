/* =====================================================================================================
   126_emisor_portal.sql  -  Datos del emisor (cabecera de las facturas) editables desde el portal /admin.
   dbo.LetEmisorLeer: la fila de dbo.LetEmisor (y si tiene logo). dbo.LetEmisorGuardar: crea o actualiza esa fila.
   El logo no se toca aqui (se carga con el instalador). Sin nombre comercial ni razon social el servicio usa la empresa de Agora.
   No lleva variables del instalador.
   ===================================================================================================== */
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'[dbo].[LetEmisorLeer]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetEmisorLeer] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetEmisorLeer]
AS
BEGIN
    SET NOCOUNT ON;
    SELECT TOP (1) NombreComercial, RazonSocial, RNC, Sucursal, Direccion, Telefono, CAST(CASE WHEN Logo IS NULL THEN 0 ELSE 1 END AS BIT) AS TieneLogo
      FROM dbo.LetEmisor WHERE Id = 1;
END
GO

IF OBJECT_ID(N'[dbo].[LetEmisorGuardar]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetEmisorGuardar] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetEmisorGuardar] (@NombreComercial NVARCHAR(150), @RazonSocial NVARCHAR(150), @RNC VARCHAR(20), @Sucursal NVARCHAR(100), @Direccion NVARCHAR(300), @Telefono NVARCHAR(50))
AS
BEGIN
    SET NOCOUNT ON;
    SET @RNC = REPLACE(REPLACE(LTRIM(RTRIM(ISNULL(@RNC, ''))), '-', ''), ' ', '');
    IF @RNC <> '' AND (@RNC LIKE '%[^0-9]%' OR LEN(@RNC) NOT IN (9, 11))
    BEGIN SELECT CAST(0 AS BIT) AS Ok, N'El RNC debe tener 9 digitos (empresa) u 11 (cedula)' AS Mensaje; RETURN; END
    IF NOT EXISTS (SELECT 1 FROM dbo.LetEmisor WHERE Id = 1) INSERT dbo.LetEmisor (Id) VALUES (1);
    UPDATE dbo.LetEmisor
       SET NombreComercial = NULLIF(LTRIM(RTRIM(ISNULL(@NombreComercial, N''))), N''), RazonSocial = NULLIF(LTRIM(RTRIM(ISNULL(@RazonSocial, N''))), N''),
           RNC = NULLIF(@RNC, ''), Sucursal = NULLIF(LTRIM(RTRIM(ISNULL(@Sucursal, N''))), N''),
           Direccion = NULLIF(LTRIM(RTRIM(ISNULL(@Direccion, N''))), N''), Telefono = NULLIF(LTRIM(RTRIM(ISNULL(@Telefono, N''))), N'')
     WHERE Id = 1;
    SELECT CAST(1 AS BIT) AS Ok, N'Datos del emisor guardados: se usan desde la siguiente factura' AS Mensaje;
END
GO
