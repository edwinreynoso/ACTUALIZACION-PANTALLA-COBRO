﻿-- 113_admin_siempre.sql
-- El usuario admin del portal siempre es administrador activo: LetAdminAutenticar lo deja entrar como ADMIN con su PIN aunque se hayan cambiado sus permisos,
-- y LetAdminUsuarioGuardar no permite quitarle el rol ni desactivarlo. Misma definicion que 092_admin.sql, repetida para que una actualizacion desde el portal la aplique.
IF OBJECT_ID(N'dbo.LetAdminAutenticar') IS NULL EXEC (N'CREATE PROCEDURE dbo.LetAdminAutenticar AS RETURN 0')
GO
ALTER PROCEDURE dbo.LetAdminAutenticar @Usuario NVARCHAR(100), @Pin NVARCHAR(40)
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Id INT, @Salt VARBINARY(16), @Hash VARBINARY(32), @Adm BIT, @Ver BIT, @Hasta DATETIME, @Activo BIT;
    SELECT @Id = Id, @Salt = PinSalt, @Hash = PinHash, @Adm = PuedeAdministrar, @Ver = PuedeVerAdmin, @Hasta = BloqueadoHasta, @Activo = Activo
      FROM dbo.LetFlujoInternoUsuario WHERE UsuarioAgora = LTRIM(RTRIM(ISNULL(@Usuario, N'')));
    -- El usuario admin siempre es administrador activo: nada de lo que se cambie en los permisos lo limita (solo su PIN lo protege).
    DECLARE @EsAdmin BIT = CASE WHEN LOWER(LTRIM(RTRIM(ISNULL(@Usuario, N'')))) = N'admin' THEN 1 ELSE 0 END;
    IF @EsAdmin = 1 SELECT @Activo = 1, @Adm = 1;
    IF @Id IS NULL OR @Activo = 0 OR @Hash IS NULL BEGIN SELECT CAST(0 AS BIT) AS Ok, CAST('' AS VARCHAR(10)) AS Rol, N'Usuario o PIN incorrectos' AS Mensaje; RETURN; END
    IF @Hasta IS NOT NULL AND @Hasta > GETDATE() BEGIN SELECT CAST(0 AS BIT) AS Ok, CAST('' AS VARCHAR(10)) AS Rol, N'Usuario bloqueado por intentos fallidos: espere unos minutos' AS Mensaje; RETURN; END
    IF HASHBYTES('SHA2_256', @Salt + CAST(ISNULL(@Pin, N'') AS VARBINARY(80))) <> @Hash
    BEGIN
        UPDATE dbo.LetFlujoInternoUsuario
           SET BloqueadoHasta = CASE WHEN Fallos + 1 >= 5 THEN DATEADD(MINUTE, 15, GETDATE()) ELSE BloqueadoHasta END,
               Fallos = CASE WHEN Fallos + 1 >= 5 THEN 0 ELSE Fallos + 1 END
         WHERE Id = @Id;
        SELECT CAST(0 AS BIT) AS Ok, CAST('' AS VARCHAR(10)) AS Rol, N'Usuario o PIN incorrectos' AS Mensaje; RETURN;
    END
    IF @Adm = 0 AND @Ver = 0 BEGIN SELECT CAST(0 AS BIT) AS Ok, CAST('' AS VARCHAR(10)) AS Rol, N'El usuario no tiene acceso al portal de administracion' AS Mensaje; RETURN; END
    UPDATE dbo.LetFlujoInternoUsuario SET Fallos = 0, BloqueadoHasta = NULL,
           PuedeAdministrar = CASE WHEN @EsAdmin = 1 THEN 1 ELSE PuedeAdministrar END, Activo = CASE WHEN @EsAdmin = 1 THEN 1 ELSE Activo END WHERE Id = @Id;
    SELECT CAST(1 AS BIT) AS Ok, CAST(CASE WHEN @Adm = 1 THEN 'ADMIN' ELSE 'LECTURA' END AS VARCHAR(10)) AS Rol, N'' AS Mensaje;
END
GO

IF OBJECT_ID(N'dbo.LetAdminUsuarioGuardar') IS NULL EXEC (N'CREATE PROCEDURE dbo.LetAdminUsuarioGuardar AS RETURN 0')
GO
ALTER PROCEDURE dbo.LetAdminUsuarioGuardar
    @Usuario NVARCHAR(100),
    @Pin NVARCHAR(40) = NULL,
    @PuedeUsar BIT = NULL,          -- NULL = conservar lo que ya tiene (0 si es nuevo)
    @PuedeFiscalizar BIT = NULL,
    @PuedeCambiarTasa BIT = NULL,
    @PuedeAdministrar BIT = NULL,
    @PuedeVerAdmin BIT = NULL,
    @Activo BIT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET @Usuario = LTRIM(RTRIM(ISNULL(@Usuario, N'')));
    -- El usuario admin siempre es administrador activo: no se puede limitar ni desactivar (si se cambia su PIN, si).
    IF LOWER(@Usuario) = N'admin' AND (@PuedeAdministrar = 0 OR @Activo = 0)
    BEGIN SELECT CAST(0 AS BIT) AS Ok, N'El usuario admin siempre es administrador: no se puede limitar ni desactivar' AS Mensaje; RETURN; END
    SELECT @PuedeUsar = ISNULL(@PuedeUsar, PuedeUsar), @PuedeFiscalizar = ISNULL(@PuedeFiscalizar, PuedeFiscalizar), @PuedeCambiarTasa = ISNULL(@PuedeCambiarTasa, PuedeCambiarTasa),
           @PuedeAdministrar = ISNULL(@PuedeAdministrar, PuedeAdministrar), @PuedeVerAdmin = ISNULL(@PuedeVerAdmin, PuedeVerAdmin), @Activo = ISNULL(@Activo, Activo)
      FROM dbo.LetFlujoInternoUsuario WHERE UsuarioAgora = @Usuario;
    SELECT @PuedeUsar = ISNULL(@PuedeUsar, 0), @PuedeFiscalizar = ISNULL(@PuedeFiscalizar, 0), @PuedeCambiarTasa = ISNULL(@PuedeCambiarTasa, 0),
           @PuedeAdministrar = ISNULL(@PuedeAdministrar, 0), @PuedeVerAdmin = ISNULL(@PuedeVerAdmin, 0), @Activo = ISNULL(@Activo, 1);
    IF LOWER(@Usuario) = N'admin' SELECT @PuedeAdministrar = 1, @Activo = 1;
    -- Dejaria sin administradores activos?
    IF EXISTS (SELECT 1 FROM dbo.LetFlujoInternoUsuario WHERE UsuarioAgora = @Usuario AND PuedeAdministrar = 1 AND Activo = 1)
       AND (@PuedeAdministrar = 0 OR @Activo = 0)
       AND NOT EXISTS (SELECT 1 FROM dbo.LetFlujoInternoUsuario WHERE UsuarioAgora <> @Usuario AND PuedeAdministrar = 1 AND Activo = 1 AND PinHash IS NOT NULL)
    BEGIN SELECT CAST(0 AS BIT) AS Ok, N'Tiene que quedar al menos un administrador activo' AS Mensaje; RETURN; END

    CREATE TABLE #r (Ok BIT, Mensaje NVARCHAR(200));
    INSERT #r EXEC dbo.LetFlujoInternoUsuarioGuardar @Usuario, @PuedeUsar, @PuedeFiscalizar, @Pin, @Activo, @PuedeCambiarTasa;
    DECLARE @Ok BIT, @Msg NVARCHAR(200);
    SELECT TOP (1) @Ok = Ok, @Msg = Mensaje FROM #r;
    IF @Ok = 1
        UPDATE dbo.LetFlujoInternoUsuario SET PuedeAdministrar = @PuedeAdministrar, PuedeVerAdmin = @PuedeVerAdmin WHERE UsuarioAgora = @Usuario;
    SELECT @Ok AS Ok, @Msg AS Mensaje;
END
GO
