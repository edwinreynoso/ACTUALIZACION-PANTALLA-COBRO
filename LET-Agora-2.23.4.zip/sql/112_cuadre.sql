﻿-- 112_cuadre.sql
-- Cuadre de caja con declaracion por moneda (OPCIONAL, apagado por defecto). Solo escribe tablas propias de LET: no toca el cierre de Agora.
--   LetCuadreConfig   : el interruptor (Activo = 0 -> la herramienta y el cierre de Agora funcionan como siempre).
--   LetCuadre         : un cuadre (turno X o jornada) con quien lo hizo, el comentario y si cuadro.
--   LetCuadreLinea    : lo esperado (cinta de cierre) y lo declarado de cada forma de pago.
--   LetCuadreUsuario  : valida la contrasena que el cajero usa en el POS de Agora (dbo.User.Password); 5 fallos en 15 minutos bloquean 15 minutos (LetCuadreFallo).
--   LetCuadreCalcular / LetCuadreEsperado : la cinta del turno, lo que cada forma de pago debe tener segun las ventas.
--   LetCuadreGuardar / LetCuadreLeer      : guarda la declaracion (texto metodo:monto) y devuelve el cuadre para imprimir.
-- No lleva variables del instalador.

IF OBJECT_ID(N'dbo.LetCuadreConfig', N'U') IS NULL
CREATE TABLE dbo.LetCuadreConfig (
    Id      INT NOT NULL CONSTRAINT PK_LetCuadreConfig PRIMARY KEY CONSTRAINT CK_LetCuadreConfig CHECK (Id = 1),
    Activo  BIT NOT NULL CONSTRAINT DF_LetCuadreConfig_Activo DEFAULT (0),
    Cambio  DATETIME NOT NULL CONSTRAINT DF_LetCuadreConfig_Cambio DEFAULT (GETDATE())
)
GO
IF NOT EXISTS (SELECT 1 FROM dbo.LetCuadreConfig) INSERT dbo.LetCuadreConfig (Id, Activo) VALUES (1, 0)
GO

IF OBJECT_ID(N'dbo.LetCuadre', N'U') IS NULL
CREATE TABLE dbo.LetCuadre (
    Id          INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_LetCuadre PRIMARY KEY,
    PosId       INT           NOT NULL,
    Caja        NVARCHAR(100) NULL,
    Jornada     DATE          NOT NULL,
    Turno       NVARCHAR(40)  NULL,
    Tipo        VARCHAR(10)   NOT NULL,            -- 'X' (turno) o 'JORNADA'
    UsuarioId   INT           NULL,
    Usuario     NVARCHAR(100) NULL,
    Comentario  NVARCHAR(500) NULL,
    Cuadra      BIT           NOT NULL,
    Fecha       DATETIME      NOT NULL CONSTRAINT DF_LetCuadre_Fecha DEFAULT (GETDATE())
)
GO
IF OBJECT_ID(N'dbo.LetCuadreLinea', N'U') IS NULL
CREATE TABLE dbo.LetCuadreLinea (
    Id          INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_LetCuadreLinea PRIMARY KEY,
    CuadreId    INT           NOT NULL CONSTRAINT FK_LetCuadreLinea_Cuadre REFERENCES dbo.LetCuadre (Id),
    MetodoId    INT           NOT NULL,
    Nombre      NVARCHAR(100) NULL,
    Tipo        VARCHAR(12)   NOT NULL,            -- 'EFECTIVO' o 'NOMETALICO'
    Moneda      CHAR(3)       NOT NULL,
    Esperado    DECIMAL(14,2) NOT NULL,
    Declarado   DECIMAL(14,2) NOT NULL,
    Diferencia  AS (Declarado - Esperado) PERSISTED
)
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_LetCuadre_Cierre' AND object_id = OBJECT_ID(N'dbo.LetCuadre'))
    CREATE INDEX IX_LetCuadre_Cierre ON dbo.LetCuadre (PosId, Jornada, Id DESC)
GO

-- Intentos fallidos de contrasena. La contrasena identifica al usuario, asi que el bloqueo es general: 5 fallos en 15 minutos bloquean los intentos 15 minutos.
IF OBJECT_ID(N'dbo.LetCuadreFallo', N'U') IS NULL
CREATE TABLE dbo.LetCuadreFallo (
    Id     INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_LetCuadreFallo PRIMARY KEY,
    Fecha  DATETIME NOT NULL CONSTRAINT DF_LetCuadreFallo_Fecha DEFAULT (GETDATE())
)
GO

IF OBJECT_ID(N'[dbo].[LetCuadreActivo]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetCuadreActivo] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetCuadreActivo]
AS
BEGIN
    SET NOCOUNT ON;
    SELECT CAST(ISNULL((SELECT Activo FROM dbo.LetCuadreConfig WHERE Id = 1), 0) AS BIT) AS Activo;
END
GO

IF OBJECT_ID(N'[dbo].[LetCuadreConfigurar]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetCuadreConfigurar] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetCuadreConfigurar] (@Activo BIT)
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE dbo.LetCuadreConfig SET Activo = @Activo, Cambio = GETDATE() WHERE Id = 1;
    IF @@ROWCOUNT = 0 INSERT dbo.LetCuadreConfig (Id, Activo) VALUES (1, @Activo);
    SELECT CAST(1 AS BIT) AS Ok, CASE WHEN @Activo = 1 THEN N'Cuadre con declaracion por moneda ACTIVADO' ELSE N'Cuadre con declaracion por moneda DESACTIVADO: Agora cierra como siempre' END AS Mensaje;
END
GO

-- La contrasena que el cajero usa en el POS de Agora (dbo.User.Password). Devuelve el usuario o el motivo del rechazo.
IF OBJECT_ID(N'[dbo].[LetCuadreUsuario]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetCuadreUsuario] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetCuadreUsuario] (@Pin NVARCHAR(40))
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @n INT, @fallos INT, @desde DATETIME;
    SELECT @fallos = COUNT(*), @desde = MIN(Fecha) FROM dbo.LetCuadreFallo WHERE Fecha > DATEADD(MINUTE, -15, GETDATE());
    IF @fallos >= 5
    BEGIN
        SELECT CAST(0 AS BIT) AS Ok, CAST(NULL AS INT) AS UsuarioId, CAST(NULL AS NVARCHAR(100)) AS Usuario,
               N'Demasiados intentos fallidos: espere unos minutos (hasta ' + CONVERT(NVARCHAR(5), DATEADD(MINUTE, 15, (SELECT MAX(Fecha) FROM dbo.LetCuadreFallo)), 108) + N')' AS Mensaje;
        RETURN;
    END
    SELECT @n = COUNT(*) FROM dbo.[User] WHERE DeletionDate IS NULL AND ISNULL(@Pin, N'') <> N'' AND Password = @Pin;
    IF @n = 1
    BEGIN
        DELETE dbo.LetCuadreFallo;
        SELECT CAST(1 AS BIT) AS Ok, u.Id AS UsuarioId, u.Name AS Usuario, N'' AS Mensaje FROM dbo.[User] u WHERE u.DeletionDate IS NULL AND u.Password = @Pin;
    END
    ELSE IF @n > 1
        SELECT CAST(0 AS BIT) AS Ok, CAST(NULL AS INT) AS UsuarioId, CAST(NULL AS NVARCHAR(100)) AS Usuario, N'Esa contrasena la usan varios usuarios: pida al administrador que le asigne una propia' AS Mensaje;
    ELSE
    BEGIN
        INSERT dbo.LetCuadreFallo DEFAULT VALUES;
        DELETE dbo.LetCuadreFallo WHERE Fecha < DATEADD(DAY, -1, GETDATE());
        SELECT CAST(0 AS BIT) AS Ok, CAST(NULL AS INT) AS UsuarioId, CAST(NULL AS NVARCHAR(100)) AS Usuario, N'Contrasena incorrecta' AS Mensaje;
    END
END
GO

-- Calculo de la cinta de cierre de una caja: llena las tablas temporales #H (encabezado) y #E (una fila por forma de pago) que crea quien llama.
-- Es el turno abierto o, si no hay, el ultimo cerrado. Efectivo = la forma da vuelto; las demas son no metalico (tarjeta, transferencia...).
-- Las formas de una moneda extranjera se esperan en esa moneda.
IF OBJECT_ID(N'[dbo].[LetCuadreCalcular]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetCuadreCalcular] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetCuadreCalcular] (@PosId INT)
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Caja NVARCHAR(100), @Apertura DATETIME, @Cierre DATETIME, @Abierto BIT = 0, @Jornada DATE, @Fondo DECIMAL(14,2) = 0;
    SELECT @Caja = Name, @Apertura = OpenDate, @Jornada = CONVERT(DATE, BusinessDay), @Fondo = ISNULL(InitialAmount, 0)
      FROM dbo.Pos WHERE Id = @PosId AND BusinessDay IS NOT NULL;
    IF @Apertura IS NOT NULL SET @Abierto = 1;
    ELSE
    BEGIN
        SELECT TOP (1) @Apertura = c.OpenDate, @Cierre = c.CloseDate, @Jornada = CONVERT(DATE, c.BusinessDay), @Fondo = ISNULL(c.CashInitialAmount, 0)
          FROM dbo.PosCloseOut c WHERE c.PosId = @PosId ORDER BY c.Id DESC;
        SELECT @Caja = Name FROM dbo.Pos WHERE Id = @PosId;
    END
    IF @Apertura IS NULL RETURN;

    INSERT #H (PosId, Caja, Jornada, Turno, Apertura, Cierre, Abierto, FondoInicial)
    VALUES (@PosId, @Caja, @Jornada, CONVERT(NVARCHAR(19), @Apertura, 126), @Apertura, @Cierre, @Abierto, @Fondo);

    DECLARE @Hasta DATETIME = ISNULL(@Cierre, GETDATE());
    DECLARE @MetodoFondo INT = (SELECT TOP (1) m.Id FROM dbo.PaymentMethod m
                                 WHERE m.DeletionDate IS NULL AND m.GiveChange = 1 AND NOT EXISTS (SELECT 1 FROM dbo.LetMonedaFormaPago x WHERE x.AgoraPaymentId = m.Id)
                                 ORDER BY m.Id);
    INSERT #E (MetodoId, Nombre, Tipo, Moneda, Esperado)
    SELECT m.Id, m.Name, CASE WHEN m.GiveChange = 1 THEN 'EFECTIVO' ELSE 'NOMETALICO' END, ISNULL(x.Moneda, 'DOP'),
           CAST(CASE WHEN x.Moneda IS NOT NULL
                     THEN ISNULL((SELECT SUM(p.MontoMoneda) FROM dbo.LetPagoMoneda p WHERE p.PosId = @PosId AND p.IdFormaPago = m.Id AND p.Fecha >= @Apertura AND p.Fecha <= @Hasta), 0)
                     ELSE ISNULL((SELECT SUM(d.PaidAmount - d.ChangeAmount) FROM dbo.DocumentPayment d WHERE d.PosId = @PosId AND d.MethodId = m.Id AND d.Date >= @Apertura AND d.Date <= @Hasta), 0)
                          + CASE WHEN m.Id = @MetodoFondo THEN @Fondo ELSE 0 END
                END AS DECIMAL(14,2))
      FROM dbo.PaymentMethod m
      LEFT JOIN dbo.LetMonedaFormaPago x ON x.AgoraPaymentId = m.Id
     WHERE m.DeletionDate IS NULL AND m.IsValidForSale = 1
       -- La exencion de ITBIS y las formas ocultas sin movimiento no se cuentan.
       AND NOT EXISTS (SELECT 1 FROM dbo.LETMetodoPagos z WHERE z.AgoraPaymentId = m.Id AND z.DeletionDate IS NOT NULL
                          AND NOT EXISTS (SELECT 1 FROM dbo.DocumentPayment d WHERE d.PosId = @PosId AND d.MethodId = m.Id AND d.Date >= @Apertura AND d.Date <= @Hasta));
END
GO

-- La cinta para la pantalla: primer resultado = encabezado (sin filas si la caja nunca se abrio), segundo = formas de pago con lo esperado.
IF OBJECT_ID(N'[dbo].[LetCuadreEsperado]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetCuadreEsperado] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetCuadreEsperado] (@PosId INT)
AS
BEGIN
    SET NOCOUNT ON;
    CREATE TABLE #H (PosId INT, Caja NVARCHAR(100), Jornada DATE, Turno NVARCHAR(40), Apertura DATETIME, Cierre DATETIME, Abierto BIT, FondoInicial DECIMAL(14,2));
    CREATE TABLE #E (MetodoId INT, Nombre NVARCHAR(100), Tipo VARCHAR(12), Moneda CHAR(3), Esperado DECIMAL(14,2));
    EXEC dbo.LetCuadreCalcular @PosId;
    SELECT * FROM #H;
    SELECT * FROM #E ORDER BY CASE WHEN Tipo = 'EFECTIVO' THEN 0 ELSE 1 END, MetodoId;
END
GO

-- Guarda el cuadre. @Lineas es texto 'metodo:monto;metodo:monto' (ej. 1:728.00;5:6). Revalida la contrasena, recalcula lo esperado en el servidor
-- (la pantalla nunca manda lo esperado) y registra la diferencia de cada linea. Con @Simular = 1 no guarda nada: devuelve el estado, el encabezado y las lineas con su diferencia para que el cajero las revise antes de confirmar. Un descuadre NO impide guardar: solo se registra con el comentario.
IF OBJECT_ID(N'[dbo].[LetCuadreGuardar]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetCuadreGuardar] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetCuadreGuardar] (@PosId INT, @Tipo VARCHAR(10), @Pin NVARCHAR(40), @Lineas NVARCHAR(MAX), @Comentario NVARCHAR(500) = NULL, @Simular BIT = 0)
AS
BEGIN
    SET NOCOUNT ON;
    IF @Tipo NOT IN ('X', 'JORNADA') BEGIN SELECT CAST(0 AS BIT) AS Ok, N'Elija cierre X o de jornada' AS Mensaje, CAST(NULL AS INT) AS CuadreId; RETURN; END
    IF ISNULL(@Lineas, N'') = N'' BEGIN SELECT CAST(0 AS BIT) AS Ok, N'Faltan los montos declarados' AS Mensaje, CAST(NULL AS INT) AS CuadreId; RETURN; END
    IF ISNULL((SELECT Activo FROM dbo.LetCuadreConfig WHERE Id = 1), 0) = 0 BEGIN SELECT CAST(0 AS BIT) AS Ok, N'El cuadre con declaracion no esta activado' AS Mensaje, CAST(NULL AS INT) AS CuadreId; RETURN; END

    DECLARE @U TABLE (Ok BIT, UsuarioId INT, Usuario NVARCHAR(100), Mensaje NVARCHAR(200));
    INSERT @U EXEC dbo.LetCuadreUsuario @Pin;
    DECLARE @UsuarioId INT, @Usuario NVARCHAR(100);
    SELECT @UsuarioId = UsuarioId, @Usuario = Usuario FROM @U WHERE Ok = 1;
    IF @UsuarioId IS NULL BEGIN SELECT CAST(0 AS BIT) AS Ok, ISNULL((SELECT TOP (1) Mensaje FROM @U), N'Contrasena incorrecta') AS Mensaje, CAST(NULL AS INT) AS CuadreId; RETURN; END

    CREATE TABLE #H (PosId INT, Caja NVARCHAR(100), Jornada DATE, Turno NVARCHAR(40), Apertura DATETIME, Cierre DATETIME, Abierto BIT, FondoInicial DECIMAL(14,2));
    CREATE TABLE #E (MetodoId INT, Nombre NVARCHAR(100), Tipo VARCHAR(12), Moneda CHAR(3), Esperado DECIMAL(14,2));
    EXEC dbo.LetCuadreCalcular @PosId;
    IF NOT EXISTS (SELECT 1 FROM #H) BEGIN SELECT CAST(0 AS BIT) AS Ok, N'La caja no tiene un turno para cuadrar' AS Mensaje, CAST(NULL AS INT) AS CuadreId; RETURN; END

    DECLARE @D TABLE (MetodoId INT, Declarado DECIMAL(14,2));
    -- La base de Agora esta en un nivel de compatibilidad que no tiene OPENJSON: se lee el texto 'metodo:monto;metodo:monto' a mano.
    DECLARE @r NVARCHAR(MAX) = @Lineas + N';', @i INT, @par NVARCHAR(100), @c INT, @mid INT, @monto DECIMAL(14,2), @malo BIT = 0;
    WHILE LEN(@r) > 0
    BEGIN
        SET @i = CHARINDEX(N';', @r);
        SET @par = LTRIM(RTRIM(LEFT(@r, @i - 1)));
        SET @r = SUBSTRING(@r, @i + 1, LEN(@r));
        IF @par = N'' CONTINUE;
        SET @c = CHARINDEX(N':', @par);
        SET @mid = TRY_CONVERT(INT, CASE WHEN @c > 1 THEN LEFT(@par, @c - 1) END);
        SET @monto = TRY_CONVERT(DECIMAL(14,2), CASE WHEN @c > 0 THEN SUBSTRING(@par, @c + 1, 40) END);
        IF @mid IS NULL OR @monto IS NULL OR @monto < 0 OR EXISTS (SELECT 1 FROM @D WHERE MetodoId = @mid) SET @malo = 1;
        ELSE INSERT @D VALUES (@mid, @monto);
    END
    IF @malo = 1 BEGIN SELECT CAST(0 AS BIT) AS Ok, N'Los montos declarados no pueden estar vacios, repetidos ni ser negativos' AS Mensaje, CAST(NULL AS INT) AS CuadreId; RETURN; END
    IF EXISTS (SELECT 1 FROM @D d WHERE NOT EXISTS (SELECT 1 FROM #E e WHERE e.MetodoId = d.MetodoId)) BEGIN SELECT CAST(0 AS BIT) AS Ok, N'Hay una forma de pago que no pertenece a este cuadre' AS Mensaje, CAST(NULL AS INT) AS CuadreId; RETURN; END

    IF @Simular = 1
    BEGIN
        SELECT CAST(1 AS BIT) AS Ok,
               CASE WHEN EXISTS (SELECT 1 FROM #E e LEFT JOIN @D d ON d.MetodoId = e.MetodoId WHERE ISNULL(d.Declarado, 0) <> e.Esperado) THEN N'La caja no cuadra' ELSE N'La caja cuadra' END AS Mensaje,
               CAST(NULL AS INT) AS CuadreId, @Usuario AS Usuario;
        SELECT * FROM #H;
        SELECT e.MetodoId, e.Nombre, e.Tipo, e.Moneda, e.Esperado, ISNULL(d.Declarado, 0) AS Declarado, ISNULL(d.Declarado, 0) - e.Esperado AS Diferencia
          FROM #E e LEFT JOIN @D d ON d.MetodoId = e.MetodoId ORDER BY CASE WHEN e.Tipo = 'EFECTIVO' THEN 0 ELSE 1 END, e.MetodoId;
        RETURN;
    END

    -- Doble clic: el mismo cuadre del mismo usuario en los ultimos 30 segundos no se repite.
    DECLARE @Previo INT = (SELECT TOP (1) c.Id FROM dbo.LetCuadre c WHERE c.PosId = @PosId AND c.Tipo = @Tipo AND c.UsuarioId = @UsuarioId AND c.Fecha > DATEADD(SECOND, -30, GETDATE()) ORDER BY c.Id DESC);
    IF @Previo IS NOT NULL
    BEGIN SELECT CAST(1 AS BIT) AS Ok, N'Ese cuadre ya estaba registrado (no se repite)' AS Mensaje, @Previo AS CuadreId; RETURN; END

    DECLARE @Id INT, @Cuadra BIT;
    BEGIN TRANSACTION;
    INSERT dbo.LetCuadre (PosId, Caja, Jornada, Turno, Tipo, UsuarioId, Usuario, Comentario, Cuadra)
    SELECT @PosId, h.Caja, h.Jornada, h.Turno, @Tipo, @UsuarioId, @Usuario, NULLIF(LTRIM(RTRIM(@Comentario)), N''),
           CASE WHEN EXISTS (SELECT 1 FROM #E e LEFT JOIN @D d ON d.MetodoId = e.MetodoId WHERE ISNULL(d.Declarado, 0) <> e.Esperado) THEN 0 ELSE 1 END
      FROM #H h;
    SET @Id = SCOPE_IDENTITY();
    INSERT dbo.LetCuadreLinea (CuadreId, MetodoId, Nombre, Tipo, Moneda, Esperado, Declarado)
    SELECT @Id, e.MetodoId, e.Nombre, e.Tipo, e.Moneda, e.Esperado, ISNULL(d.Declarado, 0) FROM #E e LEFT JOIN @D d ON d.MetodoId = e.MetodoId;
    COMMIT;

    SELECT @Cuadra = Cuadra FROM dbo.LetCuadre WHERE Id = @Id;
    SELECT CAST(1 AS BIT) AS Ok, CASE WHEN @Cuadra = 1 THEN N'La caja cuadra' ELSE N'La caja no cuadra: el descuadre quedo registrado' END AS Mensaje, @Id AS CuadreId;
END
GO

-- El cuadre guardado, para la vista previa, la impresion y el correo: encabezado y lineas.
IF OBJECT_ID(N'[dbo].[LetCuadreLeer]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetCuadreLeer] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetCuadreLeer] (@Id INT)
AS
BEGIN
    SET NOCOUNT ON;
    SELECT c.Id, c.PosId, c.Caja, c.Jornada, c.Turno, c.Tipo, c.Usuario, c.Comentario, c.Cuadra, c.Fecha FROM dbo.LetCuadre c WHERE c.Id = @Id;
    SELECT l.MetodoId, l.Nombre, l.Tipo, l.Moneda, l.Esperado, l.Declarado, l.Diferencia FROM dbo.LetCuadreLinea l WHERE l.CuadreId = @Id ORDER BY CASE WHEN l.Tipo = 'EFECTIVO' THEN 0 ELSE 1 END, l.MetodoId;
END
GO
