﻿-- 117_cuadre_ticket.sql
-- LetCuadreLeer devuelve tambien los datos de la empresa (nombre y RNC) para el ticket, el PDF y el correo del cuadre. Misma definicion que 112_cuadre.sql,
-- repetida para que una actualizacion desde el portal la aplique.
-- El cuadre guardado, para la vista previa, el ticket, el PDF y el correo: encabezado, lineas y los datos de la empresa (nombre y RNC, como en el informe de caja de Agora).
IF OBJECT_ID(N'[dbo].[LetCuadreLeer]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetCuadreLeer] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetCuadreLeer] (@Id INT)
AS
BEGIN
    SET NOCOUNT ON;
    SELECT c.Id, c.PosId, c.Caja, c.Jornada, c.Turno, c.Tipo, c.Usuario, c.Comentario, c.Cuadra, c.Fecha FROM dbo.LetCuadre c WHERE c.Id = @Id;
    SELECT l.MetodoId, l.Nombre, l.Tipo, l.Moneda, l.Esperado, l.Declarado, l.Diferencia FROM dbo.LetCuadreLinea l WHERE l.CuadreId = @Id ORDER BY CASE WHEN l.Tipo = 'EFECTIVO' THEN 0 ELSE 1 END, l.MetodoId;
    IF OBJECT_ID(N'dbo.LetEmisor', N'U') IS NOT NULL
        EXEC (N'SELECT TOP (1) NombreComercial, RazonSocial, RNC FROM dbo.LetEmisor ORDER BY Id');
    ELSE
        SELECT CAST(NULL AS NVARCHAR(200)) AS NombreComercial, CAST(NULL AS NVARCHAR(200)) AS RazonSocial, CAST(NULL AS NVARCHAR(20)) AS RNC WHERE 1 = 0;
END
GO
