﻿-- 119_cierre_agora_turno.sql
-- El cierre desde el cuadre tambien puede hacerse con un cuadre de CIERRE X (turno), pero SOLO cuando esa caja es la unica con turno abierto en Agora:
-- el cierre automatico de Agora cierra la jornada completa (todas las cajas), asi que con una sola caja abierta equivale a cerrar su turno y la jornada.
-- Con varias cajas abiertas el cierre X no puede cerrar nada (cada turno se cierra en el POS de Agora). Ademas el cuadre X debe ser del turno que esta abierto.
-- Redefine LetCuadreOpciones (agrega CajasAbiertas) y LetCierreAgoraSolicitar (118). No lleva variables del instalador.

IF OBJECT_ID(N'[dbo].[LetCuadreOpciones]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetCuadreOpciones] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetCuadreOpciones]
AS
BEGIN
    SET NOCOUNT ON;
    SELECT CAST(ISNULL((SELECT Activo FROM dbo.LetCuadreConfig WHERE Id = 1), 0) AS BIT) AS Activo,
           CAST(ISNULL((SELECT CierreAgora FROM dbo.LetCuadreConfig WHERE Id = 1), 0) AS BIT) AS CierreAgora,
           (SELECT TOP (1) CONVERT(VARCHAR(5), AutoCloseTime, 108) FROM dbo.Workplace ORDER BY Id) AS HoraAuto,
           (SELECT COUNT(*) FROM dbo.Ticket) AS TicketsAbiertos,
           (SELECT TOP (1) CAST(BusinessDay AS DATE) FROM dbo.SystemCloseOut WHERE CloseDate IS NULL ORDER BY Id DESC) AS JornadaAbierta,
           (SELECT COUNT(*) FROM dbo.Pos WHERE BusinessDay IS NOT NULL) AS CajasAbiertas;
END
GO

IF OBJECT_ID(N'[dbo].[LetCierreAgoraSolicitar]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetCierreAgoraSolicitar] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetCierreAgoraSolicitar] (@CuadreId INT, @Pin NVARCHAR(40))
AS
BEGIN
    SET NOCOUNT ON;
    EXEC dbo.LetCierreAgoraRevisar;
    IF ISNULL((SELECT CierreAgora FROM dbo.LetCuadreConfig WHERE Id = 1), 0) = 0
    BEGIN SELECT CAST(0 AS BIT) AS Ok, N'El cierre de la jornada de Agora desde el cuadre no esta activado' AS Mensaje, CAST(NULL AS INT) AS Id; RETURN; END

    DECLARE @U TABLE (Ok BIT, UsuarioId INT, Usuario NVARCHAR(100), Mensaje NVARCHAR(200));
    INSERT @U EXEC dbo.LetCuadreUsuario @Pin;
    DECLARE @Usuario NVARCHAR(100) = (SELECT Usuario FROM @U WHERE Ok = 1);
    IF @Usuario IS NULL
    BEGIN SELECT CAST(0 AS BIT) AS Ok, ISNULL((SELECT TOP (1) Mensaje FROM @U), N'Contrasena incorrecta') AS Mensaje, CAST(NULL AS INT) AS Id; RETURN; END

    DECLARE @Tipo VARCHAR(10), @Jornada DATE, @Fecha DATETIME, @PosId INT, @Turno NVARCHAR(40);
    SELECT @Tipo = Tipo, @Jornada = Jornada, @Fecha = Fecha, @PosId = PosId, @Turno = Turno FROM dbo.LetCuadre WHERE Id = @CuadreId;
    IF @Tipo IS NULL BEGIN SELECT CAST(0 AS BIT) AS Ok, N'No existe ese cuadre' AS Mensaje, CAST(NULL AS INT) AS Id; RETURN; END
    IF @Fecha < DATEADD(HOUR, -6, GETDATE()) BEGIN SELECT CAST(0 AS BIT) AS Ok, N'Ese cuadre es de hace mas de 6 horas: haga uno nuevo' AS Mensaje, CAST(NULL AS INT) AS Id; RETURN; END

    -- Un cuadre de turno (X) solo cierra si esa caja es la unica con turno abierto y el cuadre es del turno abierto.
    IF @Tipo = 'X'
    BEGIN
        DECLARE @Abiertas INT = (SELECT COUNT(*) FROM dbo.Pos WHERE BusinessDay IS NOT NULL);
        IF @Abiertas > 1
        BEGIN SELECT CAST(0 AS BIT) AS Ok, N'Hay ' + CAST(@Abiertas AS NVARCHAR(10)) + N' cajas con turno abierto: el cierre del turno se hace en el POS de Agora (este cierre cerraria la jornada de todas)' AS Mensaje, CAST(NULL AS INT) AS Id; RETURN; END
        IF NOT EXISTS (SELECT 1 FROM dbo.Pos WHERE Id = @PosId AND BusinessDay IS NOT NULL AND CONVERT(NVARCHAR(19), OpenDate, 126) = @Turno)
        BEGIN SELECT CAST(0 AS BIT) AS Ok, N'Ese cuadre no es del turno que esta abierto en esa caja: haga uno nuevo' AS Mensaje, CAST(NULL AS INT) AS Id; RETURN; END
    END
    ELSE IF @Tipo <> 'JORNADA'
    BEGIN SELECT CAST(0 AS BIT) AS Ok, N'Tipo de cuadre no valido para cerrar en Agora' AS Mensaje, CAST(NULL AS INT) AS Id; RETURN; END

    DECLARE @J INT, @JDia DATE;
    SELECT TOP (1) @J = Id, @JDia = CAST(BusinessDay AS DATE) FROM dbo.SystemCloseOut WHERE CloseDate IS NULL ORDER BY Id DESC;
    IF @J IS NULL BEGIN SELECT CAST(0 AS BIT) AS Ok, N'No hay una jornada abierta en Agora (ya esta cerrada)' AS Mensaje, CAST(NULL AS INT) AS Id; RETURN; END
    IF @JDia <> @Jornada BEGIN SELECT CAST(0 AS BIT) AS Ok, N'El cuadre es de otra jornada distinta de la que esta abierta en Agora' AS Mensaje, CAST(NULL AS INT) AS Id; RETURN; END

    DECLARE @Pend INT = (SELECT TOP (1) Id FROM dbo.LetCierreAgora WHERE Estado = 'PENDIENTE' ORDER BY Id DESC);
    IF @Pend IS NOT NULL BEGIN SELECT CAST(1 AS BIT) AS Ok, N'Ya hay un cierre en curso: Agora cerrara la jornada en un momento' AS Mensaje, @Pend AS Id; RETURN; END

    DECLARE @W INT, @Orig DATETIME;
    SELECT TOP (1) @W = Id, @Orig = AutoCloseTime FROM dbo.Workplace ORDER BY Id;
    IF @W IS NULL BEGIN SELECT CAST(0 AS BIT) AS Ok, N'No se encontro el lugar de trabajo de Agora' AS Mensaje, CAST(NULL AS INT) AS Id; RETURN; END
    DECLARE @Nueva DATETIME = CAST('1900-01-01 ' + CONVERT(CHAR(8), DATEADD(MINUTE, 2, GETDATE()), 108) AS DATETIME);

    DECLARE @Nuevo INT;
    BEGIN TRANSACTION;
    UPDATE dbo.Workplace SET AutoCloseTime = @Nueva WHERE Id = @W;
    INSERT dbo.LetCierreAgora (CuadreId, Usuario, WorkplaceId, JornadaId, HoraOriginal, HoraPuesta, Estado) VALUES (@CuadreId, @Usuario, @W, @J, @Orig, @Nueva, 'PENDIENTE');
    SET @Nuevo = SCOPE_IDENTITY();
    COMMIT;
    SELECT CAST(1 AS BIT) AS Ok, CASE WHEN @Tipo = 'X' THEN N'Agora cerrara el turno y la jornada en un par de minutos' ELSE N'Agora cerrara la jornada en un par de minutos' END AS Mensaje, @Nuevo AS Id;
END
GO
