-- 115_factura_archivo.sql
-- Copia del ticket de cada factura que el servicio imprime (el mismo JSON que manda la pantalla de cobro), para poder REIMPRIMIRLA desde el reporte
-- (http://localhost:9701) sin pasar por la caja. Se conservan 180 dias. Solo escribe tablas propias de LET. No lleva variables del instalador.

IF OBJECT_ID(N'dbo.LetFE_FacturaJson', N'U') IS NULL
CREATE TABLE dbo.LetFE_FacturaJson (
    Id       INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_LetFE_FacturaJson PRIMARY KEY,
    Serie    NVARCHAR(10)  NOT NULL,
    Numero   INT           NOT NULL,
    Json     NVARCHAR(MAX) NOT NULL,
    Guardado DATETIME      NOT NULL CONSTRAINT DF_LetFE_FacturaJson_Guardado DEFAULT (GETDATE()),
    CONSTRAINT UQ_LetFE_FacturaJson UNIQUE (Serie, Numero)
)
GO

IF OBJECT_ID(N'[dbo].[LetFEFacturaGuardar]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetFEFacturaGuardar] AS RETURN 0')
GO
-- Guarda (o actualiza) la copia de una factura y, de paso, borra las de mas de 180 dias.
ALTER PROCEDURE [dbo].[LetFEFacturaGuardar] (@Serie NVARCHAR(10), @Numero INT, @Json NVARCHAR(MAX))
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE dbo.LetFE_FacturaJson SET Json = @Json, Guardado = GETDATE() WHERE Serie = @Serie AND Numero = @Numero;
    IF @@ROWCOUNT = 0 INSERT dbo.LetFE_FacturaJson (Serie, Numero, Json) VALUES (@Serie, @Numero, @Json);
    DELETE TOP (200) FROM dbo.LetFE_FacturaJson WHERE Guardado < DATEADD(DAY, -180, GETDATE());
END
GO

IF OBJECT_ID(N'[dbo].[LetFEFacturaLeer]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetFEFacturaLeer] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetFEFacturaLeer] (@Serie NVARCHAR(10), @Numero INT)
AS
BEGIN
    SET NOCOUNT ON;
    SELECT TOP (1) Json FROM dbo.LetFE_FacturaJson WHERE Serie = @Serie AND Numero = @Numero;
END
GO
