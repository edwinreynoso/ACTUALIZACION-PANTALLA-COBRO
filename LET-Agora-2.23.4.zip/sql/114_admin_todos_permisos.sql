﻿-- 114_admin_todos_permisos.sql
-- El usuario admin siempre tiene todos los permisos del cierre operativo (usar, fiscalizar, cambiar la tasa) y esta activo: LetFlujoInternoAutenticar lo trata asi
-- cuando su PIN es correcto. Misma definicion que 008_flujo_interno.sql, repetida para que una actualizacion desde el portal la aplique.
IF OBJECT_ID(N'[dbo].[LetFlujoInternoAutenticar]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetFlujoInternoAutenticar] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetFlujoInternoAutenticar] (@Usuario NVARCHAR(100), @Pin NVARCHAR(40), @Permiso VARCHAR(10), @Ok BIT OUTPUT, @Motivo NVARCHAR(200) OUTPUT)
AS
BEGIN
    SET NOCOUNT ON;
    SET @Ok = 0;
    DECLARE @Id INT, @Salt VARBINARY(16), @Hash VARBINARY(32), @Usar BIT, @Fisc BIT, @CamTasa BIT, @Hasta DATETIME, @Activo BIT;
    SELECT @Id = Id, @Salt = PinSalt, @Hash = PinHash, @Usar = PuedeUsar, @Fisc = PuedeFiscalizar, @CamTasa = PuedeCambiarTasa, @Hasta = BloqueadoHasta, @Activo = Activo
      FROM dbo.LetFlujoInternoUsuario WHERE UsuarioAgora = LTRIM(RTRIM(ISNULL(@Usuario, N'')));
    -- El usuario admin siempre tiene todos los permisos y esta activo: nada de lo que se cambie lo limita (solo su PIN lo protege).
    IF LOWER(LTRIM(RTRIM(ISNULL(@Usuario, N'')))) = N'admin' SELECT @Usar = 1, @Fisc = 1, @CamTasa = 1, @Activo = 1;
    IF @Id IS NULL OR @Activo = 0 OR @Hash IS NULL BEGIN SET @Motivo = N'Usuario o PIN incorrectos'; RETURN; END
    IF @Hasta IS NOT NULL AND @Hasta > GETDATE() BEGIN SET @Motivo = N'Usuario bloqueado por intentos fallidos: espere unos minutos'; RETURN; END
    IF HASHBYTES('SHA2_256', @Salt + CAST(ISNULL(@Pin, N'') AS VARBINARY(80))) <> @Hash
    BEGIN
        UPDATE dbo.LetFlujoInternoUsuario
           SET BloqueadoHasta = CASE WHEN Fallos + 1 >= 5 THEN DATEADD(MINUTE, 15, GETDATE()) ELSE BloqueadoHasta END,
               Fallos = CASE WHEN Fallos + 1 >= 5 THEN 0 ELSE Fallos + 1 END
         WHERE Id = @Id;
        SET @Motivo = N'Usuario o PIN incorrectos'; RETURN;
    END
    IF (@Permiso = 'FISCALIZAR' AND @Fisc = 0) OR (@Permiso = 'USAR' AND @Usar = 0) OR (@Permiso = 'TASA' AND @CamTasa = 0)
    BEGIN SET @Motivo = N'El usuario no tiene permiso para esta accion'; RETURN; END
    UPDATE dbo.LetFlujoInternoUsuario SET Fallos = 0, BloqueadoHasta = NULL WHERE Id = @Id;
    SET @Ok = 1; SET @Motivo = N'';
END
GO
