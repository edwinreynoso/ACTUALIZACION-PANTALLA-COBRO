﻿-- 116_secuencias_umbrales.sql
-- Tabla: dbo.LetFESecuenciaUmbralesCfg. Procedimientos: LetFESecuenciaUmbrales (leer) y LetFESecuenciaUmbralesGuardar.
-- Cuando una secuencia de e-NCF pasa a AVISO o a URGENTE (comprobantes que quedan, porcentaje consumido y dias para vencer). Los valores se cambian desde el portal
-- (Secuencias de e-NCF -> Alertas) y valen para lo que se ve en pantalla y para los avisos por correo, sin reiniciar el servicio.
-- Sin fila, el servicio usa los valores del appsettings.json (EFiscal.Alertas.Secuencias). Solo escribe tablas propias de LET. No lleva variables del instalador.

IF OBJECT_ID(N'dbo.LetFESecuenciaUmbralesCfg', N'U') IS NULL
CREATE TABLE dbo.LetFESecuenciaUmbralesCfg (
    Id                INT NOT NULL CONSTRAINT PK_LetFESecuenciaUmbralesCfg PRIMARY KEY CONSTRAINT CK_LetFESecuenciaUmbralesCfg CHECK (Id = 1),
    DisponiblesAviso  INT NOT NULL,
    DisponiblesUrgente INT NOT NULL,
    PorcentajeAviso   INT NOT NULL,
    PorcentajeUrgente INT NOT NULL,
    DiasAviso         INT NOT NULL,
    DiasUrgente       INT NOT NULL,
    Cambio            DATETIME NOT NULL CONSTRAINT DF_LetFESecuenciaUmbralesCfg_Cambio DEFAULT (GETDATE()),
    Usuario           NVARCHAR(100) NULL
)
GO

IF OBJECT_ID(N'[dbo].[LetFESecuenciaUmbrales]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetFESecuenciaUmbrales] AS RETURN 0')
GO
-- Sin filas = no se han cambiado: valen los del appsettings.
ALTER PROCEDURE [dbo].[LetFESecuenciaUmbrales]
AS
BEGIN
    SET NOCOUNT ON;
    SELECT TOP (1) DisponiblesAviso, DisponiblesUrgente, PorcentajeAviso, PorcentajeUrgente, DiasAviso, DiasUrgente, Cambio, Usuario FROM dbo.LetFESecuenciaUmbralesCfg WHERE Id = 1;
END
GO

IF OBJECT_ID(N'[dbo].[LetFESecuenciaUmbralesGuardar]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetFESecuenciaUmbralesGuardar] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetFESecuenciaUmbralesGuardar] (@DisponiblesAviso INT, @DisponiblesUrgente INT, @PorcentajeAviso INT, @PorcentajeUrgente INT, @DiasAviso INT, @DiasUrgente INT, @Usuario NVARCHAR(100) = NULL)
AS
BEGIN
    SET NOCOUNT ON;
    IF @DisponiblesUrgente < 0 OR @DisponiblesAviso <= @DisponiblesUrgente
    BEGIN SELECT CAST(0 AS BIT) AS Ok, N'Los comprobantes para el aviso deben ser mas que los del aviso urgente' AS Mensaje; RETURN; END
    IF @PorcentajeAviso < 1 OR @PorcentajeUrgente > 100 OR @PorcentajeUrgente <= @PorcentajeAviso
    BEGIN SELECT CAST(0 AS BIT) AS Ok, N'El porcentaje urgente debe ser mayor que el del aviso (entre 1 y 100)' AS Mensaje; RETURN; END
    IF @DiasUrgente < 0 OR @DiasAviso <= @DiasUrgente
    BEGIN SELECT CAST(0 AS BIT) AS Ok, N'Los dias del aviso deben ser mas que los del aviso urgente' AS Mensaje; RETURN; END
    UPDATE dbo.LetFESecuenciaUmbralesCfg
       SET DisponiblesAviso = @DisponiblesAviso, DisponiblesUrgente = @DisponiblesUrgente, PorcentajeAviso = @PorcentajeAviso, PorcentajeUrgente = @PorcentajeUrgente,
           DiasAviso = @DiasAviso, DiasUrgente = @DiasUrgente, Cambio = GETDATE(), Usuario = @Usuario WHERE Id = 1;
    IF @@ROWCOUNT = 0
        INSERT dbo.LetFESecuenciaUmbralesCfg (Id, DisponiblesAviso, DisponiblesUrgente, PorcentajeAviso, PorcentajeUrgente, DiasAviso, DiasUrgente, Usuario)
        VALUES (1, @DisponiblesAviso, @DisponiblesUrgente, @PorcentajeAviso, @PorcentajeUrgente, @DiasAviso, @DiasUrgente, @Usuario);
    SELECT CAST(1 AS BIT) AS Ok, N'Alertas de secuencias guardadas' AS Mensaje;
END
GO
