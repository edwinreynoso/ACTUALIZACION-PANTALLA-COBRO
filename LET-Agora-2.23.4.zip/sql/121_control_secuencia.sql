﻿-- 121_control_secuencia.sql
-- Control de secuencia al cerrar la factura (solo con e-Fiscal Cloud). Con el control ACTIVO (portal: Secuencias de e-NCF -> Control al cerrar):
--   * si el tipo de comprobante tiene una secuencia activa con comprobantes disponibles y sin vencer, todo sigue igual (con aviso si queda poco);
--   * si NO la tiene (sin secuencia, agotada o vencida): BLOQUEAR = la factura no se cierra; CONTINGENCIA = se emite con un numero de contingencia
--     (si hay un rango de contingencia disponible para ese tipo y caja) y el servicio la entrega despues a e-Fiscal Cloud.
-- La decision la toma LetFESecuenciaControl; CrearFacturaAgora la consulta (por eso no se puede saltar desde la pantalla) y el servicio y la pantalla de cobro
-- la consultan para avisar antes de cobrar. Con el control apagado (por defecto) nada cambia. No lleva variables del instalador.

IF OBJECT_ID(N'dbo.LetFEControlSecuencia', N'U') IS NULL
CREATE TABLE dbo.LetFEControlSecuencia (
    Id           INT NOT NULL CONSTRAINT PK_LetFEControlSecuencia PRIMARY KEY CONSTRAINT CK_LetFEControlSecuencia_Id CHECK (Id = 1),
    Activo       BIT NOT NULL CONSTRAINT DF_LetFEControlSecuencia_Activo DEFAULT (0),
    SinSecuencia VARCHAR(12) NOT NULL CONSTRAINT DF_LetFEControlSecuencia_Sin DEFAULT ('BLOQUEAR') CONSTRAINT CK_LetFEControlSecuencia_Sin CHECK (SinSecuencia IN ('BLOQUEAR', 'CONTINGENCIA')),
    Cambio       DATETIME NOT NULL CONSTRAINT DF_LetFEControlSecuencia_Cambio DEFAULT (GETDATE()),
    Usuario      NVARCHAR(100) NULL
)
GO

-- Tipos de e-CF que estan emitiendo en contingencia porque no tienen secuencia activa (los pone y los quita LetFESecuenciaControl).
IF OBJECT_ID(N'dbo.LetFEContingenciaTipo', N'U') IS NULL
CREATE TABLE dbo.LetFEContingenciaTipo (
    TipoEcf INT NOT NULL CONSTRAINT PK_LetFEContingenciaTipo PRIMARY KEY,
    Desde   DATETIME NOT NULL CONSTRAINT DF_LetFEContingenciaTipo_Desde DEFAULT (GETDATE()),
    Motivo  NVARCHAR(200) NULL
)
GO

-- Cada vez que se bloquea una factura o una nota de credito (o un tipo pasa a contingencia por falta de secuencia) queda un evento; el servicio los avisa
-- por las alertas (correo o webhook) y los marca como notificados. Se borran a los 30 dias.
IF OBJECT_ID(N'dbo.LetFEControlSecuenciaEvento', N'U') IS NULL
CREATE TABLE dbo.LetFEControlSecuenciaEvento (
    Id         INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_LetFEControlSecuenciaEvento PRIMARY KEY,
    Fecha      DATETIME NOT NULL CONSTRAINT DF_LetFEControlSecuenciaEvento_Fecha DEFAULT (GETDATE()),
    TipoEcf    INT NOT NULL,
    Documento  CHAR(1) NOT NULL,
    Modo       VARCHAR(12) NOT NULL,
    Mensaje    NVARCHAR(300) NULL,
    Notificado BIT NOT NULL CONSTRAINT DF_LetFEControlSecuenciaEvento_Notificado DEFAULT (0)
)
GO

IF OBJECT_ID(N'[dbo].[LetFEControlSecuenciaObtener]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetFEControlSecuenciaObtener] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetFEControlSecuenciaObtener]
AS
BEGIN
    SET NOCOUNT ON;
    SELECT CAST(ISNULL((SELECT Activo FROM dbo.LetFEControlSecuencia WHERE Id = 1), 0) AS BIT) AS Activo,
           ISNULL((SELECT SinSecuencia FROM dbo.LetFEControlSecuencia WHERE Id = 1), 'BLOQUEAR') AS SinSecuencia,
           (SELECT Cambio FROM dbo.LetFEControlSecuencia WHERE Id = 1) AS Cambio,
           (SELECT Usuario FROM dbo.LetFEControlSecuencia WHERE Id = 1) AS Usuario;
END
GO

IF OBJECT_ID(N'[dbo].[LetFEControlSecuenciaGuardar]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetFEControlSecuenciaGuardar] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetFEControlSecuenciaGuardar] (@Activo BIT, @SinSecuencia VARCHAR(12), @Usuario NVARCHAR(100) = NULL)
AS
BEGIN
    SET NOCOUNT ON;
    IF @SinSecuencia NOT IN ('BLOQUEAR', 'CONTINGENCIA')
    BEGIN SELECT CAST(0 AS BIT) AS Ok, N'Elija que hacer cuando no hay secuencia: bloquear o usar la contingencia' AS Mensaje; RETURN; END
    UPDATE dbo.LetFEControlSecuencia SET Activo = @Activo, SinSecuencia = @SinSecuencia, Cambio = GETDATE(), Usuario = @Usuario WHERE Id = 1;
    IF @@ROWCOUNT = 0 INSERT dbo.LetFEControlSecuencia (Id, Activo, SinSecuencia, Usuario) VALUES (1, @Activo, @SinSecuencia, @Usuario);
    -- Al apagar el control o cambiar a bloquear, ningun tipo sigue forzado a contingencia.
    IF @Activo = 0 OR @SinSecuencia = 'BLOQUEAR' DELETE dbo.LetFEContingenciaTipo;
    SELECT CAST(1 AS BIT) AS Ok, CASE WHEN @Activo = 0 THEN N'Control de secuencia apagado' WHEN @SinSecuencia = 'BLOQUEAR' THEN N'Control activo: sin secuencia no se cierra la factura' ELSE N'Control activo: sin secuencia se emite en contingencia' END AS Mensaje;
END
GO

-- Igual que en 094, pero tambien toma numero de contingencia cuando el TIPO esta forzado (no hay secuencia activa y el parametro permite la contingencia).
IF OBJECT_ID(N'dbo.LetFEContingenciaTomar') IS NULL EXEC (N'CREATE PROCEDURE dbo.LetFEContingenciaTomar AS RETURN 0')
GO
ALTER PROCEDURE dbo.LetFEContingenciaTomar @TipoEcf INT, @PosId INT = NULL, @Encf VARCHAR(20) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET @Encf = NULL;
    IF NOT EXISTS (SELECT 1 FROM dbo.LetFEContingenciaModo WHERE Id = 1 AND Activa = 1)
       AND NOT EXISTS (SELECT 1 FROM dbo.LetFEContingenciaTipo WHERE TipoEcf = @TipoEcf) RETURN;
    DECLARE @Intentos INT = 0, @Numero BIGINT, @Candidato VARCHAR(20);
    DECLARE @t TABLE (Numero BIGINT);
    WHILE @Intentos < 50 AND @Encf IS NULL
    BEGIN
        SET @Intentos += 1; SET @Numero = NULL;
        DELETE @t;
        ;WITH c AS (
            SELECT TOP (1) r.Siguiente, r.Actualizado FROM dbo.LetFEContingenciaRango r WITH (UPDLOCK, ROWLOCK)
             WHERE r.Activo = 1 AND r.TipoEcf = @TipoEcf AND (r.PosId IS NULL OR r.PosId = @PosId) AND r.Siguiente <= r.Hasta
               AND (r.Vencimiento IS NULL OR r.Vencimiento >= CAST(GETDATE() AS DATE))
             ORDER BY CASE WHEN r.PosId IS NULL THEN 1 ELSE 0 END, r.Desde)
        UPDATE c SET Siguiente = Siguiente + 1, Actualizado = GETDATE() OUTPUT deleted.Siguiente INTO @t;
        SELECT @Numero = Numero FROM @t;
        IF @Numero IS NULL RETURN;      -- no hay rango disponible
        SET @Candidato = 'E' + CAST(@TipoEcf AS VARCHAR(2)) + RIGHT('0000000000' + CAST(@Numero AS VARCHAR(10)), 10);
        IF NOT EXISTS (SELECT 1 FROM dbo.LetFE_Cola WHERE Encf = @Candidato) SET @Encf = @Candidato;
    END
    IF @Encf IS NOT NULL INSERT dbo.LetFEContingenciaHistorial (Accion, Detalle) VALUES ('NUMERO', CONCAT(@Encf, N' (caja ', ISNULL(CAST(@PosId AS NVARCHAR(10)), N'?'), N')'));
END
GO

IF OBJECT_ID(N'[dbo].[LetFESecuenciaControl]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetFESecuenciaControl] AS RETURN 0')
GO
-- Decide si se puede cerrar una factura de ese tipo. Se le da el tipo de Agora (@TipoAgora) o el de e-CF (@TipoEcf).
--   Modo: SIN_CONTROL (apagado o no aplica), NORMAL, CONTINGENCIA (se emite con numero de contingencia) o BLOQUEADO (no se puede cerrar).
--   Nivel: OK, AVISO, URGENTE (queda poco o vence pronto; se puede cerrar), AGOTADA, VENCIDA o SIN_SECUENCIA.
-- @Documento: F = factura, N = nota de credito (una nota nunca se emite en contingencia: sin secuencia siempre se bloquea).
-- @Aplicar = 1 ademas deja marcado (o desmarca) el tipo como "en contingencia por falta de secuencia"; con 0 solo consulta.
ALTER PROCEDURE [dbo].[LetFESecuenciaControl] (@TipoAgora INT = NULL, @TipoEcf INT = NULL, @PosId INT = NULL, @Aplicar BIT = 0, @Documento CHAR(1) = 'F')
AS
BEGIN
    SET NOCOUNT ON;
    IF @TipoEcf IS NULL AND @TipoAgora IS NOT NULL SET @TipoEcf = dbo.LetFETipoEcf(@TipoAgora);
    DECLARE @Activo BIT = ISNULL((SELECT Activo FROM dbo.LetFEControlSecuencia WHERE Id = 1), 0);
    DECLARE @Sin VARCHAR(12) = ISNULL((SELECT SinSecuencia FROM dbo.LetFEControlSecuencia WHERE Id = 1), 'BLOQUEAR');
    IF @TipoEcf IS NULL OR @Activo = 0 OR dbo.LetFEProveedor() <> 'EFISCAL'
    BEGIN
        SELECT CAST(1 AS BIT) AS Permitido, CAST('SIN_CONTROL' AS VARCHAR(12)) AS Modo, CAST('OK' AS VARCHAR(14)) AS Nivel, CAST(N'' AS NVARCHAR(300)) AS Mensaje,
               CAST(NULL AS BIGINT) AS Disponibles, CAST(NULL AS BIGINT) AS ContingenciaDisponibles, @TipoEcf AS TipoEcf;
        RETURN;
    END

    DECLARE @Hoy DATE = CAST(GETDATE() AS DATE);
    DECLARE @DAviso INT = 100, @DUrg INT = 10, @DiasAviso INT = 30, @DiasUrg INT = 7;
    -- Los umbrales que se cambian en el portal (116); sin la tabla o sin fila valen los de siempre.
    IF OBJECT_ID(N'dbo.LetFESecuenciaUmbralesCfg', N'U') IS NOT NULL
        EXEC sp_executesql N'SELECT TOP (1) @a = DisponiblesAviso, @u = DisponiblesUrgente, @da = DiasAviso, @du = DiasUrgente FROM dbo.LetFESecuenciaUmbralesCfg WHERE Id = 1',
             N'@a INT OUTPUT, @u INT OUTPUT, @da INT OUTPUT, @du INT OUTPUT', @a = @DAviso OUTPUT, @u = @DUrg OUTPUT, @da = @DiasAviso OUTPUT, @du = @DiasUrg OUTPUT;

    -- Los rangos del tipo y el ultimo numero usado de cada uno (el de e-Fiscal; si no se sabe, el ultimo que emitio este equipo).
    DECLARE @r TABLE (Desde BIGINT, Hasta BIGINT, Ultimo BIGINT, Venc DATE);
    INSERT @r (Desde, Hasta, Ultimo, Venc)
    SELECT s.Desde, s.Hasta, COALESCE(s.Actual, n.Ultimo, s.Desde - 1), s.Vencimiento
      FROM dbo.LetFESecuencia s
      OUTER APPLY (SELECT MAX(TRY_CAST(SUBSTRING(q.Encf, 4, 10) AS BIGINT)) AS Ultimo
                     FROM dbo.LetFE_Cola q
                    WHERE s.Actual IS NULL AND q.Encf LIKE 'E[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'
                      AND SUBSTRING(q.Encf, 2, 2) = CAST(s.TipoEcf AS VARCHAR(2))
                      AND TRY_CAST(SUBSTRING(q.Encf, 4, 10) AS BIGINT) BETWEEN s.Desde AND s.Hasta) n
     WHERE s.TipoEcf = @TipoEcf;

    DECLARE @Total INT = (SELECT COUNT(*) FROM @r);
    DECLARE @NoVencidos INT = (SELECT COUNT(*) FROM @r WHERE Venc IS NULL OR Venc >= @Hoy);
    DECLARE @Disp BIGINT = (SELECT SUM(Hasta - Ultimo) FROM @r WHERE (Venc IS NULL OR Venc >= @Hoy) AND Hasta > Ultimo);
    DECLARE @SinVencer INT = (SELECT COUNT(*) FROM @r WHERE Venc IS NULL AND Hasta > Ultimo);
    DECLARE @Dias INT = (SELECT MAX(DATEDIFF(DAY, @Hoy, Venc)) FROM @r WHERE Venc >= @Hoy AND Hasta > Ultimo);
    DECLARE @Cont BIGINT = (SELECT SUM(r.Hasta - r.Siguiente + 1) FROM dbo.LetFEContingenciaRango r
                             WHERE r.Activo = 1 AND r.TipoEcf = @TipoEcf AND (r.PosId IS NULL OR r.PosId = @PosId) AND r.Siguiente <= r.Hasta
                               AND (r.Vencimiento IS NULL OR r.Vencimiento >= @Hoy));
    DECLARE @Etq NVARCHAR(10) = N'E' + CAST(@TipoEcf AS NVARCHAR(2));
    DECLARE @Nivel VARCHAR(14), @Modo VARCHAR(12), @Permitido BIT, @Msg NVARCHAR(300);

    IF @Documento = 'F' AND EXISTS (SELECT 1 FROM dbo.LetFEContingenciaModo WHERE Id = 1 AND Activa = 1) AND ISNULL(@Cont, 0) > 0
    BEGIN
        SELECT @Nivel = 'OK', @Modo = 'CONTINGENCIA', @Permitido = 1, @Msg = N'La contingencia esta activa: ' + @Etq + N' se emite con numero de contingencia y se entrega despues';
    END
    ELSE IF ISNULL(@Disp, 0) > 0 AND (@SinVencer > 0 OR @NoVencidos > 0)
    BEGIN
        SET @Nivel = CASE WHEN @Disp <= @DUrg OR (@SinVencer = 0 AND @Dias <= @DiasUrg) THEN 'URGENTE'
                          WHEN @Disp <= @DAviso OR (@SinVencer = 0 AND @Dias <= @DiasAviso) THEN 'AVISO' ELSE 'OK' END;
        SELECT @Modo = 'NORMAL', @Permitido = 1,
               @Msg = CASE WHEN @Nivel = 'OK' THEN N''
                           WHEN @Disp <= @DAviso THEN N'Quedan ' + CAST(@Disp AS NVARCHAR(20)) + N' comprobantes ' + @Etq + N': pida una secuencia nueva a e-Fiscal Cloud'
                           ELSE N'La secuencia ' + @Etq + N' vence en ' + CAST(@Dias AS NVARCHAR(10)) + N' dia(s): pida una nueva a e-Fiscal Cloud' END;
        IF @Aplicar = 1 DELETE dbo.LetFEContingenciaTipo WHERE TipoEcf = @TipoEcf;      -- volvio la secuencia: ya no se fuerza la contingencia
    END
    ELSE IF NOT EXISTS (SELECT 1 FROM dbo.LetFESecuencia WHERE Fuente = 'EFISCAL')
    BEGIN
        -- No hay ninguna secuencia traida de e-Fiscal Cloud (lo cargado a mano solo sirve de referencia y de alerta). e-Fiscal es el dueno de la secuencia y asigna el e-NCF al firmar:
        -- no se bloquea ni se fuerza la contingencia (un numero de contingencia que e-Fiscal no esperaba es rechazado y reemplazado). Se emite normal y e-Fiscal decide.
        SELECT @Nivel = 'DESCONOCIDA', @Modo = 'NORMAL', @Permitido = 1, @Msg = N'';
        IF @Aplicar = 1 DELETE dbo.LetFEContingenciaTipo WHERE TipoEcf = @TipoEcf;      -- suelta un tipo que se hubiera forzado a contingencia por esta causa
    END
    ELSE
    BEGIN
        SET @Nivel = CASE WHEN @Total = 0 THEN 'SIN_SECUENCIA' WHEN @NoVencidos = 0 THEN 'VENCIDA' ELSE 'AGOTADA' END;
        DECLARE @Causa NVARCHAR(60) = CASE @Nivel WHEN 'SIN_SECUENCIA' THEN N'no tiene secuencia cargada' WHEN 'VENCIDA' THEN N'tiene la secuencia vencida' ELSE N'tiene la secuencia agotada' END;
        IF @Documento = 'F' AND @Sin = 'CONTINGENCIA' AND ISNULL(@Cont, 0) > 0
        BEGIN
            SELECT @Modo = 'CONTINGENCIA', @Permitido = 1,
                   @Msg = N'El comprobante ' + @Etq + N' ' + @Causa + N': se emite con numero de contingencia y se entrega despues a e-Fiscal Cloud (quedan ' + CAST(@Cont AS NVARCHAR(20)) + N' de contingencia)';
            IF @Aplicar = 1 AND NOT EXISTS (SELECT 1 FROM dbo.LetFEContingenciaTipo WHERE TipoEcf = @TipoEcf)
            BEGIN
                INSERT dbo.LetFEContingenciaTipo (TipoEcf, Motivo) VALUES (@TipoEcf, LEFT(N'Sin secuencia activa de ' + @Etq + N' (' + @Causa + N')', 200));
                INSERT dbo.LetFEContingenciaHistorial (Accion, Detalle) VALUES ('SIN_SECUENCIA', LEFT(N'El comprobante ' + @Etq + N' ' + @Causa + N': se emite en contingencia', 400));
                INSERT dbo.LetFEControlSecuenciaEvento (TipoEcf, Documento, Modo, Mensaje) VALUES (@TipoEcf, @Documento, 'CONTINGENCIA', @Msg);
            END
        END
        ELSE
        BEGIN
            SELECT @Modo = 'BLOQUEADO', @Permitido = 0,
                   @Msg = N'El comprobante ' + @Etq + N' ' + @Causa + N': ' + CASE WHEN @Documento = 'N' THEN N'no se puede emitir la nota de credito' ELSE N'no se puede cerrar la factura' END + N'. Pida una secuencia a e-Fiscal Cloud'
                          + CASE WHEN @Documento = 'N' THEN N' (las notas de credito no se emiten en contingencia).' WHEN @Sin = 'CONTINGENCIA' THEN N' (y no hay numeros de contingencia disponibles).' ELSE N'.' END;
        END
    END

    SELECT @Permitido AS Permitido, @Modo AS Modo, @Nivel AS Nivel, @Msg AS Mensaje, @Disp AS Disponibles, @Cont AS ContingenciaDisponibles, @TipoEcf AS TipoEcf;
END
GO

IF OBJECT_ID(N'[dbo].[LetFEControlSecuenciaEventos]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetFEControlSecuenciaEventos] AS RETURN 0')
GO
-- @Marcar = 0: los eventos que faltan por avisar, juntos por tipo, documento y modo (con cuantos intentos fueron). @Marcar = 1: los marca como avisados hasta @HastaId.
ALTER PROCEDURE [dbo].[LetFEControlSecuenciaEventos] (@Marcar BIT = 0, @HastaId INT = NULL)
AS
BEGIN
    SET NOCOUNT ON;
    IF @Marcar = 1
    BEGIN
        UPDATE dbo.LetFEControlSecuenciaEvento SET Notificado = 1 WHERE Notificado = 0 AND (@HastaId IS NULL OR Id <= @HastaId);
        DELETE dbo.LetFEControlSecuenciaEvento WHERE Fecha < DATEADD(DAY, -30, GETDATE());
        SELECT CAST(1 AS BIT) AS Ok;
        RETURN;
    END
    SELECT MAX(Id) AS UltimoId, TipoEcf, Documento, Modo, MAX(Mensaje) AS Mensaje, COUNT(*) AS Intentos, MIN(Fecha) AS Primero, MAX(Fecha) AS Ultimo
      FROM dbo.LetFEControlSecuenciaEvento WHERE Notificado = 0
     GROUP BY TipoEcf, Documento, Modo ORDER BY MAX(Id);
END
GO

-- Todos los tipos de e-CF que usa esta instalacion (los relacionados en LetFETipoComprobante), para que el servicio avise sin esperar a una venta.
IF OBJECT_ID(N'[dbo].[LetFESecuenciaControlResumen]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetFESecuenciaControlResumen] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetFESecuenciaControlResumen] (@Aplicar BIT = 0)
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @res TABLE (Permitido BIT, Modo VARCHAR(12), Nivel VARCHAR(14), Mensaje NVARCHAR(300), Disponibles BIGINT, ContingenciaDisponibles BIGINT, TipoEcf INT);
    DECLARE @t INT;
    -- Solo los tipos que se usan: tienen una secuencia cargada o emitieron en los ultimos 60 dias.
    DECLARE c CURSOR LOCAL FAST_FORWARD FOR
        SELECT DISTINCT e.TipoEcf FROM (SELECT dbo.LetFETipoEcf(TipoAgora) AS TipoEcf FROM dbo.LetFETipoComprobante) e
         WHERE e.TipoEcf IS NOT NULL
           AND (EXISTS (SELECT 1 FROM dbo.LetFESecuencia s WHERE s.TipoEcf = e.TipoEcf)
                OR EXISTS (SELECT 1 FROM dbo.LetFE_Cola q WHERE q.TipoEcf = e.TipoEcf AND q.Fecha >= DATEADD(DAY, -60, GETDATE())));
    OPEN c; FETCH NEXT FROM c INTO @t;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        INSERT @res EXEC dbo.LetFESecuenciaControl @TipoEcf = @t, @PosId = NULL, @Aplicar = @Aplicar;
        FETCH NEXT FROM c INTO @t;
    END
    CLOSE c; DEALLOCATE c;
    SELECT Permitido, Modo, Nivel, Mensaje, Disponibles, ContingenciaDisponibles, TipoEcf FROM @res ORDER BY TipoEcf;
END
GO


------------------------------------------------------------ [dbo].[CrearFacturaAgora]
IF OBJECT_ID(N'[dbo].[CrearFacturaAgora]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[CrearFacturaAgora] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[CrearFacturaAgora]
    @udtFactura udtFactura readonly,
    @udtFacturaDetalle udtFacturaDetalle readonly,
    @udtPayment udtPayment readonly,
    @udtFacturaDetalleAddin udtFacturaDetalleAddin readonly,
    @udtCliente udtCliente readonly,
    @TipoComprobante int,
    @RNC varchar(max),
    @Mensaje varchar(max) output,
    @Respuesta int output,
    -- Datos del pasajero (tienda duty free). Opcionales: la pantalla anterior no los envia.
    @PasajeroNombre nvarchar(100) = NULL,
    @PasajeroPasaporte nvarchar(30) = NULL,
    @PasajeroNacionalidad nvarchar(50) = NULL,
    @PasajeroVueloCrucero nvarchar(50) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;

        DECLARE @NCF varchar(19);
        DECLARE @RazoSocial nvarchar(200);
        DECLARE @Serie nvarchar(10);
        DECLARE @Number int;
        DECLARE @PosId int, @IdCompania int;
        DECLARE @CodigoCliente varchar(50), @NombreCliente varchar(50),
                @Telefono nvarchar(50), @Direccion nvarchar(300), @PuntoPendiente int

        SELECT @CodigoCliente = [CodigoCliente],
               @NombreCliente = [NombreCliente],
               @Telefono = [Telefono],
               @Direccion = [Direccion],
               @PuntoPendiente = [PuntoPendiente] FROM @udtCliente

        SELECT @Serie = [Serie], @Number = [Numero], @PosId = [PosId] FROM @udtFactura;

        -- Una factura con la misma serie y numero pero de OTRO ticket no es un reintento: Agora reinicio la
        -- numeracion (base restaurada o reiniciada) y en Factura quedaron datos viejos. Se detiene en vez de
        -- devolver la factura vieja como si fuera la nueva.
        IF EXISTS (SELECT 1 FROM [dbo].[Factura] f WHERE f.[Serie] = @Serie AND f.[Numero] = @Number
                      AND f.[IdTicket] <> (SELECT TOP (1) u.[IdTicket] FROM @udtFactura u))
        BEGIN
            DECLARE @Repetida nvarchar(40) = CONCAT(@Serie, N'-', @Number);
            RAISERROR(N'LA FACTURA %s YA ESTA REGISTRADA CON OTRO TICKET (LA NUMERACION DE AGORA SE REINICIO). AVISE A SOPORTE', 16, 1, @Repetida);
        END

        -- Si la factura ya se registro (la pantalla reintenta cuando se pierde la respuesta) no se vuelve
        -- a insertar ni se gasta otro NCF: solo se devuelven sus datos para imprimirla.
        IF NOT EXISTS (SELECT 1 FROM [dbo].[Factura] WITH (UPDLOCK, HOLDLOCK) WHERE [Serie] = @Serie AND [Numero] = @Number)
        BEGIN
            -- Con e-Fiscal Cloud el e-NCF lo asigna la plataforma al emitir: este numero es solo un marcador (P + tipo + 10
            -- digitos, de su propio contador, sin depender de NCFSecuencia) y se reemplaza cuando llega el e-NCF real
            -- (LetFEResultado). Nunca se imprime.
            -- Control de secuencia (121_control_secuencia.sql): con el control activo, una factura de un tipo sin secuencia activa en e-Fiscal Cloud no se cierra,
            -- o se emite en contingencia si el parametro lo permite. Con el control apagado no hace nada.
            IF dbo.LetFEProveedor() = 'EFISCAL' AND dbo.LetFETipoEcf(@TipoComprobante) IS NOT NULL AND OBJECT_ID(N'dbo.LetFESecuenciaControl') IS NOT NULL
            BEGIN
                DECLARE @CtlOk BIT, @CtlMsg NVARCHAR(300);
                DECLARE @Ctl TABLE (Permitido BIT, Modo VARCHAR(12), Nivel VARCHAR(14), Mensaje NVARCHAR(300), Disponibles BIGINT, ContingenciaDisponibles BIGINT, TipoEcf INT);
                DECLARE @CtlEv TABLE (TipoEcf INT, Documento CHAR(1), Modo VARCHAR(12), Mensaje NVARCHAR(300));
                INSERT @Ctl EXEC dbo.LetFESecuenciaControl @TipoAgora = @TipoComprobante, @PosId = @PosId, @Aplicar = 1;
                SELECT TOP (1) @CtlOk = Permitido, @CtlMsg = Mensaje FROM @Ctl;
                IF ISNULL(@CtlOk, 1) = 0
                BEGIN
                    INSERT @CtlEv (TipoEcf, Documento, Modo, Mensaje) SELECT TipoEcf, 'F', 'BLOQUEADO', Mensaje FROM @Ctl;
                    RAISERROR(N'%s', 16, 1, @CtlMsg);
                END
            END
            IF dbo.LetFEProveedor() = 'EFISCAL' AND dbo.LetFETipoEcf(@TipoComprobante) IS NOT NULL
                EXEC dbo.LetFENcfProvisional @TipoComprobante, @NCF OUTPUT;
            ELSE
            BEGIN
                EXEC AumentarContadorFiscal @TipoComprobante, @NCF OUTPUT;
                IF @NCF IS NULL
                    RAISERROR('NO HAY SECUENCIA DE COMPROBANTES FISCALES CONFIGURADA PARA EL TIPO %d', 16, 1, @TipoComprobante);
            END
            EXEC BuscarNombreRNC @RNC, @RazoSocial OUTPUT;

            INSERT INTO [dbo].[Factura]
                ([Serie], [Numero], [BaseImponible], [Impuestos], [TotalNeto], [Fecha], [Propina],
                 [MensajePropina], [Ubicacion], [Mesa], [Usuario], [IdInvoice], [IdTicket],
                 [RelatedInvoiceId], [TasaUSD], [MontoTotalUSD], [Descuento], [DescuentoPorcentaje],
                 [MontoTotalDescuento], [PosId], [IdCliente], [CodigoCliente], [NombreCliente])
            SELECT
                [Serie], [Numero], [BaseImponible], [Impuestos], [TotalNeto], [Fecha], [Propina],
                [MensajePropina], [Ubicacion], [Mesa], [Usuario], [IdInvoice], [IdTicket],
                [RelatedInvoiceId], [TasaUSD], [MontoTotalUSD], [Descuento], [DescuentoPorcentaje],
                [MontoTotalDescuento], [PosId], [IdCliente], @CodigoCliente, [NombreCliente]
            FROM @udtFactura;

            INSERT INTO [dbo].[FacturaDetalle]
                ([Serie], [Numero], [Linea], [Descripcion], [Cantidad], [Precio], [Impuesto], [Importe],
                 [IdTicket], [IdTicketLine], [IdInvoice], [TasaImpuesto], [PrecioUnitario], [MontoTotal],
                 [MontoDescuento], [PorcentajeDescuento], [MontoTotalDescuento], [PosId], [ImpuestoId])
            SELECT
                [Serie], [Numero], [Linea], [Descripcion], [Cantidad], [Precio], [Impuesto], [Importe],
                [IdTicket], [IdTicketLine], [IdInvoice], [TasaImpuesto], [PrecioUnitario], [MontoTotal],
                [MontoDescuento], [PorcentajeDescuento], [MontoTotalDescuento], [PosId], [ImpuestoId]
            FROM @udtFacturaDetalle;

            INSERT INTO [dbo].[FacturaComprobanteFiscal]
                ([Serie], [Numero], [Tipo], [NCF], [RNC], [RazonSocial], [PosId])
            VALUES
                (@Serie, @Number, @TipoComprobante, @NCF, @RNC, @RazoSocial, @PosId);

            -- Pagos combinados: al cobrar por la API, Agora pasa a la factura solo el pago que cierra el ticket; los
            -- anteriores quedan en DocumentPayment con TicketId y sin InvoiceId, y el cierre de caja no los cuenta.
            -- Se pasan aqui a la factura, solo si con ellos los pagos dan exacto el total (si no, no se toca nada).
            DECLARE @IdTicket int, @IdInvoice int;
            SELECT TOP (1) @IdTicket = [IdTicket], @IdInvoice = [IdInvoice] FROM @udtFactura;
            DECLARE @PagosDelTicket TABLE ([Id] int, [MethodId] int, [PosId] int, [Date] datetime, [PaidAmount] decimal(18,3),
                                           [ChangeAmount] decimal(18,3), [TipAmount] decimal(18,3), [ExtraInformation] nvarchar(max));
            IF @IdTicket IS NOT NULL AND @IdInvoice IS NOT NULL
               AND EXISTS (SELECT 1 FROM dbo.DocumentPayment WHERE TicketId = @IdTicket AND InvoiceId IS NULL)
               AND ABS((SELECT Net FROM dbo.Invoice WHERE Id = @IdInvoice)
                       - ISNULL((SELECT SUM(PaidAmount - ChangeAmount) FROM dbo.DocumentPayment WHERE InvoiceId = @IdInvoice), 0)
                       - (SELECT SUM(PaidAmount - ChangeAmount) FROM dbo.DocumentPayment WHERE TicketId = @IdTicket AND InvoiceId IS NULL)) < 0.01
            BEGIN
                UPDATE dbo.DocumentPayment
                   SET InvoiceId = @IdInvoice, TicketId = NULL
                OUTPUT inserted.Id, inserted.MethodId, inserted.PosId, inserted.[Date], inserted.PaidAmount, inserted.ChangeAmount,
                       inserted.TipAmount, inserted.ExtraInformation INTO @PagosDelTicket
                 WHERE TicketId = @IdTicket AND InvoiceId IS NULL;
            END

            -- La respuesta de Agora suele traer esos pagos como anticipo (IsPrepayment) y ya vienen en @udtPayment:
            -- solo se agregan a FacturaFormaPago si con @udtPayment no se llega al total.
            IF ABS((SELECT Net FROM dbo.Invoice WHERE Id = @IdInvoice)
                   - ISNULL((SELECT SUM([PaidAmount] - [ChangeAmount]) FROM @udtPayment), 0)) >= 0.01
            INSERT INTO [dbo].[FacturaFormaPago]
                ([IdPago], [Serie], [Numero], [IdFormaPago], [PosId], [IdTransaccionTarjeta], [Fecha],
                 [TotalPagado], [TotalDevuelta], [TotalPropina], [InformacionExtra], [DescripcionPago])
            SELECT p.[Id], @Serie, @Number, p.[MethodId], p.[PosId], 0, p.[Date], p.[PaidAmount], p.[ChangeAmount],
                   ISNULL(p.[TipAmount], 0), p.[ExtraInformation], m.[Name]
            FROM @PagosDelTicket p
            LEFT JOIN dbo.PaymentMethod m ON m.Id = p.[MethodId]
            ORDER BY p.[Date];

            INSERT INTO [dbo].[FacturaFormaPago]
                ([IdPago], [Serie], [Numero], [IdFormaPago], [PosId], [IdTransaccionTarjeta], [Fecha],
                 [TotalPagado], [TotalDevuelta], [TotalPropina], [InformacionExtra], [DescripcionPago])
            SELECT
                0 IdPago,
                @Serie Serie,
                @Number Numero,
                [MethodId] IdFormaPago,
                [PosId],
                0 IdTransaccionTarjeta,
                [Date] Fecha,
                [PaidAmount] TotalPagado,
                [ChangeAmount] TotalDevuelta,
                ISNULL([TipAmount], 0) TotalPropina,
                [ExtraInformation] InformacionExtra,
                [MethodName] DescripcionPago
            FROM @udtPayment

            INSERT INTO [dbo].[FacturaDetalleAddin]
                ([Serie], [Numero], [LineaTicket], [FormatoIdVenta], [NombreProducto], [Precio],
                 [IdImpuesto], [TasaImpuesto], [PrecioCosto], [AddinIndex], [PosId])
            SELECT
                [Serie], [Numero], [LineaTicket], [FormatoIdVenta], [NombreProducto], [Precio],
                [IdImpuesto], [TasaImpuesto], [PrecioCosto], [AddinIndex], [PosId]
            FROM @udtFacturaDetalleAddin;

            -- Datos fiscales en las notas de la factura de Agora (Invoice.Notes), separados por |, para que viajen
            -- a la central con la venta:
            --   normal:     NCF, o NCF|RNC|RazonSocial si el comprobante lleva cliente
            --   duty free:  NCF|RNC|RazonSocial|Nombre|Pasaporte|Nacionalidad|VueloCrucero (siempre las 7 posiciones)
            -- Se quita el | de lo que escribio el cajero para no correr las posiciones.
            DECLARE @DutyFree bit = ISNULL((SELECT TOP (1) DutyFree FROM dbo.LetConfiguracionFiscal), 0);
            DECLARE @NotaRnc nvarchar(50)   = REPLACE(LTRIM(RTRIM(ISNULL(@RNC, ''))), N'|', N' '),
                    @NotaRazon nvarchar(200) = REPLACE(LTRIM(RTRIM(ISNULL(@RazoSocial, ''))), N'|', N' '),
                    @PasNombre nvarchar(100) = REPLACE(LTRIM(RTRIM(ISNULL(@PasajeroNombre, ''))), N'|', N' '),
                    @PasPasaporte nvarchar(30) = REPLACE(LTRIM(RTRIM(ISNULL(@PasajeroPasaporte, ''))), N'|', N' '),
                    @PasNacionalidad nvarchar(50) = REPLACE(LTRIM(RTRIM(ISNULL(@PasajeroNacionalidad, ''))), N'|', N' '),
                    @PasVuelo nvarchar(50) = REPLACE(LTRIM(RTRIM(ISNULL(@PasajeroVueloCrucero, ''))), N'|', N' ');
            DECLARE @Notas nvarchar(1000) =
                CASE WHEN @DutyFree = 1
                         THEN CONCAT(@NCF, N'|', @NotaRnc, N'|', @NotaRazon, N'|', @PasNombre, N'|', @PasPasaporte,
                                     N'|', @PasNacionalidad, N'|', @PasVuelo)
                     WHEN @NotaRnc = N'' THEN @NCF
                     ELSE CONCAT(@NCF, N'|', @NotaRnc, N'|', @NotaRazon) END;
            UPDATE Invoice SET Notes = LEFT(@Notas, 512) WHERE Serie = @Serie AND Number = @Number;

            -- Duty free: una fila por factura aunque el cajero dejara los datos en blanco (reporte a la DGA).
            IF @DutyFree = 1
                INSERT INTO dbo.LetDutyFreePasajero
                    ([Serie], [Numero], [NCF], [PosId], [Fecha], [NombreCliente], [Pasaporte], [Nacionalidad], [VueloCrucero])
                SELECT @Serie, @Number, @NCF, @PosId, ISNULL((SELECT TOP (1) [Fecha] FROM @udtFactura), GETDATE()),
                       NULLIF(@PasNombre, N''), NULLIF(@PasPasaporte, N''), NULLIF(@PasNacionalidad, N''), NULLIF(@PasVuelo, N'');

            Update Factura Set CodigoCliente = @CodigoCliente,
                               NombreCliente = @NombreCliente,
                               Telefono = @Telefono,
                               Direccion = @Direccion,
                               PuntoPendiente = @PuntoPendiente
                               where Serie = @Serie and Numero = @Number

            -- Regimenes especiales (B14 / E44): la venta es exenta de ITBIS. Agora cobro el ITBIS en el ticket y la
            -- pantalla lo cubrio con la forma de pago de exencion (codigo EX): el ticket cuadra en Agora y el cliente
            -- paga la base y la propina. La factura queda sin ITBIS.
            -- Tambien un tipo de Agora que el tecnico relaciono con el e-CF 44 en el instalador.
            IF @TipoComprobante IN (14, 44) OR (dbo.LetFEProveedor() = 'EFISCAL' AND dbo.LetFETipoEcf(@TipoComprobante) = 44)
                EXEC dbo.LetAplicarExencion @Serie, @Number;

            -- Comprobante electronico (e-CF, tipos 31 en adelante): se deja en WebPOS para enviarlo a la DGII.
            -- Va en la misma transaccion: si WebPOS falla no queda una factura electronica sin enviar.
            IF @TipoComprobante >= 31 AND EXISTS (SELECT 1 FROM dbo.LetWebPosCompanyList)
                EXEC RegistrarFEWebpos @Serie, @Number

            -- Lo recibido en moneda extranjera (dolares...) con la tasa de este momento, para el cierre de turno y de jornada.
            IF OBJECT_ID(N'dbo.LetRegistrarPagosMoneda') IS NOT NULL
                EXEC dbo.LetRegistrarPagosMoneda @Serie, @Number;

            -- Con e-Fiscal Cloud la factura queda en la cola de envio (misma transaccion): el servicio de impresion la envia.
            IF dbo.LetFEProveedor() = 'EFISCAL' AND dbo.LetFETipoEcf(@TipoComprobante) IS NOT NULL
            BEGIN
                EXEC dbo.LetFERegistrar @Serie, @Number, 'F'

                -- Cierre operativo interno: si coinciden el cliente configurado, su forma de pago activadora, la habilitacion de la caja y el
                -- permiso del usuario, el comprobante queda PENDIENTE DE FISCALIZAR (no se envia) y el ticket sale como documento interno.
                -- Si no coinciden no hace nada: el cierre habitual sigue igual. Va dentro de la misma transaccion y solo la primera vez.
                IF OBJECT_ID(N'dbo.LetFlujoInternoCerrar', N'P') IS NOT NULL
                    EXEC dbo.LetFlujoInternoCerrar @Serie, @Number
            END
        END

        -- Datos para imprimir (la API los lee en este orden).
        EXEC dbo.LetDatosImpresionFactura @Serie, @Number;

        SET @Mensaje = '';
        SET @Respuesta = 0;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        SET @Mensaje = ERROR_MESSAGE();
        SET @Respuesta = 1;

        -- Primero se deshace la transaccion; si no, el registro del error tambien se perderia.
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        -- El bloqueo por falta de secuencia queda anotado para avisarlo por las alertas (la transaccion ya se deshizo).
        INSERT dbo.LetFEControlSecuenciaEvento (TipoEcf, Documento, Modo, Mensaje) SELECT TipoEcf, Documento, Modo, Mensaje FROM @CtlEv;

        INSERT INTO LogErrores (ErrorID, UserName, ErrorNumber, ErrorState, ErrorSeverity, ErrorLine, ErrorProcedure, ErrorMessage, ErrorDateTime)
        VALUES (0, SUSER_SNAME(), ERROR_NUMBER(), ERROR_STATE(), ERROR_SEVERITY(),
                ERROR_LINE(), ERROR_PROCEDURE(), ERROR_MESSAGE(), GETDATE());

        THROW;
    END CATCH;
END;
GO

------------------------------------------------------------ [dbo].[RegistrarNotaDeCreditoAgora]
IF OBJECT_ID(N'[dbo].[RegistrarNotaDeCreditoAgora]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[RegistrarNotaDeCreditoAgora] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[RegistrarNotaDeCreditoAgora]
    @Serie nvarchar(10),
    @Number int,
    @udtPayment udtPayment readonly,
	@Mensaje varchar(max) output,
    @Respuesta int output
AS
begin
    set nocount on;
	    BEGIN TRY
        BEGIN TRANSACTION;

	    DECLARE @NCF varchar(19), @NCFAfectado varchar(19);
		
        DECLARE @RazoSocial nvarchar(200);
		DECLARE @PosId int, @IdInvoice int;
        IF NOT EXISTS (SELECT 1 FROM Invoice WHERE Serie = @Serie AND Number = @Number)
            RAISERROR('NO EXISTE LA DEVOLUCION %s-%d EN AGORA', 16, 1, @Serie, @Number);

        -- Un reintento no debe duplicar la nota ni gastar otro NCF.
        IF EXISTS (SELECT 1 FROM [dbo].[Factura] WITH (UPDLOCK, HOLDLOCK) WHERE Serie = @Serie AND Numero = @Number)
        BEGIN
            SET @Mensaje = 'ESTE NUMERO DE DEVOLUCION YA FUE REALIZADA';
            SET @Respuesta = 0;
            COMMIT TRANSACTION;
            RETURN;
        END

        -- Comprobante de nota de credito: electronico (34) o, si el cliente aun no factura electronico, B04 (4).
        -- Con e-Fiscal Cloud la nota de credito es siempre electronica (34) y no necesita una secuencia en Agora.
        DECLARE @TipoNC int = CASE WHEN dbo.LetFEProveedor() = 'EFISCAL' AND dbo.LetFETipoEcf(34) = 34 THEN 34
                                   WHEN EXISTS (SELECT 1 FROM NCFSecuencia WHERE TipoNCFID = 34 AND [Status] = 'A') THEN 34 ELSE 4 END;
        -- El e-NCF de la nota lo asigna la plataforma: este es solo un marcador (ver CrearFacturaAgora).
        -- Control de secuencia (121_control_secuencia.sql): sin secuencia activa de E34 la nota de credito no se emite (nunca va en contingencia).
        IF dbo.LetFEProveedor() = 'EFISCAL' AND dbo.LetFETipoEcf(@TipoNC) = 34 AND OBJECT_ID(N'dbo.LetFESecuenciaControl') IS NOT NULL
        BEGIN
            DECLARE @CtlOk BIT, @CtlMsg NVARCHAR(300);
            DECLARE @Ctl TABLE (Permitido BIT, Modo VARCHAR(12), Nivel VARCHAR(14), Mensaje NVARCHAR(300), Disponibles BIGINT, ContingenciaDisponibles BIGINT, TipoEcf INT);
            DECLARE @CtlEv TABLE (TipoEcf INT, Documento CHAR(1), Modo VARCHAR(12), Mensaje NVARCHAR(300));
            INSERT @Ctl EXEC dbo.LetFESecuenciaControl @TipoAgora = @TipoNC, @PosId = NULL, @Aplicar = 1, @Documento = 'N';
            SELECT TOP (1) @CtlOk = Permitido, @CtlMsg = Mensaje FROM @Ctl;
            IF ISNULL(@CtlOk, 1) = 0
            BEGIN
                INSERT @CtlEv (TipoEcf, Documento, Modo, Mensaje) SELECT TipoEcf, 'N', 'BLOQUEADO', Mensaje FROM @Ctl;
                RAISERROR(N'%s', 16, 1, @CtlMsg);
            END
        END
        IF dbo.LetFEProveedor() = 'EFISCAL' AND dbo.LetFETipoEcf(@TipoNC) = 34
            EXEC dbo.LetFENcfProvisional @TipoNC, @NCF OUTPUT;
        ELSE
        BEGIN
            EXEC AumentarContadorFiscal @TipoNC, @NCF OUTPUT;
            IF @NCF IS NULL
                RAISERROR('NO HAY SECUENCIA DE COMPROBANTES FISCALES CONFIGURADA PARA NOTAS DE CREDITO (TIPO 34 O 4)', 16, 1);
        END
        SELECT @PosId = [PosId] FROM Invoice where Serie=@Serie and Number=@Number
		SELECT @IdInvoice = [RelatedInvoiceId] FROM Invoice where Serie=@Serie and Number=@Number 



        -- Cabecera y detalle con el ITBIS y la propina legal separados (mismo calculo que la factura).
        INSERT INTO [dbo].[Factura]
            ([Serie], [Numero], [BaseImponible], [Impuestos], [TotalNeto], [Fecha], [Propina],
             [MensajePropina], [Ubicacion], [Mesa], [Usuario], [IdInvoice], [IdTicket],
             [RelatedInvoiceId], [TasaUSD], [MontoTotalUSD], [Descuento], [DescuentoPorcentaje],
             [MontoTotalDescuento], [PosId], [IdCliente], [CodigoCliente], [NombreCliente])
        SELECT [Serie], [Numero], [BaseImponible], [Impuestos], [TotalNeto], [Fecha], [Propina],
               [MensajePropina], [Ubicacion], [Mesa], [Usuario], [IdInvoice], [IdTicket],
               [RelatedInvoiceId], [TasaUSD], [MontoTotalUSD], [Descuento], [DescuentoPorcentaje],
               [MontoTotalDescuento], [PosId], 0, '', ''
          FROM dbo.LetFacturaAgoraCabecera(@Serie, @Number);

        INSERT INTO [dbo].[FacturaDetalle]
            ([Serie], [Numero], [Linea], [Descripcion], [Cantidad], [Precio], [Impuesto], [Importe],
             [IdTicket], [IdTicketLine], [IdInvoice], [TasaImpuesto], [PrecioUnitario], [MontoTotal],
             [MontoDescuento], [PorcentajeDescuento], [MontoTotalDescuento], [PosId], [ImpuestoId])
        SELECT [Serie], [Numero], [Linea], [Descripcion], [Cantidad], [Precio], [Impuesto], [Importe],
               [IdTicket], [IdTicketLine], [IdInvoice], [TasaImpuesto], [PrecioUnitario], [MontoTotal],
               [MontoDescuento], [PorcentajeDescuento], [MontoTotalDescuento], [PosId], [ImpuestoId]
          FROM dbo.LetFacturaAgoraDetalle(@Serie, @Number);

INSERT INTO [dbo].[FacturaFormaPago]
            ([IdPago], [Serie], [Numero], [IdFormaPago], [PosId], [IdTransaccionTarjeta], [Fecha],
             [TotalPagado], [TotalDevuelta], [TotalPropina], [InformacionExtra], [DescripcionPago])
 SELECT 
          0 IdPago,
          @Serie Serie,
          @Number Numero,
          [MethodId] IdFormaPago,
          [PosId],
          0 IdTransaccionTarjeta,
          [Date] Fecha,
          [Amount] TotalPagado,
          [ChangeAmount] TotalDevuelta,
          [TipAmount] TotalPropina,
          [ExtraInformation] InformacionExtra,
          [MethodName] DescripcionPago
         FROM @udtPayment	


        -- Comprobante que se modifica: la nota lleva su NCF y el mismo comprador (RNC y razon social).
        DECLARE @TipoAfectado int, @RNCAfectado varchar(20), @RazonAfectada nvarchar(200);
        SELECT TOP (1) @NCFAfectado = fc.NCF, @TipoAfectado = fc.Tipo, @RNCAfectado = fc.RNC, @RazonAfectada = fc.RazonSocial
          FROM Factura f
         INNER JOIN FacturaComprobanteFiscal fc ON f.Serie = fc.Serie AND f.Numero = fc.Numero
         WHERE f.IdInvoice = @IdInvoice
         ORDER BY fc.Id;

        INSERT INTO [dbo].[FacturaComprobanteFiscal]
            ([Serie], [Numero], [Tipo], [NCF], [RNC], [RazonSocial], [PosId], [NCFAfectado])
        VALUES
            (@Serie, @Number, @TipoNC, @NCF, ISNULL(@RNCAfectado, ''), ISNULL(@RazonAfectada, ''), @PosId, @NCFAfectado);

        -- Devolucion de una factura de regimen especial: tambien sin ITBIS.
        IF @TipoAfectado IN (14, 44) OR (dbo.LetFEProveedor() = 'EFISCAL' AND dbo.LetFETipoEcf(@TipoAfectado) = 44)
            EXEC dbo.LetAplicarExencion @Serie, @Number;

        -- Nota de credito electronica (34): se deja en WebPOS para enviarla a la DGII.
        IF @TipoNC = 34 AND EXISTS (SELECT 1 FROM dbo.LetWebPosCompanyList)
            EXEC RegistrarNotaDeCreditoFEWebpos @Serie, @Number, @NCFAfectado

        -- Devolucion de lo recibido en moneda extranjera (en negativo).
        IF OBJECT_ID(N'dbo.LetRegistrarPagosMoneda') IS NOT NULL
            EXEC dbo.LetRegistrarPagosMoneda @Serie, @Number;

        -- Con e-Fiscal Cloud la nota queda en la cola de envio; se envia cuando su factura esta aceptada.
        IF dbo.LetFEProveedor() = 'EFISCAL' AND dbo.LetFETipoEcf(@TipoNC) = 34
            EXEC dbo.LetFERegistrar @Serie, @Number, 'N'
   -- Set success response
        SET @Mensaje = '';
        SET @Respuesta = 1;

 COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
	    SET @Mensaje = ERROR_MESSAGE();
        SET @Respuesta = 0;
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
        INSERT dbo.LetFEControlSecuenciaEvento (TipoEcf, Documento, Modo, Mensaje) SELECT TipoEcf, Documento, Modo, Mensaje FROM @CtlEv;
      -- Handle errors
       
        INSERT INTO dbo.LogErrores
        (
            ErrorID,
            UserName,
            ErrorNumber,
            ErrorState,
            ErrorSeverity,
            ErrorLine,
            ErrorProcedure,
            ErrorMessage,
            ErrorDateTime
        )
        VALUES
        (
            ERROR_NUMBER(),
            SUSER_SNAME(),
            ERROR_NUMBER(),
            ERROR_STATE(),
            ERROR_SEVERITY(),
            ERROR_LINE(),
            ERROR_PROCEDURE(),
            ERROR_MESSAGE(),
            GETDATE()
        );

        THROW;
    END CATCH
END;
GO

