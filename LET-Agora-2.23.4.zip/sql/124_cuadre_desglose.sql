/* =====================================================================================================
   124_cuadre_desglose.sql  -  Desglose del efectivo (cuantos billetes y monedas de cada valor) y ajustes de cuadres ya hechos.
   - dbo.LetCuadreDesglose: lo que conto el cajero por valor, para cada forma de pago en efectivo del cuadre.
   - dbo.LetCuadreDesgloseGuardar(@CuadreId, @Desglose): @Desglose = 'metodoId:valor*cantidad,valor*cantidad;metodoId:...' (punto decimal).
   - dbo.LetCuadreDesgloseLeer(@Id): el desglose de un cuadre con el nombre y la moneda de cada forma de pago.
   - dbo.LetCuadre.AjusteDe / Motivo / Ajustado: un ajuste NO cambia el cuadre original: crea otro cuadre que lo reemplaza (ver LetCuadreAjustar).
   - dbo.LetCuadreLista(@Desde, @Hasta, @PosId, @Tipo): la consulta de cuadres hechos.
   - dbo.LetCuadreAjustar(@Id, @Lineas, @Motivo, @Pin): vuelve a declarar un cuadre guardado, con motivo obligatorio y la contrasena de un usuario de Agora.
   No lleva variables del instalador.
   ===================================================================================================== */
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'dbo.LetCuadreDesglose', N'U') IS NULL
CREATE TABLE dbo.LetCuadreDesglose (
    Id           INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_LetCuadreDesglose PRIMARY KEY,
    CuadreId     INT           NOT NULL,
    MetodoId     INT           NOT NULL,
    Denominacion DECIMAL(14,2) NOT NULL,
    Cantidad     INT           NOT NULL
)
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_LetCuadreDesglose_Cuadre' AND object_id = OBJECT_ID(N'dbo.LetCuadreDesglose'))
    CREATE INDEX IX_LetCuadreDesglose_Cuadre ON dbo.LetCuadreDesglose (CuadreId, MetodoId)
GO
IF COL_LENGTH(N'dbo.LetCuadre', N'AjusteDe') IS NULL ALTER TABLE dbo.LetCuadre ADD AjusteDe INT NULL
GO
IF COL_LENGTH(N'dbo.LetCuadre', N'Motivo') IS NULL ALTER TABLE dbo.LetCuadre ADD Motivo NVARCHAR(500) NULL
GO
IF COL_LENGTH(N'dbo.LetCuadre', N'Ajustado') IS NULL ALTER TABLE dbo.LetCuadre ADD Ajustado BIT NOT NULL CONSTRAINT DF_LetCuadre_Ajustado DEFAULT (0)
GO

IF OBJECT_ID(N'[dbo].[LetCuadreDesgloseGuardar]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetCuadreDesgloseGuardar] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetCuadreDesgloseGuardar] (@CuadreId INT, @Desglose NVARCHAR(MAX))
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM dbo.LetCuadre WHERE Id = @CuadreId) OR ISNULL(@Desglose, N'') = N'' RETURN;
    DELETE dbo.LetCuadreDesglose WHERE CuadreId = @CuadreId;
    DECLARE @r NVARCHAR(MAX) = @Desglose + N';', @bloque NVARCHAR(MAX), @p INT, @metodo INT, @lista NVARCHAR(MAX), @par NVARCHAR(100), @q INT, @den DECIMAL(14,2), @cant INT;
    WHILE LEN(@r) > 0
    BEGIN
        SET @p = CHARINDEX(N';', @r);
        SET @bloque = LEFT(@r, @p - 1); SET @r = SUBSTRING(@r, @p + 1, LEN(@r));
        IF @bloque = N'' CONTINUE;
        SET @q = CHARINDEX(N':', @bloque);
        IF @q = 0 CONTINUE;
        SET @metodo = TRY_CONVERT(INT, LEFT(@bloque, @q - 1)); SET @lista = SUBSTRING(@bloque, @q + 1, LEN(@bloque)) + N',';
        IF @metodo IS NULL OR NOT EXISTS (SELECT 1 FROM dbo.LetCuadreLinea WHERE CuadreId = @CuadreId AND MetodoId = @metodo) CONTINUE;
        WHILE LEN(@lista) > 0
        BEGIN
            SET @p = CHARINDEX(N',', @lista);
            SET @par = LEFT(@lista, @p - 1); SET @lista = SUBSTRING(@lista, @p + 1, LEN(@lista));
            SET @q = CHARINDEX(N'*', @par);
            IF @q = 0 CONTINUE;
            SET @den = TRY_CONVERT(DECIMAL(14,2), LEFT(@par, @q - 1)); SET @cant = TRY_CONVERT(INT, SUBSTRING(@par, @q + 1, 20));
            IF @den IS NOT NULL AND @den > 0 AND @cant IS NOT NULL AND @cant > 0 AND @cant <= 100000
                INSERT dbo.LetCuadreDesglose (CuadreId, MetodoId, Denominacion, Cantidad) VALUES (@CuadreId, @metodo, @den, @cant);
        END
    END
END
GO

IF OBJECT_ID(N'[dbo].[LetCuadreDesgloseLeer]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetCuadreDesgloseLeer] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetCuadreDesgloseLeer] (@Id INT)
AS
BEGIN
    SET NOCOUNT ON;
    SELECT d.MetodoId, ISNULL(l.Nombre, N'') AS Nombre, ISNULL(l.Moneda, N'DOP') AS Moneda, d.Denominacion, d.Cantidad
      FROM dbo.LetCuadreDesglose d
      LEFT JOIN dbo.LetCuadreLinea l ON l.CuadreId = d.CuadreId AND l.MetodoId = d.MetodoId
     WHERE d.CuadreId = @Id
     ORDER BY d.MetodoId, d.Denominacion DESC;
END
GO

-- La lista de cuadres hechos (el ultimo primero). Un cuadre ajustado sale marcado: lo reemplaza el que tiene AjusteDe = su numero.
IF OBJECT_ID(N'[dbo].[LetCuadreLista]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetCuadreLista] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetCuadreLista] (@Desde DATE = NULL, @Hasta DATE = NULL, @PosId INT = NULL, @Tipo VARCHAR(10) = NULL, @Max INT = 200)
AS
BEGIN
    SET NOCOUNT ON;
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    SET @Hasta = ISNULL(@Hasta, CAST(GETDATE() AS DATE));
    SET @Desde = ISNULL(@Desde, DATEADD(DAY, -7, @Hasta));
    IF @Max IS NULL OR @Max < 1 OR @Max > 500 SET @Max = 200;
    SELECT TOP (@Max) c.Id, c.PosId, c.Caja, c.Jornada, c.Turno, c.Tipo, c.Usuario, c.Cuadra, c.Fecha, c.AjusteDe, c.Motivo, c.Ajustado,
           ISNULL((SELECT SUM(l.Diferencia) FROM dbo.LetCuadreLinea l WHERE l.CuadreId = c.Id AND l.Moneda = N'DOP'), 0) AS DiferenciaDOP,
           (SELECT COUNT(*) FROM dbo.LetCuadreLinea l WHERE l.CuadreId = c.Id AND l.Diferencia <> 0) AS FormasConDiferencia
      FROM dbo.LetCuadre c
     WHERE c.Fecha >= @Desde AND c.Fecha < DATEADD(DAY, 1, @Hasta) AND (@PosId IS NULL OR c.PosId = @PosId) AND (@Tipo IS NULL OR c.Tipo = @Tipo)
     ORDER BY c.Fecha DESC, c.Id DESC;
END
GO

-- Ajusta un cuadre guardado: el original queda como estaba (marcado Ajustado) y se crea otro con lo nuevo declarado, el mismo esperado, el motivo y el numero
-- del cuadre que reemplaza. @Lineas = 'metodoId:monto;metodoId:monto'. La contrasena es la de un usuario de Agora y queda como quien ajusto.
IF OBJECT_ID(N'[dbo].[LetCuadreAjustar]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetCuadreAjustar] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetCuadreAjustar] (@Id INT, @Lineas NVARCHAR(MAX), @Motivo NVARCHAR(500), @Pin NVARCHAR(50), @Simular BIT = 0)
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @n INT, @UsuarioId INT, @Usuario NVARCHAR(100), @Nuevo INT;
    SET @Motivo = LTRIM(RTRIM(ISNULL(@Motivo, N'')));
    IF LEN(@Motivo) < 5 BEGIN SELECT CAST(0 AS BIT) AS Ok, CAST(NULL AS INT) AS CuadreId, N'Escriba el motivo del ajuste (minimo 5 letras)' AS Mensaje; RETURN; END
    IF NOT EXISTS (SELECT 1 FROM dbo.LetCuadre WHERE Id = @Id AND Ajustado = 0) BEGIN SELECT CAST(0 AS BIT) AS Ok, CAST(NULL AS INT) AS CuadreId, N'Ese cuadre no existe o ya fue ajustado' AS Mensaje; RETURN; END

    SELECT @n = COUNT(*) FROM dbo.[User] WHERE DeletionDate IS NULL AND ISNULL(@Pin, N'') <> N'' AND Password = @Pin;
    IF @n = 0 BEGIN SELECT CAST(0 AS BIT) AS Ok, CAST(NULL AS INT) AS CuadreId, N'Contrasena incorrecta' AS Mensaje; RETURN; END
    IF @n > 1 BEGIN SELECT CAST(0 AS BIT) AS Ok, CAST(NULL AS INT) AS CuadreId, N'Esa contrasena la usan varios usuarios: pida al administrador que le asigne una propia' AS Mensaje; RETURN; END
    SELECT @UsuarioId = Id, @Usuario = Name FROM dbo.[User] WHERE DeletionDate IS NULL AND Password = @Pin;

    -- lo nuevo declarado por forma de pago (las que no vengan conservan lo declarado antes)
    CREATE TABLE #N (MetodoId INT PRIMARY KEY, Monto DECIMAL(14,2));
    DECLARE @r NVARCHAR(MAX) = ISNULL(@Lineas, N'') + N';', @par NVARCHAR(100), @p INT, @q INT;
    WHILE LEN(@r) > 0
    BEGIN
        SET @p = CHARINDEX(N';', @r); SET @par = LEFT(@r, @p - 1); SET @r = SUBSTRING(@r, @p + 1, LEN(@r));
        SET @q = CHARINDEX(N':', @par);
        IF @q > 0 AND TRY_CONVERT(INT, LEFT(@par, @q - 1)) IS NOT NULL AND TRY_CONVERT(DECIMAL(14,2), SUBSTRING(@par, @q + 1, 30)) IS NOT NULL
           AND NOT EXISTS (SELECT 1 FROM #N WHERE MetodoId = TRY_CONVERT(INT, LEFT(@par, @q - 1)))
            INSERT #N VALUES (TRY_CONVERT(INT, LEFT(@par, @q - 1)), TRY_CONVERT(DECIMAL(14,2), SUBSTRING(@par, @q + 1, 30)));
    END
    IF EXISTS (SELECT 1 FROM #N WHERE Monto < 0 OR Monto > 999999999) BEGIN SELECT CAST(0 AS BIT) AS Ok, CAST(NULL AS INT) AS CuadreId, N'Hay un monto que no es valido' AS Mensaje; RETURN; END
    IF EXISTS (SELECT 1 FROM #N n WHERE NOT EXISTS (SELECT 1 FROM dbo.LetCuadreLinea l WHERE l.CuadreId = @Id AND l.MetodoId = n.MetodoId)) BEGIN SELECT CAST(0 AS BIT) AS Ok, CAST(NULL AS INT) AS CuadreId, N'Hay una forma de pago que no es de ese cuadre' AS Mensaje; RETURN; END

    CREATE TABLE #L (MetodoId INT, Nombre NVARCHAR(100), Tipo VARCHAR(12), Moneda VARCHAR(5), Esperado DECIMAL(14,2), Declarado DECIMAL(14,2));
    INSERT #L SELECT l.MetodoId, l.Nombre, l.Tipo, l.Moneda, l.Esperado, ISNULL(n.Monto, l.Declarado) FROM dbo.LetCuadreLinea l LEFT JOIN #N n ON n.MetodoId = l.MetodoId WHERE l.CuadreId = @Id;

    IF @Simular = 1
    BEGIN
        SELECT CAST(1 AS BIT) AS Ok, CAST(NULL AS INT) AS CuadreId, N'Vista previa del ajuste' AS Mensaje, @Usuario AS Usuario;
        SELECT MetodoId, Nombre, Tipo, Moneda, Esperado, Declarado, CAST(Declarado - Esperado AS DECIMAL(14,2)) AS Diferencia FROM #L ORDER BY CASE WHEN Tipo = 'EFECTIVO' THEN 0 ELSE 1 END, Nombre;
        RETURN;
    END

    BEGIN TRANSACTION;
    INSERT dbo.LetCuadre (PosId, Caja, Jornada, Turno, Tipo, UsuarioId, Usuario, Comentario, Cuadra, AjusteDe, Motivo)
    SELECT PosId, Caja, Jornada, Turno, Tipo, @UsuarioId, @Usuario, Comentario, CASE WHEN EXISTS (SELECT 1 FROM #L WHERE Declarado <> Esperado) THEN 0 ELSE 1 END, @Id, @Motivo
      FROM dbo.LetCuadre WHERE Id = @Id;
    SET @Nuevo = SCOPE_IDENTITY();
    INSERT dbo.LetCuadreLinea (CuadreId, MetodoId, Nombre, Tipo, Moneda, Esperado, Declarado)
    SELECT @Nuevo, MetodoId, Nombre, Tipo, Moneda, Esperado, Declarado FROM #L;
    UPDATE dbo.LetCuadre SET Ajustado = 1 WHERE Id = @Id;
    COMMIT;
    SELECT CAST(1 AS BIT) AS Ok, @Nuevo AS CuadreId, N'Cuadre ajustado: ahora es el No. ' + CONVERT(NVARCHAR(12), @Nuevo) AS Mensaje, @Usuario AS Usuario;
END
GO

-- LetCuadreLeer (112) con el numero del cuadre que este reemplaza y el motivo del ajuste, para el ticket y la consulta.
IF OBJECT_ID(N'[dbo].[LetCuadreLeer]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetCuadreLeer] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetCuadreLeer] (@Id INT)
AS
BEGIN
    SET NOCOUNT ON;
    SELECT c.Id, c.PosId, c.Caja, c.Jornada, c.Turno, c.Tipo, c.Usuario, c.Comentario, c.Cuadra, c.Fecha, c.AjusteDe, c.Motivo, c.Ajustado FROM dbo.LetCuadre c WHERE c.Id = @Id;
    SELECT l.MetodoId, l.Nombre, l.Tipo, l.Moneda, l.Esperado, l.Declarado, l.Diferencia FROM dbo.LetCuadreLinea l WHERE l.CuadreId = @Id ORDER BY CASE WHEN l.Tipo = 'EFECTIVO' THEN 0 ELSE 1 END, l.MetodoId;
    IF OBJECT_ID(N'dbo.LetEmisor', N'U') IS NOT NULL
        EXEC (N'SELECT TOP (1) NombreComercial, RazonSocial, RNC FROM dbo.LetEmisor ORDER BY Id');
    ELSE
        SELECT CAST(NULL AS NVARCHAR(200)) AS NombreComercial, CAST(NULL AS NVARCHAR(200)) AS RazonSocial, CAST(NULL AS NVARCHAR(20)) AS RNC WHERE 1 = 0;
END
GO
