/* =====================================================================================================
   122_reporte_jornada.sql  -  Reporte de JORNADA para cuadrar con el fiscalizador. Solo lee.
   El fiscalizador corta cada 24 horas y la jornada de Agora no: este reporte trae TODAS las transacciones de una jornada (desde su apertura
   hasta la ultima cuenta cerrada antes del cierre de jornada, por Invoice.BusinessDay) para compararlas con lo que subio al fiscalizador.
   - Una fila por transaccion y forma de pago. La base, el ITBIS y la propina legal de la transaccion se reparten entre sus formas de pago en
     proporcion a lo pagado (la diferencia de centavos va a la forma de pago mayor), asi la suma por forma de pago cuadra con el total.
   - Quien abrio y quien cerro la cuenta, con sus horas; la hora y el link de validez del e-CF (LetFE_Cola.FechaFirma y QrData).
   - Las ventas que NO se subieron al fiscalizador (operacion interna pendiente de fiscalizar, diferidas, descartadas o sin e-NCF) salen sin datos del
     fiscalizador y con la observacion.
   - Las notas de credito (TD) van en negativo.
   Result sets: 1) resumen de la jornada  2) por forma de pago  3) detalle  4) corte del fiscalizador (por dia de la hora de firma)
   Compatible con SQL Server 2008 (sin CONCAT ni IIF). No lleva variables del instalador.
   ===================================================================================================== */
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'dbo.LetReporteJornada') IS NULL EXEC (N'CREATE PROCEDURE dbo.LetReporteJornada AS RETURN 0')
GO
ALTER PROCEDURE dbo.LetReporteJornada @Jornada DATE = NULL, @PosId INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

    DECLARE @JId INT, @Apertura DATETIME, @CierreJ DATETIME;
    IF @Jornada IS NULL AND OBJECT_ID(N'dbo.SystemCloseOut', N'U') IS NOT NULL
        EXEC sp_executesql N'SELECT TOP (1) @j = CAST(BusinessDay AS DATE) FROM dbo.SystemCloseOut ORDER BY Id DESC', N'@j DATE OUTPUT', @Jornada OUTPUT;
    IF @Jornada IS NULL SET @Jornada = CAST(GETDATE() AS DATE);
    IF OBJECT_ID(N'dbo.SystemCloseOut', N'U') IS NOT NULL
    BEGIN
        EXEC sp_executesql N'SELECT TOP (1) @id = Id, @c = CloseDate FROM dbo.SystemCloseOut WHERE CAST(BusinessDay AS DATE) = @j ORDER BY Id DESC',
                           N'@id INT OUTPUT, @c DATETIME OUTPUT, @j DATE', @JId OUTPUT, @CierreJ OUTPUT, @Jornada;
        IF @JId IS NOT NULL AND COL_LENGTH(N'dbo.SystemCloseOut', N'OpenDate') IS NOT NULL
            EXEC sp_executesql N'SELECT @a = OpenDate FROM dbo.SystemCloseOut WHERE Id = @id', N'@a DATETIME OUTPUT, @id INT', @Apertura OUTPUT, @JId;
    END

    /* ---- Las ventas (T) y notas de credito (TD) de la jornada ---- */
    CREATE TABLE #T (IdInvoice INT PRIMARY KEY, Serie NVARCHAR(10) COLLATE DATABASE_DEFAULT, Numero INT, Signo INT, PosId INT,
                     Base DECIMAL(18,2), Total DECIMAL(18,2), Propina DECIMAL(18,2), Itbis DECIMAL(18,2),
                     Cierre DATETIME, CerradoPor NVARCHAR(100) COLLATE DATABASE_DEFAULT, AperturaCuenta DATETIME, AbiertaPor NVARCHAR(100) COLLATE DATABASE_DEFAULT);
    INSERT INTO #T (IdInvoice, Serie, Numero, Signo, PosId, Base, Total, Propina, Itbis, Cierre, CerradoPor, AperturaCuenta, AbiertaPor)
    SELECT i.Id, i.Serie, i.Number, CASE WHEN i.Serie = 'TD' THEN -1 ELSE 1 END, i.PosId, ABS(i.Gross), ABS(i.Net), 0, 0,
           i.CreationDate, uc.Name, tk.Apertura, ua.Name
      FROM dbo.Invoice i
      LEFT JOIN dbo.[User] uc ON uc.Id = i.UserId
      OUTER APPLY (SELECT TOP (1) t.CreationDate AS Apertura, t.OpenerUserId
                     FROM dbo.InvoiceItem ii JOIN dbo.Ticket t ON t.Id = ii.TicketId
                    WHERE ii.InvoiceId = i.Id ORDER BY t.CreationDate, t.Id) tk
      LEFT JOIN dbo.[User] ua ON ua.Id = tk.OpenerUserId
     WHERE CAST(i.BusinessDay AS DATE) = @Jornada AND i.Serie IN ('T', 'TD') AND (@PosId IS NULL OR i.PosId = @PosId);

    /* ---- Propina legal (igual que el 607): se separa cada tasa de Agora con dbo.LetImpuestos; el ITBIS es el resto ---- */
    CREATE TABLE #Tasa (Tasa DECIMAL(9,6) PRIMARY KEY, Itbis DECIMAL(9,6), Propina DECIMAL(9,6));
    IF OBJECT_ID(N'dbo.LetImpuestos', N'U') IS NOT NULL AND OBJECT_ID(N'dbo.LetConfiguracionFiscal', N'U') IS NOT NULL
        EXEC (N'INSERT INTO #Tasa (Tasa, Itbis, Propina)
                SELECT i.TasaAgora,
                       MAX(CASE WHEN c.TipoNegocio = ''RESTAURANTE'' THEN i.TasaItbis ELSE i.TasaItbis + i.TasaPropina END),
                       MAX(CASE WHEN c.TipoNegocio = ''RESTAURANTE'' THEN i.TasaPropina ELSE 0 END)
                  FROM dbo.LetImpuestos i
                  OUTER APPLY (SELECT TOP (1) TipoNegocio FROM dbo.LetConfiguracionFiscal) c
                 GROUP BY i.TasaAgora');
    IF EXISTS (SELECT 1 FROM #Tasa)
        UPDATE v SET Propina = ISNULL(p.Propina, 0)
          FROM #T v
          OUTER APPLY (
                SELECT ROUND(ABS(SUM(g.Tax * ISNULL(t.Propina / NULLIF(t.Itbis + t.Propina, 0), 0))), 2) AS Propina
                  FROM dbo.Invoice i
                 CROSS APPLY (VALUES (i.Tax1Rate, i.Tax1Tax), (i.Tax2Rate, i.Tax2Tax), (i.Tax3Rate, i.Tax3Tax), (i.Tax4Rate, i.Tax4Tax),
                                     (i.Tax5Rate, i.Tax5Tax), (i.Tax6Rate, i.Tax6Tax), (i.Tax7Rate, i.Tax7Tax), (i.Tax8Rate, i.Tax8Tax),
                                     (i.Tax9Rate, i.Tax9Tax), (i.Tax10Rate, i.Tax10Tax)) g (Tasa, Tax)
                  LEFT JOIN #Tasa t ON t.Tasa = g.Tasa
                 WHERE i.Id = v.IdInvoice AND g.Tax <> 0) p;
    ELSE
        UPDATE v SET Propina = ISNULL((SELECT TOP (1) ABS(f.Propina) FROM dbo.Factura f WHERE f.IdInvoice = v.IdInvoice ORDER BY f.Id), 0) FROM #T v;
    UPDATE #T SET Itbis = Total - Base - Propina;
    UPDATE #T SET Base = Base * Signo, Total = Total * Signo, Propina = Propina * Signo, Itbis = Itbis * Signo;

    /* ---- Formas de pago de cada transaccion (neto del cambio) ---- */
    CREATE TABLE #Pg (IdInvoice INT, Forma NVARCHAR(100) COLLATE DATABASE_DEFAULT, Monto DECIMAL(18,2), Orden INT,
                      Base DECIMAL(18,2), Itbis DECIMAL(18,2), Propina DECIMAL(18,2));
    INSERT INTO #Pg (IdInvoice, Forma, Monto, Orden)
    SELECT t.IdInvoice, ISNULL(m.Name, N'(sin nombre)'), SUM(ABS(ISNULL(dp.PaidAmount, 0) - ISNULL(dp.ChangeAmount, 0))) * t.Signo, 0
      FROM #T t
      JOIN dbo.DocumentPayment dp ON dp.InvoiceId = t.IdInvoice
      LEFT JOIN dbo.PaymentMethod m ON m.Id = dp.MethodId
     GROUP BY t.IdInvoice, t.Signo, ISNULL(m.Name, N'(sin nombre)');
    INSERT INTO #Pg (IdInvoice, Forma, Monto, Orden)
    SELECT t.IdInvoice, N'SIN PAGO REGISTRADO', t.Total, 0 FROM #T t WHERE NOT EXISTS (SELECT 1 FROM #Pg p WHERE p.IdInvoice = t.IdInvoice);

    -- reparto proporcional de base, ITBIS y propina; el redondeo sobrante va a la forma de pago mayor de cada transaccion
    UPDATE p SET Orden = x.Orden
      FROM #Pg p JOIN (SELECT IdInvoice, Forma, ROW_NUMBER() OVER (PARTITION BY IdInvoice ORDER BY ABS(Monto) DESC, Forma) AS Orden FROM #Pg) x
        ON x.IdInvoice = p.IdInvoice AND x.Forma = p.Forma;
    UPDATE p SET Base    = ROUND(t.Base    * CASE WHEN s.Suma = 0 THEN 1.0 / s.Cuantas ELSE p.Monto / s.Suma END, 2),
                 Itbis   = ROUND(t.Itbis   * CASE WHEN s.Suma = 0 THEN 1.0 / s.Cuantas ELSE p.Monto / s.Suma END, 2),
                 Propina = ROUND(t.Propina * CASE WHEN s.Suma = 0 THEN 1.0 / s.Cuantas ELSE p.Monto / s.Suma END, 2)
      FROM #Pg p JOIN #T t ON t.IdInvoice = p.IdInvoice
      JOIN (SELECT IdInvoice, SUM(Monto) AS Suma, COUNT(*) AS Cuantas FROM #Pg GROUP BY IdInvoice) s ON s.IdInvoice = p.IdInvoice;
    UPDATE p SET Base = p.Base + (t.Base - s.B), Itbis = p.Itbis + (t.Itbis - s.I), Propina = p.Propina + (t.Propina - s.P)
      FROM #Pg p JOIN #T t ON t.IdInvoice = p.IdInvoice
      JOIN (SELECT IdInvoice, SUM(Base) AS B, SUM(Itbis) AS I, SUM(Propina) AS P FROM #Pg GROUP BY IdInvoice) s ON s.IdInvoice = p.IdInvoice
     WHERE p.Orden = 1;

    /* ---- Datos del fiscalizador por transaccion (solo lo que de verdad se subio) ---- */
    CREATE TABLE #F (IdInvoice INT PRIMARY KEY, Subido BIT, Encf VARCHAR(20), FechaFiscal DATETIME, EstadoDgii VARCHAR(30), Enlace NVARCHAR(MAX), Observacion NVARCHAR(200) COLLATE DATABASE_DEFAULT);
    INSERT INTO #F (IdInvoice, Subido, Encf, FechaFiscal, EstadoDgii, Enlace, Observacion)
    SELECT t.IdInvoice,
           CASE WHEN c.Id IS NOT NULL AND c.Encf IS NOT NULL AND c.Estado NOT IN ('DIFERIDO', 'DESCARTADO') THEN 1 ELSE 0 END,
           c.Encf, c.FechaFirma, ISNULL(c.EstadoDgii, c.Estado), c.QrData,
           CASE WHEN c.Id IS NOT NULL AND c.Encf IS NOT NULL AND c.Estado NOT IN ('DIFERIDO', 'DESCARTADO') THEN N''
                WHEN o.Id IS NOT NULL THEN N'Operacion interna ' + o.Referencia + N': no se subio al fiscalizador'
                WHEN c.Id IS NULL THEN N'Sin comprobante electronico: no se subio al fiscalizador'
                WHEN c.Estado = 'DESCARTADO' THEN N'Comprobante descartado: no se subio al fiscalizador'
                ELSE N'Todavia sin e-NCF (' + c.Estado + N'): no se subio al fiscalizador' END
      FROM #T t
      LEFT JOIN dbo.LetFE_Cola c ON c.Serie = t.Serie AND c.Numero = t.Numero
      LEFT JOIN dbo.LetOperacionInterna o ON o.Serie = t.Serie AND o.Numero = t.Numero;
    UPDATE #F SET Encf = NULL, FechaFiscal = NULL, EstadoDgii = NULL, Enlace = NULL WHERE Subido = 0;
    UPDATE #F SET Enlace = NULL WHERE Enlace IS NOT NULL AND Enlace NOT LIKE 'http%';

    /* ---- 1) Resumen de la jornada ---- */
    SELECT @Jornada AS Jornada, @JId AS JornadaId,
           ISNULL(@Apertura, (SELECT MIN(AperturaCuenta) FROM #T)) AS Apertura, @CierreJ AS CierreJornada,
           CAST(CASE WHEN @JId IS NOT NULL AND @CierreJ IS NULL THEN 1 ELSE 0 END AS BIT) AS Abierta,
           (SELECT MIN(Cierre) FROM #T) AS PrimeraCuentaCerrada, (SELECT MAX(Cierre) FROM #T) AS UltimaCuentaCerrada,
           COUNT(*) AS Transacciones, SUM(CASE WHEN Signo = 1 THEN 1 ELSE 0 END) AS Ventas, SUM(CASE WHEN Signo = -1 THEN 1 ELSE 0 END) AS Notas,
           ISNULL(SUM(Base), 0) AS Base, ISNULL(SUM(Itbis), 0) AS Itbis, ISNULL(SUM(Propina), 0) AS Propina, ISNULL(SUM(Total), 0) AS Total,
           ISNULL(SUM(CASE WHEN f.Subido = 1 THEN 1 ELSE 0 END), 0) AS EnFiscalizador, ISNULL(SUM(CASE WHEN f.Subido = 1 THEN 0 ELSE 1 END), 0) AS SinFiscalizador,
           ISNULL(SUM(CASE WHEN f.Subido = 1 THEN Total ELSE 0 END), 0) AS TotalEnFiscalizador, ISNULL(SUM(CASE WHEN f.Subido = 1 THEN 0 ELSE Total END), 0) AS TotalSinFiscalizador
      FROM #T t LEFT JOIN #F f ON f.IdInvoice = t.IdInvoice;

    /* ---- 2) Por forma de pago ---- */
    SELECT p.Forma, COUNT(DISTINCT p.IdInvoice) AS Transacciones, SUM(p.Monto) AS Monto, SUM(p.Base) AS Base, SUM(p.Itbis) AS Itbis, SUM(p.Propina) AS Propina,
           SUM(CASE WHEN f.Subido = 1 THEN p.Monto ELSE 0 END) AS MontoEnFiscalizador, SUM(CASE WHEN f.Subido = 1 THEN 0 ELSE p.Monto END) AS MontoSinFiscalizador
      FROM #Pg p JOIN #F f ON f.IdInvoice = p.IdInvoice
     GROUP BY p.Forma ORDER BY SUM(p.Monto) DESC;

    /* ---- 3) Detalle: una fila por transaccion y forma de pago ---- */
    SELECT @Jornada AS Jornada, t.Serie, t.Numero, t.Serie + N'-' + CONVERT(NVARCHAR(12), t.Numero) AS Transaccion,
           CASE WHEN t.Signo = -1 THEN N'Nota de credito' ELSE N'Venta' END AS Tipo, ISNULL(cj.Name, CONVERT(NVARCHAR(12), t.PosId)) AS Caja,
           t.AbiertaPor, t.AperturaCuenta AS HoraApertura, t.CerradoPor AS CerradaPor, t.Cierre AS HoraCierre,
           p.Forma AS FormaPago, p.Monto AS MontoPagado, p.Base, p.Itbis, p.Propina, t.Total AS TotalTransaccion,
           f.Encf AS eNCF, f.FechaFiscal AS HoraFiscalizador, f.EstadoDgii, f.Enlace AS LinkValidez, f.Observacion
      FROM #T t
      JOIN #Pg p ON p.IdInvoice = t.IdInvoice
      JOIN #F f ON f.IdInvoice = t.IdInvoice
      LEFT JOIN dbo.Pos cj ON cj.Id = t.PosId
     ORDER BY t.Cierre, t.Serie, t.Numero, p.Orden;

    /* ---- 4) Corte del fiscalizador: como se reparte lo de esta jornada segun el DIA de la hora de firma del e-CF ---- */
    SELECT CAST(f.FechaFiscal AS DATE) AS DiaFiscalizador, COUNT(*) AS Documentos, SUM(t.Total) AS Total,
           MIN(f.FechaFiscal) AS Primera, MAX(f.FechaFiscal) AS Ultima
      FROM #T t JOIN #F f ON f.IdInvoice = t.IdInvoice
     WHERE f.Subido = 1
     GROUP BY CAST(f.FechaFiscal AS DATE) ORDER BY CAST(f.FechaFiscal AS DATE);
END
GO
