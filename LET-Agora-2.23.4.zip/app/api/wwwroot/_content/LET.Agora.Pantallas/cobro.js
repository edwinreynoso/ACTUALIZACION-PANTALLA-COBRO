// Pantalla de cobro: lo minimo que tiene que pasar en el navegador.
// - El teclado numerico escribe sin ir al servidor.
// - Cada accion (forma de pago, quitar pago, comprobante) envia el formulario y el servidor
//   devuelve el panel ya dibujado; el calculo del cobro vive en C# (CalculoCobro).
// - Al cobrar: imprime en el servicio de impresion del equipo (si aplica) y le pide a Agora cerrar la ventana.
(() => {
    'use strict';

    const $ = id => document.getElementById(id);
    const ESPERA_IMPRESION = 20000;

    // ------------------------------------------------------------------ dialogos

    function abrir(dlg) {
        dlg.returnValue = '';
        if (!dlg.open) dlg.showModal();
    }

    document.addEventListener('click', e => {
        const boton = e.target.closest('[data-cerrar]');
        if (boton) boton.closest('dialog').close('');
    });

    function aviso(texto) {
        return new Promise(resolver => {
            const dlg = $('dlg-aviso');
            $('dlg-aviso-texto').textContent = texto;
            dlg.addEventListener('close', () => resolver(), { once: true });
            abrir(dlg);
            dlg.querySelector('[data-cerrar]').focus();
        });
    }

    // ------------------------------------------------------------------ teclados numericos

    // Solo digitos y un punto, con dos decimales como maximo (igual que CalculoCobro.LimpiarMonto).
    function limpiarMonto(texto) {
        let limpio = (texto || '').replace(/[^0-9.]/g, '');
        const punto = limpio.indexOf('.');
        if (punto >= 0) {
            limpio = limpio.slice(0, punto + 1) + limpio.slice(punto + 1).replace(/\./g, '').slice(0, 2);
        }
        return limpio.slice(0, 12);
    }

    const esCampoMonto = campo => campo.id === 'entrada' || campo.id === 'dlg-monto-valor';

    document.addEventListener('click', e => {
        const tecla = e.target.closest('[data-tecla]');
        if (!tecla || tecla.disabled) return;
        const campo = $(tecla.closest('[data-teclado-para]').dataset.tecladoPara);
        if (!campo || campo.disabled) return;

        const valor = tecla.dataset.tecla;
        let texto = valor === 'B' ? campo.value.slice(0, -1)
            : valor === 'C' ? ''
            : campo.value + valor;
        if (esCampoMonto(campo)) texto = limpiarMonto(texto);
        campo.value = texto.slice(0, campo.maxLength > 0 ? campo.maxLength : 60);
        if (campo.id === 'dlg-monto-valor') campo.dispatchEvent(new Event('input', { bubbles: true }));
        campo.focus();
    });

    document.addEventListener('input', e => {
        if (esCampoMonto(e.target)) {
            const limpio = limpiarMonto(e.target.value);
            if (limpio !== e.target.value) e.target.value = limpio;
        }
    });

    // ------------------------------------------------------------------ cerrar la ventana de Agora (precuenta)

    // Agora abre la pantalla en su visor: se le pide que la cierre y vuelva al ticket. Abierta fuera de Agora
    // (pruebas) no hay a quien pedirselo y la pagina se queda.
    const cerrarEnAgora = () => window.parent.postMessage({ type: 'agora:pos:close-window', applyFlow: 'none' }, '*');
    document.addEventListener('click', e => {
        if (e.target.closest('[data-cerrar-agora]')) cerrarEnAgora();
    });
    const cierreAutomatico = document.querySelector('[data-cerrar-agora-en]');
    if (cierreAutomatico) setTimeout(cerrarEnAgora, Number(cierreAutomatico.dataset.cerrarAgoraEn) || 1500);
    // Un solo envio: el boton de imprimir se desactiva al tocarlo (doble toque = dos precuentas).
    document.addEventListener('submit', e => {
        const boton = e.target.querySelector('[data-una-vez]');
        if (!boton) return;
        if (boton.disabled) { e.preventDefault(); return; }
        setTimeout(() => { boton.disabled = true; }, 0);
    });

    // ------------------------------------------------------------------ cobro

    const cobro = $('cobro');
    if (!cobro) return;

    const url = cobro.dataset.url;
    const form = $('cobro-form');
    const panel = $('panel');
    let ocupado = false;

    function enfocar() {
        const entrada = $('entrada');
        if (entrada && !entrada.disabled && !document.querySelector('dialog[open]')) {
            entrada.focus();
            entrada.setSelectionRange(entrada.value.length, entrada.value.length);
        }
    }

    function ponerEstado(texto) {
        const estado = $('estado');
        if (!estado) return;
        estado.innerHTML = '<span class="girando"></span><span></span>';
        estado.lastChild.textContent = texto;
    }

    function ocupar(si) {
        ocupado = si;
        cobro.classList.toggle('ocupado', si);
    }

    // Envia el formulario a una accion de la pagina y pone el panel que devuelve el servidor.
    async function enviar(accion, extra) {
        if (ocupado) return null;
        ocupar(true);
        try {
            const datos = new FormData(form);
            for (const [clave, valor] of Object.entries(extra || {})) datos.set(clave, valor);
            const respuesta = await fetch(`${url}?handler=${accion}`, { method: 'POST', body: datos });
            if (!respuesta.ok) throw new Error(`HTTP ${respuesta.status}`);
            panel.innerHTML = await respuesta.text();
            return respuesta;
        } catch (ex) {
            await aviso(`NO SE PUDO CONECTAR CON EL SERVIDOR ${ex.message}`);
            return null;
        } finally {
            ocupar(false);
        }
    }

    // Una accion y lo que el servidor pida despues: un aviso, el monto en moneda extranjera o el RNC.
    async function accion(nombre, extra) {
        const respuesta = await enviar(nombre, extra);
        if (!respuesta) return;

        const textoAviso = respuesta.headers.get('X-Aviso');
        if (textoAviso) await aviso(decodeURIComponent(textoAviso));

        const pideMonto = respuesta.headers.get('X-Pide-Monto');
        if (pideMonto) {
            const h = nombre => decodeURIComponent(respuesta.headers.get(nombre) || '');
            const info = {
                pesos: h('X-Pide-Monto-Pesos'), pesosNum: parseFloat(h('X-Pide-Monto-PesosNum')), moneda: h('X-Pide-Monto-Moneda'),
                simbolo: h('X-Pide-Monto-Simbolo'), tasa: parseFloat(h('X-Pide-Monto-Tasa')), equivalente: h('X-Pide-Monto-Eq')
            };
            const monto = await pedirMonto(h('X-Pide-Monto-Titulo'), info);
            if (monto) await accion('Monto', { metodoId: pideMonto, monto });
        }

        const pideRnc = respuesta.headers.get('X-Pide-Rnc');
        if (pideRnc) {
            const cliente = await pedirRnc();
            if (cliente) {
                ponerCliente(cliente);
                await accion('Comprobante', { elegidoId: pideRnc });
            }
        }

        enfocar();
    }

    function ponerCliente(cliente) {
        form.elements['Rnc'].value = cliente.rnc;
        form.elements['RazonSocial'].value = cliente.razon;
    }

    panel.addEventListener('click', async e => {
        const boton = e.target.closest('[data-accion]');
        if (!boton || boton.disabled || ocupado) return;

        switch (boton.dataset.accion) {
            case 'metodo':
                return accion('Metodo', { metodoId: boton.dataset.id });
            case 'quitar':
                return accion('Quitar', { indice: boton.dataset.indice });
            case 'comprobante':
                return accion('Comprobante', { elegidoId: boton.dataset.id });
            case 'cliente': {
                const cliente = await pedirRnc();
                if (cliente) {
                    ponerCliente(cliente);
                    await accion('Refrescar');
                }
                return;
            }
            case 'pasajero':
                if (await pedirPasajero()) await accion('Refrescar');
                return;
            case 'dividir': {
                const total = parseFloat(panel.querySelector('.cobro-body')?.dataset.totalPagar || '0');
                const r = await pedirPartes(total);
                if (r) await accion('Dividir', { cuantas: r.cuantas, montos: r.montos });
                return;
            }
            case 'parte':
                return accion('Parte', { indice: boton.dataset.indice });
            case 'quitar-division':
                return accion('QuitarDivision');
            case 'cobrar':
                return cobrar();
            case 'volver':
                // Sin cobrar (el ticket sigue abierto en Agora). Si se abrio con el ticket en pantalla de Agora
                // se cierra la ventana y se vuelve a ese ticket; la lista trae tambien los tickets en espera.
                if (cobro.dataset.boton === '1' && window.parent !== window) {
                    window.parent.postMessage({ type: 'agora:pos:close-window', applyFlow: 'none' }, '*');
                } else {
                    location.href = urlLista();
                }
                return;
        }
    });

    panel.addEventListener('keydown', e => {
        if (e.target.id !== 'entrada') return;
        if (e.key === 'Enter' || e.key === 'NumpadEnter') {
            e.preventDefault();
            panel.querySelector('.tecla-ent')?.click();
        } else if (e.key === 'Escape') {
            e.target.value = '';
        }
    });

    // ------------------------------------------------------------------ cobrar, imprimir y cerrar

    // sinPasajero: el cajero ya vio el recordatorio de duty free y decidio facturar sin todos los datos.
    async function cobrar(sinPasajero) {
        if (ocupado) return;
        ocupar(true);
        ponerEstado('PROCESANDO EL COBRO...');

        let resultado;
        try {
            const datos = new FormData(form);
            if (sinPasajero) datos.set('SinPasajero', 'true');
            const respuesta = await fetch(`${url}?handler=Procesar`, { method: 'POST', body: datos });
            if (!respuesta.ok) throw new Error(`HTTP ${respuesta.status}`);
            resultado = await respuesta.json();
        } catch (ex) {
            resultado = { ok: false, mensaje: `NO SE PUDO CONECTAR CON EL SERVIDOR ${ex.message}` };
        }

        // Tienda duty free: faltan datos del pasajero. Nada se envio a Agora todavia.
        if (!resultado.ok && resultado.pidePasajero) {
            ocupar(false);
            const decision = await recordatorioPasajero(resultado.mensaje);
            if (decision === 'facturar') return cobrar(true);
            if (decision === 'completar' && await pedirPasajero()) {
                await accion('Refrescar');
                return cobrar();
            }
            await accion('Refrescar');
            return;
        }

        if (!resultado.ok) {
            ocupar(false);
            await aviso(resultado.mensaje);
            // Si Agora ya recibio pagos el panel queda bloqueado; Cobrar sigue desde donde quedo.
            await accion('Refrescar');
            return;
        }

        // Imprimir antes de cerrar: al cerrar la ventana Agora destruye el iframe.
        if (resultado.imprimir && resultado.factura) {
            ponerEstado('IMPRIMIENDO...');
            const impresion = await imprimir(resultado.factura);
            if (!impresion.ok) await aviso(`LA FACTURA SE REGISTRO PERO NO SE PUDO IMPRIMIR ${impresion.mensaje}`);
        }

        cerrar();
    }

    // Lista de tickets sin perder la caja que mando el boton de Agora.
    function urlLista() {
        const caja = form.elements['pos_id']?.value;
        return '/cobro?lista=1' + (caja ? '&pos_id=' + encodeURIComponent(caja) : '');
    }

    function cerrar() {
        window.parent.postMessage({ type: 'agora:pos:close-window', applyFlow: 'afterClose' }, '*');
        // Abierta fuera de Agora (pruebas): si nadie cierra la ventana, vuelve a la lista.
        if (window.parent === window) {
            setTimeout(() => { location.href = urlLista(); }, 1500);
        }
    }

    // El servicio de impresion corre en el equipo del cajero; se conecta al abrir para ganar tiempo.
    const socketUrl = cobro.dataset.socket;
    let socket = null;

    function conectarImpresion() {
        return new Promise((resolver, rechazar) => {
            if (socket && socket.readyState === WebSocket.OPEN) return resolver(socket);
            try {
                socket = new WebSocket(`ws://${socketUrl}/servicioimpresion`);
            } catch (ex) {
                return rechazar(ex);
            }
            const espera = setTimeout(() => {
                rechazar(new Error('EL SERVICIO DE IMPRESION NO RESPONDIO A TIEMPO'));
                try { socket.close(); } catch { /* ya cerrado */ }
            }, ESPERA_IMPRESION);
            socket.onopen = () => { clearTimeout(espera); resolver(socket); };
            socket.onerror = () => { clearTimeout(espera); rechazar(new Error('EL SERVICIO DE IMPRESION NO ESTA DISPONIBLE')); };
        });
    }

    async function imprimir(factura) {
        try {
            const s = await conectarImpresion();
            const respuesta = await new Promise((resolver, rechazar) => {
                const espera = setTimeout(() => rechazar(new Error('EL SERVICIO DE IMPRESION NO RESPONDIO A TIEMPO')), ESPERA_IMPRESION);
                s.onmessage = e => {
                    clearTimeout(espera);
                    try { resolver(JSON.parse(e.data)); } catch (ex) { rechazar(ex); }
                };
                s.onclose = () => { clearTimeout(espera); rechazar(new Error('EL SERVICIO DE IMPRESION CERRO LA CONEXION')); };
                s.send(JSON.stringify(factura));
            });
            const exito = respuesta.Exito ?? respuesta.exito;
            return exito ? { ok: true } : { ok: false, mensaje: respuesta.Mensaje ?? respuesta.mensaje ?? '' };
        } catch (ex) {
            return { ok: false, mensaje: ex.message };
        }
    }

    if (socketUrl) conectarImpresion().catch(() => { /* se reintenta al imprimir */ });

    // ------------------------------------------------------------------ monto en moneda extranjera

    const dos = n => n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

    // Explica el cobro en moneda extranjera: el pendiente en pesos (resaltado) y dos formas de escribir lo que entrega el cliente:
    // en su moneda (USD, EUR...) o en pesos (se convierte a la moneda con la tasa). Debajo se describe en las dos monedas lo que se registra.
    let modoMonto = 'ext';

    function explicarMonto(info) {
        const pesos = $('dlg-monto-pesos'), pide = $('dlg-monto-pide'), conv = $('dlg-monto-conv'), modo = $('dlg-monto-modo');
        if (!info || !(info.tasa > 0)) { pesos.hidden = pide.hidden = conv.hidden = modo.hidden = true; modoMonto = 'ext'; return; }
        modoMonto = 'ext';
        $('dlg-monto-pesos-valor').textContent = 'RD$ ' + info.pesos + '  =  ' + info.simbolo + ' ' + info.equivalente;
        $('dlg-modo-ext').textContent = 'En ' + info.moneda;
        pesos.hidden = pide.hidden = conv.hidden = modo.hidden = false;
        const marcar = () => { $('dlg-modo-ext').classList.toggle('on', modoMonto === 'ext'); $('dlg-modo-pesos').classList.toggle('on', modoMonto === 'pesos'); };

        // La moneda extranjera que se registra segun lo escrito (si escribe pesos, se convierte con la tasa).
        const extranjera = () => {
            const escrito = parseFloat(($('dlg-monto-valor').value || '').replace(',', '.'));
            if (!(escrito > 0)) return 0;
            return modoMonto === 'pesos' ? Math.round(escrito / info.tasa * 100) / 100 : escrito;
        };
        const actualizar = () => {
            marcar();
            pide.textContent = modoMonto === 'pesos' ? 'Escriba cuántos pesos (RD$) entrega el cliente' : 'Escriba cuántos ' + info.moneda + ' entrega el cliente';
            $('dlg-monto-valor').placeholder = modoMonto === 'pesos' ? 'Monto en RD$' : 'Monto en ' + info.moneda;
            const ext = extranjera();
            if (!(ext > 0)) {
                conv.textContent = 'Pendiente de la cuenta: RD$ ' + info.pesos + '\nEn ' + info.moneda + ': ' + info.simbolo + ' ' + info.equivalente + '  (RD$ ' + info.pesos + ' ÷ tasa ' + info.tasa + ')';
                return;
            }
            const enPesos = Math.round(ext * info.tasa * 100) / 100;
            const resto = Math.round((info.pesosNum - enPesos) * 100) / 100;
            const lineas = [
                'Cliente entrega: ' + info.simbolo + ' ' + dos(ext),
                'Equivale a: RD$ ' + dos(enPesos) + '  (tasa ' + info.tasa + ')',
                resto > 0 ? 'Quedan RD$ ' + dos(resto) + ' pendientes por cobrar.' : resto < 0 ? 'Sobran RD$ ' + dos(-resto) + ': se devuelven como cambio.' : 'Cubre el pendiente exacto.'
            ];
            if (modoMonto === 'pesos') lineas.splice(1, 0, 'Se registra en ' + info.moneda + ' (RD$ ' + dos(parseFloat(($('dlg-monto-valor').value || '0').replace(',', '.'))) + ' ÷ tasa ' + info.tasa + ').');
            conv.textContent = lineas.join('\n');
        };
        $('dlg-monto-valor').oninput = actualizar;
        $('dlg-monto').actualizarConversion = actualizar;
        $('dlg-monto').valorParaEnviar = () => { const e = extranjera(); return e > 0 ? String(e) : ''; };
        $('dlg-modo-ext').onclick = () => { modoMonto = 'ext'; $('dlg-monto-valor').value = ''; actualizar(); $('dlg-monto-valor').focus(); };
        $('dlg-modo-pesos').onclick = () => { modoMonto = 'pesos'; $('dlg-monto-valor').value = ''; actualizar(); $('dlg-monto-valor').focus(); };
        $('dlg-monto-todo').onclick = () => { modoMonto = 'ext'; $('dlg-monto-valor').value = String(Math.ceil(info.pesosNum / info.tasa * 100 - 1e-9) / 100); actualizar(); };   // lo justo para cubrirlo (redondeado hacia arriba al centavo)
        actualizar();
    }

    function pedirMonto(titulo, info) {
        return new Promise(resolver => {
            const dlg = $('dlg-monto');
            const campo = $('dlg-monto-valor');
            $('dlg-monto-titulo').textContent = titulo;
            campo.value = '';
            dlg.valorParaEnviar = null;
            explicarMonto(info);
            dlg.addEventListener('close', () => resolver(dlg.returnValue === 'ok' ? (dlg.valorParaEnviar ? (dlg.valorParaEnviar() || campo.value) : campo.value) : null), { once: true });
            abrir(dlg);
            campo.focus();
        });
    }

    function aceptarMonto() {
        if ($('dlg-monto-valor').value) $('dlg-monto').close('ok');
    }

    $('dlg-monto-aceptar').addEventListener('click', aceptarMonto);
    $('dlg-monto-valor').addEventListener('keydown', e => {
        if (e.key === 'Enter' || e.key === 'NumpadEnter') { e.preventDefault(); aceptarMonto(); }
    });

    // ------------------------------------------------------------------ dividir la cuenta

    const MAX_PARTES = 20;

    // Las partes salen en centavos: lo que sobra de redondear se suma a la ultima (igual que CalculoCobro.Dividir).
    function vistaPartes(total, n) {
        if (!(n >= 2 && n <= MAX_PARTES) || !(total > 0)) return null;
        const cada = Math.floor(total / n * 100) / 100;
        if (cada < 0.01) return null;
        const ultima = Math.round((total - cada * (n - 1)) * 100) / 100;
        return { cada, ultima };
    }

    // Partes con montos distintos: los escritos quedan fijos y las que se dejan en blanco se reparten el resto (igual que CalculoCobro.DividirConMontos).
    function calcularPartes(total, valores) {
        const n = valores.length;
        if (n < 2 || n > MAX_PARTES) return { error: 'De 2 a ' + MAX_PARTES + ' personas' };
        const fijos = valores.map(v => { const x = parseFloat(v); return (v || '').trim() === '' || isNaN(x) ? null : Math.round(x * 100) / 100; });
        if (fijos.some(x => x !== null && x <= 0)) return { error: 'Cada monto debe ser mayor que cero' };
        const suma = Math.round(fijos.reduce((s, x) => s + (x || 0), 0) * 100) / 100;
        const blancos = fijos.filter(x => x === null).length;
        if (blancos === 0) return Math.abs(suma - total) <= 0.005 ? { partes: fijos } : { error: 'Los montos suman $' + dos(suma) + ' y la cuenta es $' + dos(total) };
        const resto = Math.round((total - suma) * 100) / 100;
        const cada = Math.floor(resto / blancos * 100) / 100;
        if (cada < 0.01) return { error: resto <= 0 ? 'Ya no queda nada para las demás personas' : 'No alcanza para las demás personas' };
        const ultima = Math.round((resto - cada * (blancos - 1)) * 100) / 100;
        let k = 0;
        return { partes: fijos.map(x => x !== null ? x : (++k === blancos ? ultima : cada)) };
    }

    // Devuelve { cuantas, montos } (montos vacio = partes iguales) o null si se cancela.
    function pedirPartes(total) {
        return new Promise(resolver => {
            const dlg = $('dlg-dividir'), campo = $('dlg-dividir-n'), vista = $('dlg-dividir-vista'), aceptar = $('dlg-dividir-aceptar');
            const filas = $('dv-filas'), vistaD = $('dv-vista');
            let modo = 'iguales', personas = 3, activa = 0;
            const valores = () => [...filas.querySelectorAll('.dv-monto')].map(i => i.value);

            const pintarFilas = () => {
                const previos = valores();
                filas.innerHTML = Array.from({ length: personas }, (_, i) =>
                    `<label class="dv-fila${i === activa ? ' activa' : ''}" data-i="${i}"><span>Persona ${i + 1}</span><input class="campo campo-monto dv-monto" data-i="${i}" readonly inputmode="none" placeholder="el resto" value="${previos[i] || ''}"></label>`).join('');
            };
            const actualizar = () => {
                $('dv-personas').textContent = personas;
                if (modo === 'iguales') {
                    const n = parseInt((campo.value || '').replace(/\D/g, ''), 10);
                    const v = vistaPartes(total, n);
                    aceptar.disabled = !v;
                    vista.textContent = v ? (v.ultima === v.cada ? n + ' partes de $' + dos(v.cada) : (n - 1) + ' partes de $' + dos(v.cada) + ' y la última de $' + dos(v.ultima)) : 'Escriba de 2 a ' + MAX_PARTES + ' partes';
                } else {
                    const r = calcularPartes(total, valores());
                    aceptar.disabled = !r.partes;
                    vistaD.classList.toggle('error', !r.partes);
                    vistaD.textContent = r.partes ? r.partes.map((p, i) => 'Persona ' + (i + 1) + ': $' + dos(p)).join(' · ') : r.error;
                }
            };
            const poner = m => {
                modo = m;
                dlg.querySelectorAll('[data-modo]').forEach(b => b.classList.toggle('on', b.dataset.modo === m));
                $('dv-iguales').hidden = m !== 'iguales'; $('dv-distintas').hidden = m !== 'distintas';
                if (m === 'distintas') pintarFilas();
                actualizar();
            };

            campo.value = '2';
            campo.oninput = actualizar;
            dlg.onclick = e => {
                const rapido = e.target.closest('[data-partes]');
                if (rapido) campo.value = rapido.dataset.partes;
                const modoBtn = e.target.closest('[data-modo]');
                if (modoBtn) poner(modoBtn.dataset.modo);
                const delta = e.target.closest('[data-personas]');
                if (delta) { personas = Math.min(MAX_PARTES, Math.max(2, personas + parseInt(delta.dataset.personas, 10))); if (activa >= personas) activa = personas - 1; pintarFilas(); }
                const fila = e.target.closest('.dv-fila');
                if (fila) { activa = parseInt(fila.dataset.i, 10); filas.querySelectorAll('.dv-fila').forEach(f => f.classList.toggle('activa', f === fila)); }
                const tecla = e.target.closest('[data-dv]');
                if (tecla) {
                    const input = filas.querySelectorAll('.dv-monto')[activa];
                    if (input) input.value = tecla.dataset.dv === 'C' ? '' : limpiarMonto(input.value + tecla.dataset.dv);
                }
                setTimeout(actualizar, 0);                      // el teclado de la pantalla cambia el valor sin avisar
            };
            aceptar.onclick = () => { if (!aceptar.disabled) dlg.close('ok'); };
            poner('iguales');
            dlg.addEventListener('close', () => {
                if (dlg.returnValue !== 'ok') return resolver(null);
                resolver(modo === 'iguales'
                    ? { cuantas: parseInt(campo.value.replace(/\D/g, ''), 10), montos: '' }
                    : { cuantas: personas, montos: valores().map(v => (v || '').trim()).join(';') });
            }, { once: true });
            $('dlg-dividir-total').textContent = '$' + dos(total);
            abrir(dlg);
            if (modo === 'iguales') campo.focus();
        });
    }

    // ------------------------------------------------------------------ pasajero (tienda duty free)

    const camposPasajero = [
        ['pasajero-nombre', 'PasajeroNombre'],
        ['pasajero-pasaporte', 'PasajeroPasaporte'],
        ['pasajero-nacionalidad', 'PasajeroNacionalidad'],
        ['pasajero-vuelo', 'PasajeroVuelo']
    ];

    // Abre el dialogo con lo que ya se escribio; al aceptar lo deja en el formulario. Devuelve si se acepto.
    function pedirPasajero() {
        return new Promise(resolver => {
            const dlg = $('dlg-pasajero');
            for (const [id, nombre] of camposPasajero) $(id).value = form.elements[nombre]?.value || '';
            dlg.addEventListener('close', () => {
                const ok = dlg.returnValue === 'ok';
                if (ok) {
                    for (const [id, nombre] of camposPasajero) {
                        if (form.elements[nombre]) form.elements[nombre].value = $(id).value.trim().toUpperCase();
                    }
                }
                resolver(ok);
            }, { once: true });
            abrir(dlg);
            // El primer campo vacio, para seguir donde se quedo.
            (camposPasajero.map(([id]) => $(id)).find(c => !c.value) || $('pasajero-nombre')).focus();
        });
    }

    $('pasajero-aceptar')?.addEventListener('click', () => $('dlg-pasajero').close('ok'));
    // Enter pasa al siguiente campo; en el ultimo acepta.
    $('dlg-pasajero')?.addEventListener('keydown', e => {
        if (e.key !== 'Enter' && e.key !== 'NumpadEnter') return;
        const indice = camposPasajero.findIndex(([id]) => id === e.target.id);
        if (indice < 0) return;
        e.preventDefault();
        if (indice < camposPasajero.length - 1) $(camposPasajero[indice + 1][0]).focus();
        else $('dlg-pasajero').close('ok');
    });

    // Recordatorio al cobrar sin todos los datos: 'completar', 'facturar' o '' (cerro el dialogo).
    function recordatorioPasajero(texto) {
        return new Promise(resolver => {
            const dlg = $('dlg-sin-pasajero');
            $('dlg-sin-pasajero-texto').textContent = texto;
            dlg.addEventListener('close', () => resolver(dlg.returnValue), { once: true });
            abrir(dlg);
            $('sin-pasajero-completar').focus();
        });
    }

    $('sin-pasajero-completar')?.addEventListener('click', () => $('dlg-sin-pasajero').close('completar'));
    $('sin-pasajero-facturar')?.addEventListener('click', () => $('dlg-sin-pasajero').close('facturar'));

    // ------------------------------------------------------------------ cliente del comprobante (RNC)

    const dlgRnc = $('dlg-rnc');
    const resultados = $('rnc-resultados');
    let rncSeleccion = null;
    let rncUltimaBusqueda = '';

    function pedirRnc() {
        return new Promise(resolver => {
            rncSeleccion = null;
            rncUltimaBusqueda = '';
            $('rnc-texto').value = '';
            resultados.innerHTML = '';
            $('rnc-seleccionar').disabled = true;
            $('rnc-buscar').hidden = false;
            $('rnc-nuevo').hidden = true;
            dlgRnc.addEventListener('close', () => resolver(dlgRnc.returnValue === 'ok' ? rncSeleccion : null), { once: true });
            abrir(dlgRnc);
            $('rnc-texto').focus();
        });
    }

    function aceptarRnc(cliente) {
        if (!cliente) return;
        rncSeleccion = cliente;
        dlgRnc.close('ok');
    }

    async function buscarRnc() {
        const texto = $('rnc-texto').value.trim();
        rncSeleccion = null;
        $('rnc-seleccionar').disabled = true;
        resultados.innerHTML = '<div class="cargando"><span class="girando"></span></div>';
        try {
            const respuesta = await fetch(`${url}?handler=Rnc&texto=${encodeURIComponent(texto)}`);
            if (!respuesta.ok) throw new Error(`HTTP ${respuesta.status}`);
            resultados.innerHTML = await respuesta.text();
        } catch (ex) {
            resultados.innerHTML = '<div class="alerta alerta-error"></div>';
            resultados.firstChild.textContent = `NO SE PUDO CONECTAR CON EL SERVIDOR ${ex.message}`;
        }
        rncUltimaBusqueda = texto;
        const encontrados = resultados.querySelectorAll('.resultado');
        // Un solo resultado: queda seleccionado para aceptar con Enter o "Seleccionar".
        if (encontrados.length === 1) marcarRnc(encontrados[0]);
    }

    function marcarRnc(elemento) {
        resultados.querySelectorAll('.resultado.seleccionado').forEach(r => r.classList.remove('seleccionado'));
        elemento.classList.add('seleccionado');
        rncSeleccion = { rnc: elemento.dataset.rnc, razon: elemento.dataset.razon };
        $('rnc-seleccionar').disabled = false;

        resultados.querySelector('.rnc-estado')?.remove();
        if (elemento.dataset.estado) {
            const alerta = document.createElement('div');
            alerta.className = 'alerta alerta-aviso rnc-estado';
            alerta.textContent = `Este RNC figura como ${elemento.dataset.estado} en la DGII.`;
            resultados.appendChild(alerta);
        }
    }

    $('rnc-boton-buscar').addEventListener('click', buscarRnc);
    $('rnc-seleccionar').addEventListener('click', () => aceptarRnc(rncSeleccion));
    $('rnc-texto').addEventListener('keydown', e => {
        if (e.key !== 'Enter' && e.key !== 'NumpadEnter') return;
        e.preventDefault();
        // Enter con un resultado ya seleccionado lo confirma; si no, busca.
        if (rncSeleccion && $('rnc-texto').value.trim() === rncUltimaBusqueda) aceptarRnc(rncSeleccion);
        else buscarRnc();
    });
    resultados.addEventListener('click', e => {
        const elemento = e.target.closest('.resultado');
        if (elemento) marcarRnc(elemento);
    });
    resultados.addEventListener('dblclick', e => {
        const elemento = e.target.closest('.resultado');
        if (elemento) { marcarRnc(elemento); aceptarRnc(rncSeleccion); }
    });

    $('rnc-abrir-nuevo').addEventListener('click', () => {
        // Se aprovecha lo que el usuario ya escribio en la busqueda.
        const texto = $('rnc-texto').value.trim();
        const esNumero = /^\d+$/.test(texto);
        $('nuevo-rnc').value = esNumero ? texto : '';
        $('nuevo-razon').value = esNumero ? '' : texto.toUpperCase();
        $('nuevo-nombre').value = $('nuevo-direccion').value = $('nuevo-telefono').value = '';
        $('nuevo-mensaje').hidden = true;
        $('rnc-buscar').hidden = true;
        $('rnc-nuevo').hidden = false;
        (esNumero ? $('nuevo-razon') : $('nuevo-rnc')).focus();
    });

    $('rnc-volver').addEventListener('click', () => {
        $('rnc-nuevo').hidden = true;
        $('rnc-buscar').hidden = false;
        $('rnc-texto').focus();
    });

    $('rnc-guardar').addEventListener('click', async () => {
        const boton = $('rnc-guardar');
        const mensaje = $('nuevo-mensaje');
        boton.disabled = true;
        mensaje.hidden = true;
        try {
            const datos = new FormData();
            datos.set('nuevoRnc', $('nuevo-rnc').value);
            datos.set('nuevaRazon', $('nuevo-razon').value);
            datos.set('nuevoNombre', $('nuevo-nombre').value);
            datos.set('nuevaDireccion', $('nuevo-direccion').value);
            datos.set('nuevoTelefono', $('nuevo-telefono').value);
            const respuesta = await fetch(`${url}?handler=RegistrarRnc`, { method: 'POST', body: datos });
            if (!respuesta.ok) throw new Error(`HTTP ${respuesta.status}`);
            const r = await respuesta.json();
            if (r.ok) {
                aceptarRnc({ rnc: r.rnc, razon: r.razon });
                return;
            }
            mensaje.textContent = r.mensaje;
        } catch (ex) {
            mensaje.textContent = `NO SE PUDO CONECTAR CON EL SERVIDOR ${ex.message}`;
        } finally {
            boton.disabled = false;
        }
        mensaje.hidden = false;
    });

    // ------------------------------------------------------------------ al abrir

    (async () => {
        const avisos = JSON.parse(cobro.dataset.avisos || '[]');
        for (const texto of avisos) await aviso(texto);
        enfocar();
    })();
})();
