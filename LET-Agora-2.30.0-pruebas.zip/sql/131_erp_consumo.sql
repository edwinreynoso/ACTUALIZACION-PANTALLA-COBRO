﻿-- 131_erp_consumo.sql
-- Consumo del turno para el ERP (ADR-0019, fase 3): lo vendido por articulo en un turno, tomado de los movimientos de existencia de Agora (Movement tipo 1: SourceLineId = TicketLine, cantidad negativa
-- = salida; incluye lo cobrado con serie F y las cortesias). El turno de un movimiento sale de la factura (Invoice) de su ticket: caja y fecha. `explode` = el ERP descompone el plato con su receta
-- (Product.AdjustIngredientsOnSale apagado); si Agora ya descuenta los ingredientes, no. Redefine LetERPEncolar (125): agrega el control de documentos sin comprobante y el evento consumo.turno.
-- Sin variables del instalador. Idempotente.

IF OBJECT_ID(N'[dbo].[LetERPConsumoJson]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetERPConsumoJson] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetERPConsumoJson] (@PosId INT, @Apertura DATETIME, @Cierre DATETIME, @Rnc VARCHAR(20), @Offset VARCHAR(6), @Dia DATE, @Sucursal VARCHAR(20), @Json NVARCHAR(MAX) OUTPUT)
AS
BEGIN
    SET NOCOUNT ON;
    SET @Json = NULL;
    -- Tickets del turno: los que tienen una factura de esa caja entre la apertura y el cierre (si hay varias, la fiscal tipo 0 primero).
    DECLARE @C TABLE (ProductId INT, Nombre NVARCHAR(300), Cant DECIMAL(18,4), Explotar BIT);
    INSERT @C (ProductId, Nombre, Cant, Explotar)
    SELECT m.ProductId, MAX(LEFT(ISNULL(NULLIF(LTRIM(RTRIM(m.ProductName)), N''), N'Articulo'), 300)),
           CAST(-SUM(m.QuantityInSaleUnit) AS DECIMAL(18,4)),
           CASE WHEN MAX(CAST(ISNULL(p.AdjustIngredientsOnSale, 0) AS INT)) = 0 THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT) END
      FROM dbo.Movement m
      JOIN dbo.TicketLine l ON l.Id = m.SourceLineId
      LEFT JOIN dbo.Product p ON p.Id = m.ProductId
     WHERE m.Type = 1
       AND EXISTS (SELECT 1 FROM dbo.InvoiceItem ii JOIN dbo.Invoice i ON i.Id = ii.InvoiceId
                    WHERE ii.TicketId = l.TicketId AND i.Type IN (0, 1) AND i.PosId = @PosId AND i.CreationDate >= @Apertura AND i.CreationDate <= @Cierre)
     GROUP BY m.ProductId
    HAVING -SUM(m.QuantityInSaleUnit) > 0;
    IF NOT EXISTS (SELECT 1 FROM @C) RETURN;
    SET @Json = (
        SELECT 1 AS schema_version, @Sucursal AS branch_code, @Rnc AS issuer_rnc, @PosId AS pos_id, CONVERT(VARCHAR(10), @Dia, 23) AS business_day, CONVERT(VARCHAR(19), @Apertura, 126) + @Offset AS shift_opened_at,
               JSON_QUERY((SELECT c.ProductId AS product_id, c.Nombre AS name, CONVERT(VARCHAR(30), c.Cant) AS qty, c.Explotar AS explode FROM @C c ORDER BY c.ProductId FOR JSON PATH)) AS lines
        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
END
GO

-- Recorre los turnos CERRADOS desde @Desde y encola los eventos de los que estan completos y cuadran. Devuelve el resumen de lo que hizo.
IF OBJECT_ID(N'[dbo].[LetERPEncolar]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetERPEncolar] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetERPEncolar] (@Rnc VARCHAR(20), @Offset VARCHAR(6) = '-04:00', @Desde DATE = NULL, @MaxTurnos INT = 20, @Sucursal VARCHAR(20) = 'PRINCIPAL')
AS
BEGIN
    SET NOCOUNT ON;
    EXEC dbo.LetERPFormasSembrar;
    DECLARE @Encolados INT = 0, @Esperando INT = 0, @Revisar INT = 0;
    DECLARE @T TABLE (PosId INT, Apertura DATETIME, Cierre DATETIME, Dia DATE, CajaInicial DECIMAL(14,2), CajaEsperada DECIMAL(14,2));
    INSERT @T
    SELECT TOP (@MaxTurnos) p.PosId, p.OpenDate, p.CloseDate, CAST(p.BusinessDay AS DATE), p.CashInitialAmount, p.CashExpectedEndAmount
      FROM dbo.PosCloseOut p
     WHERE p.CloseDate IS NOT NULL AND p.OpenDate IS NOT NULL AND (@Desde IS NULL OR CAST(p.BusinessDay AS DATE) >= @Desde)
       AND NOT EXISTS (SELECT 1 FROM dbo.LetERP_Turno t WHERE t.PosId = p.PosId AND t.Turno = p.OpenDate AND t.Estado IN ('ENCOLADO', 'SIN_VENTAS'))
     ORDER BY p.CloseDate;

    DECLARE @PosId INT, @Apertura DATETIME, @Cierre DATETIME, @Dia DATE, @CajaIni DECIMAL(14,2), @CajaEsp DECIMAL(14,2);
    DECLARE tc CURSOR LOCAL FAST_FORWARD FOR SELECT PosId, Apertura, Cierre, Dia, CajaInicial, CajaEsperada FROM @T ORDER BY Cierre;
    OPEN tc;
    FETCH NEXT FROM tc INTO @PosId, @Apertura, @Cierre, @Dia, @CajaIni, @CajaEsp;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        DECLARE @Docs TABLE (Serie NVARCHAR(10), Numero INT, Documento CHAR(1), Estado VARCHAR(20));
        DELETE @Docs;
        -- Documentos del turno: las facturas de esa caja entre la apertura y el cierre (varias filas con el mismo numero cuentan una vez).
        INSERT @Docs (Serie, Numero, Documento, Estado)
        SELECT f.Serie, f.Numero, MAX(c.Documento), MAX(c.Estado)
          FROM dbo.Factura f LEFT JOIN dbo.LetFE_Cola c ON c.Serie = f.Serie AND c.Numero = f.Numero
         WHERE f.PosId = @PosId AND f.Fecha >= @Apertura AND f.Fecha <= @Cierre
         GROUP BY f.Serie, f.Numero;

        DECLARE @Estado VARCHAR(12) = NULL, @Motivo NVARCHAR(500) = NULL, @N INT = (SELECT COUNT(*) FROM @Docs);
        IF @N = 0
        BEGIN
            MERGE dbo.LetERP_Turno AS t USING (SELECT @PosId AS PosId, @Apertura AS Turno) s ON t.PosId = s.PosId AND t.Turno = s.Turno
            WHEN MATCHED THEN UPDATE SET Estado = 'SIN_VENTAS', Motivo = NULL, Documentos = 0, Actualizado = GETDATE()
            WHEN NOT MATCHED THEN INSERT (PosId, Turno, Estado, Motivo, Documentos) VALUES (s.PosId, s.Turno, 'SIN_VENTAS', NULL, 0);
        END
        ELSE
        BEGIN
            DECLARE @SinFiscal INT = (SELECT COUNT(*) FROM dbo.Invoice i
                 WHERE i.PosId = @PosId AND i.Type IN (0, 1) AND i.CreationDate >= @Apertura AND i.CreationDate <= @Cierre
                   AND NOT EXISTS (SELECT 1 FROM dbo.Factura f WHERE f.IdInvoice = i.Id)
                   AND EXISTS (SELECT 1 FROM dbo.DocumentPayment p WHERE p.InvoiceId = i.Id AND NOT EXISTS (SELECT 1 FROM dbo.LetERP_FormaPago m WHERE m.IdFormaPago = p.MethodId AND m.Metodo = 'COMPLIMENTARY')));
            IF @SinFiscal > 0
            BEGIN SET @Estado = 'REVISAR'; SET @Motivo = CAST(@SinFiscal AS NVARCHAR(10)) + N' documento(s) cobrado(s) del turno (serie F u otra) no pasaron por e-Fiscal y no tienen comprobante electronico: no se pueden registrar en el ERP; decida como se fiscalizan'; END
            ELSE IF EXISTS (SELECT 1 FROM @Docs WHERE Documento IS NULL)
            BEGIN SET @Estado = 'REVISAR'; SET @Motivo = CAST((SELECT COUNT(*) FROM @Docs WHERE Documento IS NULL) AS NVARCHAR(10)) + N' venta(s) del turno no pasaron por e-Fiscal (no estan en la cola); revise antes de enviar al ERP'; END
            ELSE IF EXISTS (SELECT 1 FROM @Docs WHERE Estado = 'DESCARTADO')
            BEGIN SET @Estado = 'REVISAR'; SET @Motivo = CAST((SELECT COUNT(*) FROM @Docs WHERE Estado = 'DESCARTADO') AS NVARCHAR(10)) + N' documento(s) descartado(s): decida con el contador como se registran antes de enviar el turno'; END
            ELSE IF EXISTS (SELECT 1 FROM @Docs WHERE Estado NOT IN ('ACEPTADO', 'ACEPTADO_COND', 'REGULARIZADO'))
            BEGIN SET @Estado = 'ESPERANDO'; SET @Motivo = CAST((SELECT COUNT(*) FROM @Docs WHERE Estado NOT IN ('ACEPTADO', 'ACEPTADO_COND', 'REGULARIZADO')) AS NVARCHAR(10)) + N' documento(s) sin aceptar por la DGII todavia'; END

            DECLARE @Ev TABLE (Orden INT IDENTITY(1,1), EventId NVARCHAR(120), Tipo VARCHAR(30), Payload NVARCHAR(MAX));
            DELETE @Ev;
            DECLARE @VentasTot DECIMAL(14,2) = 0, @NotasTot DECIMAL(14,2) = 0;
            IF @Estado IS NULL
            BEGIN
                DECLARE @Serie NVARCHAR(10), @Num INT, @Docu CHAR(1), @Json NVARCHAR(MAX), @Prob NVARCHAR(500), @Tot DECIMAL(14,2);
                DECLARE dc CURSOR LOCAL FAST_FORWARD FOR SELECT Serie, Numero, Documento FROM @Docs ORDER BY Serie, Numero;
                OPEN dc;
                FETCH NEXT FROM dc INTO @Serie, @Num, @Docu;
                WHILE @@FETCH_STATUS = 0
                BEGIN
                    EXEC dbo.LetERPDocumento @Serie, @Num, @Rnc, @Offset, @Dia, @Apertura, @Sucursal, @Json OUTPUT, @Prob OUTPUT;
                    IF @Json IS NULL
                    BEGIN SET @Estado = 'REVISAR'; SET @Motivo = LEFT(@Serie + N'-' + CAST(@Num AS NVARCHAR(10)) + N': ' + ISNULL(@Prob, N'no se pudo armar el documento'), 500); BREAK; END
                    SET @Tot = CAST(JSON_VALUE(@Json, '$.totals.total') AS DECIMAL(14,2));
                    IF @Docu = 'N' SET @NotasTot += @Tot ELSE SET @VentasTot += @Tot;
                    INSERT @Ev (EventId, Tipo, Payload)
                    VALUES (CASE WHEN @Docu = 'N' THEN N'nota:' ELSE N'venta:' END + @Sucursal + N':' + CAST(@PosId AS NVARCHAR(10)) + N':' + @Serie + N':' + CAST(@Num AS NVARCHAR(10)),
                            CASE WHEN @Docu = 'N' THEN 'nota.fiscalizada' ELSE 'venta.fiscalizada' END, @Json);
                    FETCH NEXT FROM dc INTO @Serie, @Num, @Docu;
                END
                CLOSE dc; DEALLOCATE dc;
            END

            IF @Estado IS NOT NULL
            BEGIN
                MERGE dbo.LetERP_Turno AS t USING (SELECT @PosId AS PosId, @Apertura AS Turno) s ON t.PosId = s.PosId AND t.Turno = s.Turno
                WHEN MATCHED THEN UPDATE SET Estado = @Estado, Motivo = @Motivo, Documentos = @N, Actualizado = GETDATE()
                WHEN NOT MATCHED THEN INSERT (PosId, Turno, Estado, Motivo, Documentos) VALUES (s.PosId, s.Turno, @Estado, @Motivo, @N);
                IF @Estado = 'ESPERANDO' SET @Esperando += 1 ELSE SET @Revisar += 1;
            END
            ELSE
            BEGIN
                -- Cierre del turno al final: declara cuantos documentos y que totales trae, para que el ERP sepa cuando esta completo.
                DECLARE @Cierre1 NVARCHAR(MAX) = (
                    SELECT 1 AS schema_version, @Sucursal AS branch_code, @Rnc AS issuer_rnc, @PosId AS pos_id, CONVERT(VARCHAR(10), @Dia, 23) AS business_day,
                           CONVERT(VARCHAR(19), @Apertura, 126) + @Offset AS shift_opened_at, CONVERT(VARCHAR(19), @Cierre, 126) + @Offset AS shift_closed_at,
                           CONVERT(VARCHAR(20), CAST(ISNULL(@CajaIni, 0) AS DECIMAL(14,2))) AS cash_initial, CONVERT(VARCHAR(20), CAST(ISNULL(@CajaEsp, 0) AS DECIMAL(14,2))) AS cash_expected,
                           @N AS [documents.count], CONVERT(VARCHAR(20), @VentasTot) AS [documents.sales_total], CONVERT(VARCHAR(20), @NotasTot) AS [documents.credit_notes_total]
                    FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
                INSERT @Ev (EventId, Tipo, Payload) VALUES (N'turno:' + @Sucursal + N':' + CAST(@PosId AS NVARCHAR(10)) + N':' + CONVERT(NVARCHAR(19), @Apertura, 126), 'turno.cerrado', @Cierre1);
                DECLARE @Consumo NVARCHAR(MAX);
                EXEC dbo.LetERPConsumoJson @PosId, @Apertura, @Cierre, @Rnc, @Offset, @Dia, @Sucursal, @Consumo OUTPUT;
                IF @Consumo IS NOT NULL INSERT @Ev (EventId, Tipo, Payload) VALUES (N'consumo:' + @Sucursal + N':' + CAST(@PosId AS NVARCHAR(10)) + N':' + CONVERT(NVARCHAR(19), @Apertura, 126), 'consumo.turno', @Consumo);
                BEGIN TRAN;
                    INSERT dbo.LetERP_Cola (EventId, Tipo, PosId, Turno, Payload)
                    SELECT e.EventId, e.Tipo, @PosId, @Apertura, e.Payload FROM @Ev e
                     WHERE NOT EXISTS (SELECT 1 FROM dbo.LetERP_Cola q WHERE q.EventId = e.EventId) ORDER BY e.Orden;
                    MERGE dbo.LetERP_Turno AS t USING (SELECT @PosId AS PosId, @Apertura AS Turno) s ON t.PosId = s.PosId AND t.Turno = s.Turno
                    WHEN MATCHED THEN UPDATE SET Estado = 'ENCOLADO', Motivo = NULL, Documentos = @N, Actualizado = GETDATE()
                    WHEN NOT MATCHED THEN INSERT (PosId, Turno, Estado, Motivo, Documentos) VALUES (s.PosId, s.Turno, 'ENCOLADO', NULL, @N);
                COMMIT;
                SET @Encolados += 1;
            END
        END
        FETCH NEXT FROM tc INTO @PosId, @Apertura, @Cierre, @Dia, @CajaIni, @CajaEsp;
    END
    CLOSE tc; DEALLOCATE tc;
    SELECT @Encolados AS Encolados, @Esperando AS Esperando, @Revisar AS Revisar;
END
GO

