-- Copias del ticket por tipo de comprobante. Por defecto cada tipo imprime solo el original (Copias = 0). Si en el portal (Copias por tipo de comprobante)
-- se marca un tipo y se pone la cantidad, la venta de ese tipo imprime el ORIGINAL y esa cantidad de COPIAS. Las reimpresiones siempre salen una sola vez.
-- Tipo 0 = ventas sin comprobante fiscal. Idempotente.
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID(N'dbo.LetCopiaComprobante', N'U') IS NULL
CREATE TABLE dbo.LetCopiaComprobante (
    TipoNcf     INT           NOT NULL CONSTRAINT PK_LetCopiaComprobante PRIMARY KEY,   -- NCFSecuencia.TipoNCFID (0 = sin comprobante)
    Copias      INT           NOT NULL CONSTRAINT DF_LetCopiaComprobante_Copias DEFAULT (0) CONSTRAINT CK_LetCopiaComprobante_Copias CHECK (Copias BETWEEN 0 AND 5),
    Usuario     NVARCHAR(100) NULL,
    Actualizado DATETIME      NOT NULL CONSTRAINT DF_LetCopiaComprobante_Act DEFAULT (GETDATE())
)
GO

------------------------------------------------------------ [dbo].[LetCopiasComprobanteListar]
IF OBJECT_ID(N'[dbo].[LetCopiasComprobanteListar]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetCopiasComprobanteListar] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetCopiasComprobanteListar]
AS
BEGIN
    SET NOCOUNT ON;
    SELECT t.Tipo, t.Descripcion, ISNULL(c.Copias, 0) AS Copias
      FROM (SELECT 0 AS Tipo, N'Ventas sin comprobante fiscal' AS Descripcion
            UNION ALL
            SELECT s.TipoNCFID, MIN(s.TipoNCFDescripcion) FROM dbo.NCFSecuencia s WHERE s.TipoNCFID > 0 GROUP BY s.TipoNCFID) t
      LEFT JOIN dbo.LetCopiaComprobante c ON c.TipoNcf = t.Tipo
     ORDER BY t.Tipo;
END
GO

------------------------------------------------------------ [dbo].[LetCopiasComprobanteGuardar]
IF OBJECT_ID(N'[dbo].[LetCopiasComprobanteGuardar]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetCopiasComprobanteGuardar] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetCopiasComprobanteGuardar] (@Tipo INT, @Copias INT, @Usuario NVARCHAR(100) = NULL)
AS
BEGIN
    SET NOCOUNT ON;
    IF @Tipo < 0 OR @Copias < 0 OR @Copias > 5
    BEGIN SELECT CAST(0 AS BIT) AS Ok, N'Las copias van de 0 a 5 (0 = solo el original)' AS Mensaje; RETURN; END
    IF EXISTS (SELECT 1 FROM dbo.LetCopiaComprobante WHERE TipoNcf = @Tipo)
        UPDATE dbo.LetCopiaComprobante SET Copias = @Copias, Usuario = @Usuario, Actualizado = GETDATE() WHERE TipoNcf = @Tipo;
    ELSE
        INSERT dbo.LetCopiaComprobante (TipoNcf, Copias, Usuario) VALUES (@Tipo, @Copias, @Usuario);
    SELECT CAST(1 AS BIT) AS Ok, N'Guardado' AS Mensaje;
END
GO
