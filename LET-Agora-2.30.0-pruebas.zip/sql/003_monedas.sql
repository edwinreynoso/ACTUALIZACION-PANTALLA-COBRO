-- Monedas y tasas de cambio. Agora maneja una sola moneda (pesos): todo lo que entra se registra en pesos. Aqui se guarda lo que
-- Agora no guarda: la tabla de tasas por fecha, que forma de pago es de que moneda, cuantos dolares (u otra moneda) recibio cada
-- venta con la tasa de ese momento y el vuelto en pesos (para el cierre de turno y de jornada), y los clientes restringidos.
-- Se ejecuta despues de 000_esquema.sql y antes de 010 y 080 (que usan LetTasaVigente).

SET QUOTED_IDENTIFIER ON
GO

------------------------------------------------------------ LetMoneda de una version anterior de la pantalla
-- La pantalla de cobro original ya tenia dbo.LetMoneda con otra estructura (Id, IdFormaPago, Tasa, Descripcion). Esta version usa el mismo nombre
-- con Codigo, Nombre, Simbolo, Activa y EnPrecuenta. Si la tabla existe sin la columna Codigo se renombra a LetMoneda_Anterior (con sus restricciones),
-- sin perder datos, y mas abajo se crea la nueva y se pasan las formas de pago con tasa.
IF OBJECT_ID(N'dbo.LetMoneda', N'U') IS NOT NULL AND COL_LENGTH(N'dbo.LetMoneda', N'Codigo') IS NULL
BEGIN
    DECLARE @nuevo sysname = N'LetMoneda_Anterior';
    IF OBJECT_ID(N'dbo.' + @nuevo, N'U') IS NOT NULL SET @nuevo = N'LetMoneda_Anterior_' + CONVERT(NVARCHAR(14), GETDATE(), 112) + REPLACE(CONVERT(NVARCHAR(8), GETDATE(), 108), ':', '');
    DECLARE @c sysname, @n INT = 1;
    WHILE @n > 0
    BEGIN
        SET @c = NULL;
        SELECT TOP (1) @c = o.name FROM sys.objects o
         WHERE o.parent_object_id = OBJECT_ID(N'dbo.LetMoneda') AND o.type IN ('PK', 'D', 'UQ', 'C', 'F') AND o.name NOT LIKE N'%[_]Anterior%';
        IF @c IS NULL SET @n = 0;
        ELSE
        BEGIN
            DECLARE @nc sysname = LEFT(@c, 100) + N'_Anterior_' + CONVERT(NVARCHAR(12), @n);
            EXEC sp_rename @objname = @c, @newname = @nc, @objtype = N'OBJECT';
            SET @n += 1;
            IF @n > 50 SET @n = 0;
        END
    END
    EXEC sp_rename @objname = N'dbo.LetMoneda', @newname = @nuevo, @objtype = N'OBJECT';
    PRINT N'Aviso: la tabla dbo.LetMoneda de una version anterior se renombro a ' + @nuevo + N'.';
END
GO

------------------------------------------------------------ usuarios con PIN
-- La misma tabla de usuarios del cierre operativo (008): UsuarioAgora es el nombre del usuario de Agora. PuedeCambiarTasa: es supervisor de la
-- tasa de cambio (solo ellos la cambian). PuedeUsar: puede registrar el cobro real y declarar el cierre de monedas. PuedeFiscalizar: ver 008.
IF OBJECT_ID(N'dbo.LetFlujoInternoUsuario', N'U') IS NULL
CREATE TABLE dbo.LetFlujoInternoUsuario (
    Id              INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_LetFlujoInternoUsuario PRIMARY KEY,
    UsuarioAgora    NVARCHAR(100) NOT NULL CONSTRAINT UQ_LetFlujoInternoUsuario UNIQUE,
    PuedeUsar       BIT NOT NULL CONSTRAINT DF_LetFlujoInternoUsuario_Usar DEFAULT (0),
    PuedeFiscalizar BIT NOT NULL CONSTRAINT DF_LetFlujoInternoUsuario_Fisc DEFAULT (0),
    PinSalt         VARBINARY(16) NULL,
    PinHash         VARBINARY(32) NULL,
    Fallos          INT NOT NULL CONSTRAINT DF_LetFlujoInternoUsuario_Fallos DEFAULT (0),
    BloqueadoHasta  DATETIME NULL,
    Activo          BIT NOT NULL CONSTRAINT DF_LetFlujoInternoUsuario_Activo DEFAULT (1)
)
GO
IF COL_LENGTH(N'dbo.LetFlujoInternoUsuario', N'PuedeCambiarTasa') IS NULL
    ALTER TABLE dbo.LetFlujoInternoUsuario ADD PuedeCambiarTasa BIT NOT NULL CONSTRAINT DF_LetFlujoInternoUsuario_Tasa DEFAULT (0)
GO

------------------------------------------------------------ monedas y tasas
IF OBJECT_ID(N'dbo.LetMoneda', N'U') IS NULL
CREATE TABLE dbo.LetMoneda (
    Codigo      CHAR(3)       NOT NULL CONSTRAINT PK_LetMoneda PRIMARY KEY,   -- USD, EUR...
    Nombre      NVARCHAR(40)  NOT NULL,
    Simbolo     NVARCHAR(6)   NOT NULL,
    Activa      BIT           NOT NULL CONSTRAINT DF_LetMoneda_Activa DEFAULT (1),
    EnPrecuenta BIT           NOT NULL CONSTRAINT DF_LetMoneda_EnPrecuenta DEFAULT (1)   -- sale el total en esta moneda en la precuenta
)
GO
IF NOT EXISTS (SELECT 1 FROM dbo.LetMoneda WHERE Codigo = 'USD')
    INSERT dbo.LetMoneda (Codigo, Nombre, Simbolo) VALUES ('USD', N'Dolar estadounidense', N'US$')
GO

-- Cada cambio de tasa es una fila nueva con su fecha: la tasa de una venta vieja se puede reconstruir.
IF OBJECT_ID(N'dbo.LetTasaCambio', N'U') IS NULL
CREATE TABLE dbo.LetTasaCambio (
    Id      INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_LetTasaCambio PRIMARY KEY,
    Moneda  CHAR(3)        NOT NULL,
    Desde   DATETIME       NOT NULL CONSTRAINT DF_LetTasaCambio_Desde DEFAULT (GETDATE()),
    Tasa    DECIMAL(12,4)  NOT NULL CONSTRAINT CK_LetTasaCambio_Tasa CHECK (Tasa > 0),   -- pesos por 1 unidad de la moneda
    Usuario NVARCHAR(60)   NULL,
    Creado  DATETIME       NOT NULL CONSTRAINT DF_LetTasaCambio_Creado DEFAULT (GETDATE())
)
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_LetTasaCambio_Moneda' AND object_id = OBJECT_ID(N'dbo.LetTasaCambio'))
    CREATE INDEX IX_LetTasaCambio_Moneda ON dbo.LetTasaCambio (Moneda, Desde DESC)
GO

-- Que formas de pago de Agora son de que moneda (ej. la forma de pago "Dolares" -> USD).
IF OBJECT_ID(N'dbo.LetMonedaFormaPago', N'U') IS NULL
CREATE TABLE dbo.LetMonedaFormaPago (
    Moneda         CHAR(3) NOT NULL,
    AgoraPaymentId INT     NOT NULL,
    CONSTRAINT PK_LetMonedaFormaPago PRIMARY KEY (AgoraPaymentId)
)
GO
-- Si venia la tabla anterior: sus formas de pago con tasa mayor que 1 pasan a la moneda USD (el codigo de moneda no se guardaba) y se toma su
-- ultima tasa. Solo corre mientras no haya formas de pago vinculadas; se corrigen luego en el portal (Monedas y tasas).
DECLARE @t sysname = (SELECT TOP (1) name FROM sys.tables WHERE schema_id = SCHEMA_ID(N'dbo') AND name LIKE N'LetMoneda[_]Anterior%' ORDER BY name);
IF @t IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.LetMonedaFormaPago)
   AND COL_LENGTH(N'dbo.' + @t, N'IdFormaPago') IS NOT NULL AND COL_LENGTH(N'dbo.' + @t, N'Tasa') IS NOT NULL
BEGIN
    DECLARE @ord NVARCHAR(10) = CASE WHEN COL_LENGTH(N'dbo.' + @t, N'Id') IS NOT NULL THEN N'a.Id DESC' ELSE N'a.Tasa DESC' END;
    DECLARE @sql NVARCHAR(MAX) = N'INSERT dbo.LetMonedaFormaPago (Moneda, AgoraPaymentId) SELECT ''USD'', a.IdFormaPago FROM dbo.' + QUOTENAME(@t) + N' a
            WHERE a.Tasa > 1 AND a.IdFormaPago IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.LetMonedaFormaPago x WHERE x.AgoraPaymentId = a.IdFormaPago)
            GROUP BY a.IdFormaPago;
          IF NOT EXISTS (SELECT 1 FROM dbo.LetTasaCambio WHERE Moneda = ''USD'')
              INSERT dbo.LetTasaCambio (Moneda, Tasa, Usuario) SELECT TOP (1) ''USD'', a.Tasa, N''migrada'' FROM dbo.' + QUOTENAME(@t) + N' a WHERE a.Tasa > 1 ORDER BY ' + @ord;
    EXEC (@sql);
END
GO

------------------------------------------------------------ lo que recibio cada venta en moneda extranjera
-- Una fila por pago en moneda extranjera de cada factura o nota de credito (la nota va en negativo). Guarda la tasa de ESE momento:
-- asi el cierre suma cada venta con su tasa, aunque la tasa cambie durante el dia, y el valor en pesos coincide con lo que
-- Agora tiene cobrado en esa forma de pago. MontoPesos es lo que Agora registro (TotalPagado); el cliente pudo pagar de mas y
-- recibir VueltoPesos (el vuelto se da en pesos).
IF OBJECT_ID(N'dbo.LetPagoMoneda', N'U') IS NULL
CREATE TABLE dbo.LetPagoMoneda (
    Id                  INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_LetPagoMoneda PRIMARY KEY,
    FacturaFormaPagoId  INT            NOT NULL,
    Serie               NVARCHAR(10)   NOT NULL,
    Numero              INT            NOT NULL,
    IdFormaPago         INT            NOT NULL,
    Moneda              CHAR(3)        NOT NULL,
    Tasa                DECIMAL(12,4)  NOT NULL,
    MontoMoneda         DECIMAL(14,2)  NOT NULL,      -- lo que el cliente entrego, en la moneda extranjera
    MontoPesos          DECIMAL(14,2)  NOT NULL,      -- lo mismo en pesos, con la tasa
    VueltoPesos         DECIMAL(14,2)  NOT NULL CONSTRAINT DF_LetPagoMoneda_Vuelto DEFAULT (0),
    PosId               INT            NULL,
    Fecha               DATETIME       NOT NULL,
    Jornada             DATE           NULL,          -- Pos.BusinessDay de la caja
    Creado              DATETIME       NOT NULL CONSTRAINT DF_LetPagoMoneda_Creado DEFAULT (GETDATE()),
    CONSTRAINT UQ_LetPagoMoneda_Pago UNIQUE (FacturaFormaPagoId)
)
GO
-- Turno: la apertura del turno de Agora (Pos.OpenDate / PosCloseOut.OpenDate) en formato ISO 'AAAA-MM-DDThh:mm:ss'; se llena al registrar el pago (ver LetTurnosCaja).
IF COL_LENGTH(N'dbo.LetPagoMoneda', N'Turno') IS NULL ALTER TABLE dbo.LetPagoMoneda ADD Turno NVARCHAR(40) NULL
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_LetPagoMoneda_Cierre' AND object_id = OBJECT_ID(N'dbo.LetPagoMoneda'))
    CREATE INDEX IX_LetPagoMoneda_Cierre ON dbo.LetPagoMoneda (PosId, Jornada, Moneda) INCLUDE (MontoMoneda, MontoPesos, VueltoPesos)
GO

------------------------------------------------------------ clientes restringidos
-- Un cliente que solo puede cerrar con UNA forma de pago y cuya venta se queda en una serie interna (ej. F): no va a e-Fiscal
-- Cloud y su ticket sale como COMPROBANTE INTERNO NO FISCAL (nunca con e-NCF ni QR de la DGII). Imprimir: S siempre, N nunca,
-- P preguntar al cerrar. Aqui solo estan los datos; el bloqueo de las demas formas de pago y la exclusion se aplican aparte.
IF OBJECT_ID(N'dbo.LetClienteRestringido', N'U') IS NULL
CREATE TABLE dbo.LetClienteRestringido (
    Id                   INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_LetClienteRestringido PRIMARY KEY,
    Rnc                  VARCHAR(20)    NOT NULL CONSTRAINT UQ_LetClienteRestringido_Rnc UNIQUE,
    Nombre               NVARCHAR(200)  NOT NULL,
    IdFormaPagoPermitida INT            NOT NULL,   -- PaymentMethod.Id de Agora: la unica forma de pago que se deja usar
    SerieF               NVARCHAR(10)   NOT NULL,   -- serie interna en que queda la venta
    Imprimir             CHAR(1)        NOT NULL CONSTRAINT DF_LetClienteRestringido_Imprimir DEFAULT ('P') CONSTRAINT CK_LetClienteRestringido_Imprimir CHECK (Imprimir IN ('S', 'N', 'P')),
    Activo               BIT            NOT NULL CONSTRAINT DF_LetClienteRestringido_Activo DEFAULT (1),
    Creado               DATETIME       NOT NULL CONSTRAINT DF_LetClienteRestringido_Creado DEFAULT (GETDATE())
)
GO

------------------------------------------------------------ LetTasaVigente
-- La tasa de una moneda en una fecha (la ultima registrada hasta esa fecha). NULL si nunca se registro.
IF OBJECT_ID(N'[dbo].[LetTasaVigente]') IS NULL EXEC (N'CREATE FUNCTION [dbo].[LetTasaVigente] (@Moneda CHAR(3), @Fecha DATETIME) RETURNS DECIMAL(12,4) AS BEGIN RETURN NULL END')
GO
ALTER FUNCTION [dbo].[LetTasaVigente] (@Moneda CHAR(3), @Fecha DATETIME)
RETURNS DECIMAL(12,4)
AS
BEGIN
    RETURN (SELECT TOP (1) t.Tasa FROM dbo.LetTasaCambio t WHERE t.Moneda = @Moneda AND t.Desde <= ISNULL(@Fecha, GETDATE()) ORDER BY t.Desde DESC, t.Id DESC);
END
GO

------------------------------------------------------------ LetRegistrarMoneda / LetVincularFormaPago
IF OBJECT_ID(N'[dbo].[LetRegistrarMoneda]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetRegistrarMoneda] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetRegistrarMoneda] (@Codigo CHAR(3), @Nombre NVARCHAR(40), @Simbolo NVARCHAR(6), @EnPrecuenta BIT = 1)
AS
BEGIN
    SET NOCOUNT ON;
    SET @Codigo = UPPER(LTRIM(RTRIM(@Codigo)));
    IF LEN(@Codigo) <> 3 OR @Codigo = 'DOP' BEGIN SELECT CAST(0 AS BIT) AS Ok, N'El codigo de la moneda son 3 letras (ej. USD, EUR) y no puede ser DOP, la moneda principal' AS Mensaje; RETURN; END
    IF EXISTS (SELECT 1 FROM dbo.LetMoneda WHERE Codigo = @Codigo)
        UPDATE dbo.LetMoneda SET Nombre = @Nombre, Simbolo = @Simbolo, EnPrecuenta = @EnPrecuenta, Activa = 1 WHERE Codigo = @Codigo;
    ELSE
        INSERT dbo.LetMoneda (Codigo, Nombre, Simbolo, EnPrecuenta) VALUES (@Codigo, @Nombre, @Simbolo, @EnPrecuenta);
    SELECT CAST(1 AS BIT) AS Ok, N'Moneda registrada' AS Mensaje;
END
GO

IF OBJECT_ID(N'[dbo].[LetVincularFormaPago]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetVincularFormaPago] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetVincularFormaPago] (@Moneda CHAR(3), @AgoraPaymentId INT)
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM dbo.LetMoneda WHERE Codigo = @Moneda) BEGIN SELECT CAST(0 AS BIT) AS Ok, N'La moneda no existe: registrela primero' AS Mensaje; RETURN; END
    IF EXISTS (SELECT 1 FROM dbo.LetMonedaFormaPago WHERE AgoraPaymentId = @AgoraPaymentId)
        UPDATE dbo.LetMonedaFormaPago SET Moneda = @Moneda WHERE AgoraPaymentId = @AgoraPaymentId;
    ELSE
        INSERT dbo.LetMonedaFormaPago (Moneda, AgoraPaymentId) VALUES (@Moneda, @AgoraPaymentId);
    -- La forma de pago toma la tasa vigente (la pantalla de cobro convierte con LETMetodoPagos.Rate).
    DECLARE @Tasa DECIMAL(12,4) = dbo.LetTasaVigente(@Moneda, GETDATE());
    IF @Tasa IS NOT NULL UPDATE dbo.LETMetodoPagos SET Rate = @Tasa WHERE AgoraPaymentId = @AgoraPaymentId;
    SELECT CAST(1 AS BIT) AS Ok, N'Forma de pago vinculada' AS Mensaje;
END
GO

------------------------------------------------------------ LetRegistrarTasa
-- Registra la tasa del dia de una moneda y la deja en las formas de pago de esa moneda (la pantalla de cobro convierte con
-- LETMetodoPagos.Rate, que guarda 2 decimales) y, para el dolar, donde la precuenta y el ticket leian la tasa antes
-- (LetPrecuentaConfiguracion.TasaDolar y MonitorParametros.TasaDolar).
IF OBJECT_ID(N'[dbo].[LetRegistrarTasa]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetRegistrarTasa] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetRegistrarTasa] (@Moneda CHAR(3), @Tasa DECIMAL(12,4), @Usuario NVARCHAR(100) = NULL, @Pin NVARCHAR(40) = NULL, @PorAdministrador BIT = 0, @Confirmado BIT = 0)
AS
BEGIN
    SET NOCOUNT ON;
    -- La tasa la cambia un supervisor (usuario con permiso de cambiar la tasa y su PIN: LetFlujoInternoUsuarioGuardar ... @PuedeCambiarTasa = 1) o, desde el portal,
    -- un administrador ya autenticado (@PorAdministrador = 1; el portal solo lo pide con rol ADMIN y deja el usuario en la auditoria). @Usuario queda en el historial.
    DECLARE @AutOk BIT = 1, @AutMotivo NVARCHAR(200);
    IF @PorAdministrador = 0
    BEGIN
        EXEC dbo.LetFlujoInternoAutenticar @Usuario, @Pin, 'TASA', @AutOk OUTPUT, @AutMotivo OUTPUT;
        IF @AutOk = 0 BEGIN SELECT CAST(0 AS BIT) AS Ok, @AutMotivo + N' (la tasa la cambia un supervisor con permiso de tasa o un administrador del portal)' AS Mensaje; RETURN; END
    END
    SET @Moneda = UPPER(LTRIM(RTRIM(@Moneda)));
    IF NOT EXISTS (SELECT 1 FROM dbo.LetMoneda WHERE Codigo = @Moneda AND Activa = 1) BEGIN SELECT CAST(0 AS BIT) AS Ok, N'La moneda no existe o esta inactiva' AS Mensaje; RETURN; END
    IF @Tasa IS NULL OR @Tasa <= 0 OR @Tasa > 100000 BEGIN SELECT CAST(0 AS BIT) AS Ok, N'La tasa debe ser mayor que 0 (pesos por 1 ' + @Moneda + N')' AS Mensaje; RETURN; END
    -- Una tasa que se aleja mas de 25% de la anterior casi siempre es un error de digitacion (580 en vez de 58): se rechaza salvo que quien la cambia
    -- la confirme (@Confirmado = 1; el portal lo pide con una pregunta).
    DECLARE @Anterior DECIMAL(12,4) = dbo.LetTasaVigente(@Moneda, GETDATE());
    IF @Anterior IS NOT NULL AND @Confirmado = 0 AND (@Tasa > @Anterior * 1.25 OR @Tasa < @Anterior * 0.75)
    BEGIN SELECT CAST(0 AS BIT) AS Ok, N'La tasa cambia mas de 25% respecto a la anterior (' + CONVERT(NVARCHAR(20), @Anterior) + N'): revise que este bien escrita' AS Mensaje; RETURN; END

    BEGIN TRANSACTION;
    INSERT dbo.LetTasaCambio (Moneda, Tasa, Usuario) VALUES (@Moneda, @Tasa, LEFT(@Usuario, 60));
    UPDATE m SET Rate = @Tasa FROM dbo.LETMetodoPagos m JOIN dbo.LetMonedaFormaPago x ON x.AgoraPaymentId = m.AgoraPaymentId WHERE x.Moneda = @Moneda;
    IF @Moneda = 'USD'
    BEGIN
        IF OBJECT_ID(N'dbo.LetPrecuentaConfiguracion', N'U') IS NOT NULL
            EXEC sp_executesql N'UPDATE dbo.LetPrecuentaConfiguracion SET TasaDolar = @t', N'@t DECIMAL(12,4)', @Tasa;
        IF OBJECT_ID(N'dbo.MonitorParametros', N'U') IS NOT NULL
            EXEC sp_executesql N'UPDATE dbo.MonitorParametros SET TasaDolar = @t', N'@t DECIMAL(12,2)', @Tasa;
    END
    COMMIT TRANSACTION;
    SELECT CAST(1 AS BIT) AS Ok, N'Tasa registrada: 1 ' + @Moneda + N' = RD$ ' + CONVERT(NVARCHAR(20), @Tasa) AS Mensaje;
END
GO

------------------------------------------------------------ LetRegistrarPagosMoneda
-- Se llama al crear una factura o nota de credito: guarda lo que el cliente entrego en cada moneda extranjera con la tasa de ese
-- momento (la de la forma de pago, que es la que uso la pantalla de cobro). Se puede llamar mas de una vez: no repite filas.
IF OBJECT_ID(N'[dbo].[LetRegistrarPagosMoneda]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetRegistrarPagosMoneda] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetRegistrarPagosMoneda] (@Serie NVARCHAR(10), @Numero INT)
AS
BEGIN
    SET NOCOUNT ON;
    -- (En dbo.Factura una venta normal trae RelatedInvoiceId = 0, no NULL; solo la nota de credito apunta a la venta que devuelve.)
    -- Una nota de credito devuelve dinero: sus montos van en negativo para que el cierre los reste.
    DECLARE @Signo INT = CASE WHEN EXISTS (SELECT 1 FROM dbo.Factura f WHERE f.Serie = @Serie AND f.Numero = @Numero AND ISNULL(f.RelatedInvoiceId, 0) <> 0) THEN -1 ELSE 1 END;

    INSERT dbo.LetPagoMoneda (FacturaFormaPagoId, Serie, Numero, IdFormaPago, Moneda, Tasa, MontoMoneda, MontoPesos, VueltoPesos, PosId, Fecha)
    SELECT ffp.Id, ffp.Serie, ffp.Numero, ffp.IdFormaPago, x.Moneda, t.Tasa,
           @Signo * CAST(ROUND(ffp.TotalPagado / t.Tasa, 2) AS DECIMAL(14,2)),
           @Signo * ffp.TotalPagado, @Signo * ISNULL(ffp.TotalDevuelta, 0), ffp.PosId, ffp.Fecha
    FROM dbo.FacturaFormaPago ffp
    JOIN dbo.LetMonedaFormaPago x ON x.AgoraPaymentId = ffp.IdFormaPago
    CROSS APPLY (SELECT COALESCE(NULLIF((SELECT TOP (1) m.Rate FROM dbo.LETMetodoPagos m WHERE m.AgoraPaymentId = ffp.IdFormaPago ORDER BY m.Id), 1),
                                 dbo.LetTasaVigente(x.Moneda, ffp.Fecha)) AS Tasa) t
    WHERE ffp.Serie = @Serie AND ffp.Numero = @Numero AND t.Tasa > 0
      AND NOT EXISTS (SELECT 1 FROM dbo.LetPagoMoneda p WHERE p.FacturaFormaPagoId = ffp.Id);

    -- La jornada de la caja (Pos.BusinessDay) y el turno (la apertura del turno abierto, Pos.OpenDate: es la misma fecha que Agora guarda en
    -- PosCloseOut.OpenDate al cerrar el turno), si las tablas existen en esta base.
    IF OBJECT_ID(N'dbo.Pos', N'U') IS NOT NULL AND COL_LENGTH(N'dbo.Pos', N'OpenDate') IS NOT NULL
        EXEC sp_executesql N'UPDATE p SET Jornada = CONVERT(DATE, ps.BusinessDay), Turno = CONVERT(NVARCHAR(19), ps.OpenDate, 126)
                               FROM dbo.LetPagoMoneda p JOIN dbo.Pos ps ON ps.Id = p.PosId
                              WHERE p.Serie = @s AND p.Numero = @n AND p.Jornada IS NULL AND ps.BusinessDay IS NOT NULL', N'@s NVARCHAR(10), @n INT', @Serie, @Numero;
    ELSE IF OBJECT_ID(N'dbo.Pos', N'U') IS NOT NULL
        EXEC sp_executesql N'UPDATE p SET Jornada = CONVERT(DATE, ps.BusinessDay)
                               FROM dbo.LetPagoMoneda p JOIN dbo.Pos ps ON ps.Id = p.PosId
                              WHERE p.Serie = @s AND p.Numero = @n AND p.Jornada IS NULL', N'@s NVARCHAR(10), @n INT', @Serie, @Numero;
    -- Si la caja ya estaba cerrada al registrar (llamada tardia), el turno es el cierre de Agora que cubre la fecha del pago.
    IF OBJECT_ID(N'dbo.PosCloseOut', N'U') IS NOT NULL
        EXEC sp_executesql N'UPDATE p SET Turno = CONVERT(NVARCHAR(19), co.OpenDate, 126), Jornada = ISNULL(p.Jornada, CONVERT(DATE, co.BusinessDay))
                               FROM dbo.LetPagoMoneda p
                               CROSS APPLY (SELECT TOP (1) c.OpenDate, c.BusinessDay FROM dbo.PosCloseOut c
                                             WHERE c.PosId = p.PosId AND p.Fecha >= c.OpenDate AND p.Fecha <= c.CloseDate ORDER BY c.Id DESC) co
                              WHERE p.Serie = @s AND p.Numero = @n AND p.Turno IS NULL', N'@s NVARCHAR(10), @n INT', @Serie, @Numero;
END
GO

------------------------------------------------------------ clientes restringidos: alta y consulta
IF OBJECT_ID(N'[dbo].[LetRegistrarClienteRestringido]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetRegistrarClienteRestringido] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetRegistrarClienteRestringido] (@Rnc VARCHAR(20), @Nombre NVARCHAR(200), @IdFormaPago INT, @SerieF NVARCHAR(10), @Imprimir CHAR(1) = 'P', @Activo BIT = 1)
AS
BEGIN
    SET NOCOUNT ON;
    SET @Rnc = REPLACE(REPLACE(LTRIM(RTRIM(ISNULL(@Rnc, ''))), '-', ''), ' ', '');
    SET @Imprimir = UPPER(ISNULL(@Imprimir, 'P'));
    IF @Rnc = '' OR @Rnc LIKE '%[^0-9]%' BEGIN SELECT CAST(0 AS BIT) AS Ok, N'El RNC son solo numeros' AS Mensaje; RETURN; END
    IF LTRIM(RTRIM(ISNULL(@Nombre, N''))) = N'' BEGIN SELECT CAST(0 AS BIT) AS Ok, N'Falta el nombre del cliente' AS Mensaje; RETURN; END
    IF LTRIM(RTRIM(ISNULL(@SerieF, N''))) = N'' BEGIN SELECT CAST(0 AS BIT) AS Ok, N'Falta la serie interna (ej. F)' AS Mensaje; RETURN; END
    IF @Imprimir NOT IN ('S', 'N', 'P') BEGIN SELECT CAST(0 AS BIT) AS Ok, N'Imprimir: S (siempre), N (nunca) o P (preguntar)' AS Mensaje; RETURN; END
    IF EXISTS (SELECT 1 FROM dbo.LetClienteRestringido WHERE Rnc = @Rnc)
        UPDATE dbo.LetClienteRestringido SET Nombre = @Nombre, IdFormaPagoPermitida = @IdFormaPago, SerieF = LTRIM(RTRIM(@SerieF)), Imprimir = @Imprimir, Activo = @Activo WHERE Rnc = @Rnc;
    ELSE
        INSERT dbo.LetClienteRestringido (Rnc, Nombre, IdFormaPagoPermitida, SerieF, Imprimir, Activo) VALUES (@Rnc, @Nombre, @IdFormaPago, LTRIM(RTRIM(@SerieF)), @Imprimir, @Activo);
    SELECT CAST(1 AS BIT) AS Ok, N'Cliente restringido guardado' AS Mensaje;
END
GO

IF OBJECT_ID(N'[dbo].[LetClienteRestringidoDe]') IS NULL EXEC (N'CREATE FUNCTION [dbo].[LetClienteRestringidoDe] () RETURNS TABLE AS RETURN SELECT 1 AS c')
GO
-- La fila del cliente restringido de un RNC (vacia si no lo es o esta inactivo).
ALTER FUNCTION [dbo].[LetClienteRestringidoDe] (@Rnc VARCHAR(20))
RETURNS TABLE
AS
RETURN
    SELECT c.Id, c.Rnc, c.Nombre, c.IdFormaPagoPermitida, c.SerieF, c.Imprimir
      FROM dbo.LetClienteRestringido c
     WHERE c.Rnc = REPLACE(REPLACE(LTRIM(RTRIM(ISNULL(@Rnc, ''))), '-', ''), ' ', '') AND c.Activo = 1
GO

------------------------------------------------------------ cierre de monedas (jornada y turno)
-- Lo que el cajero cuenta de cada moneda extranjera al cerrar, contra lo que el sistema dice que debe haber. Cada declaracion es una fila nueva
-- (un cierre se puede recontar y queda la historia); la que vale es la ultima. Turno es opcional: sin turno se cierra la jornada completa.
IF OBJECT_ID(N'dbo.LetCierreMoneda', N'U') IS NULL
CREATE TABLE dbo.LetCierreMoneda (
    Id          INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_LetCierreMoneda PRIMARY KEY,
    PosId       INT           NULL,
    Jornada     DATE          NOT NULL,
    Turno       NVARCHAR(40)  NULL,
    Moneda      CHAR(3)       NOT NULL,
    Esperado    DECIMAL(14,2) NOT NULL,          -- recibido - devuelto en esa moneda, segun las ventas
    Contado     DECIMAL(14,2) NOT NULL,          -- lo que el cajero conto
    Diferencia  AS (Contado - Esperado) PERSISTED,
    PesosAgora  DECIMAL(14,2) NOT NULL,          -- el valor en pesos que va en el cierre de Agora para esa forma de pago
    Usuario     NVARCHAR(100) NULL,
    Fecha       DATETIME      NOT NULL CONSTRAINT DF_LetCierreMoneda_Fecha DEFAULT (GETDATE())
)
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_LetCierreMoneda_Cierre' AND object_id = OBJECT_ID(N'dbo.LetCierreMoneda'))
    CREATE INDEX IX_LetCierreMoneda_Cierre ON dbo.LetCierreMoneda (PosId, Jornada, Moneda, Id DESC)
GO

IF OBJECT_ID(N'[dbo].[LetCierreMonedas]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetCierreMonedas] AS RETURN 0')
GO
-- Resumen por moneda de una caja y una jornada (sin @PosId = todas las cajas; sin @Jornada = la ultima con movimiento; con @Turno solo ese turno).
-- Recibido = lo que entraron las ventas menos lo devuelto en notas de credito, en la moneda extranjera. PesosEquivalente es el valor en pesos
-- que Agora tiene cobrado en la forma de pago de esa moneda (cada venta con su tasa): es el numero que va en el cierre de Agora.
-- VueltoPesos es lo entregado en pesos como cambio de esas ventas (sale de la gaveta en pesos).
ALTER PROCEDURE [dbo].[LetCierreMonedas] (@PosId INT = NULL, @Jornada DATE = NULL, @Turno NVARCHAR(40) = NULL)
AS
BEGIN
    SET NOCOUNT ON;
    IF @Jornada IS NULL
        SELECT @Jornada = MAX(ISNULL(p.Jornada, CAST(p.Fecha AS DATE))) FROM dbo.LetPagoMoneda p WHERE (@PosId IS NULL OR p.PosId = @PosId);
    SET @Jornada = ISNULL(@Jornada, CAST(GETDATE() AS DATE));

    SELECT m.Codigo AS Moneda, m.Simbolo, @Jornada AS Jornada, @PosId AS PosId, @Turno AS Turno,
           ISNULL(v.Ventas, 0) AS Ventas,
           ISNULL(v.Recibido, 0) AS Recibido,
           ISNULL(v.PesosEquivalente, 0) AS PesosEquivalente,
           ISNULL(v.VueltoPesos, 0) AS VueltoPesos,
           CASE WHEN ISNULL(v.Recibido, 0) <> 0 THEN CAST(v.PesosEquivalente / v.Recibido AS DECIMAL(12,4)) END AS TasaPromedio,
           d.Contado AS Declarado, d.Diferencia, d.Usuario AS DeclaradoPor, d.Fecha AS FechaDeclaracion
      FROM dbo.LetMoneda m
      OUTER APPLY (SELECT COUNT(*) AS Ventas, SUM(p.MontoMoneda) AS Recibido, SUM(p.MontoPesos) AS PesosEquivalente, SUM(p.VueltoPesos) AS VueltoPesos
                     FROM dbo.LetPagoMoneda p
                    WHERE p.Moneda = m.Codigo AND (@PosId IS NULL OR p.PosId = @PosId)
                      AND ISNULL(p.Jornada, CAST(p.Fecha AS DATE)) = @Jornada AND (@Turno IS NULL OR p.Turno = @Turno)) v
      OUTER APPLY (SELECT TOP (1) c.Contado, c.Diferencia, c.Usuario, c.Fecha FROM dbo.LetCierreMoneda c
                    WHERE c.Moneda = m.Codigo AND ISNULL(c.PosId, -1) = ISNULL(@PosId, -1) AND c.Jornada = @Jornada AND ISNULL(c.Turno, N'') = ISNULL(@Turno, N'')
                    ORDER BY c.Id DESC) d
     WHERE m.Activa = 1 AND (ISNULL(v.Ventas, 0) > 0 OR d.Contado IS NOT NULL OR EXISTS (SELECT 1 FROM dbo.LetMonedaFormaPago x WHERE x.Moneda = m.Codigo))
     ORDER BY m.Codigo;
END
GO

IF OBJECT_ID(N'[dbo].[LetCierreMonedaDeclarar]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetCierreMonedaDeclarar] AS RETURN 0')
GO
-- El cajero declara lo que conto de una moneda. Pide usuario con permiso (PuedeUsar) y su PIN. Guarda lo esperado en ese momento, lo contado y la diferencia.
ALTER PROCEDURE [dbo].[LetCierreMonedaDeclarar] (@PosId INT, @Jornada DATE, @Moneda CHAR(3), @Contado DECIMAL(14,2), @Usuario NVARCHAR(100), @Pin NVARCHAR(40), @Turno NVARCHAR(40) = NULL)
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Ok BIT, @Motivo NVARCHAR(200);
    EXEC dbo.LetFlujoInternoAutenticar @Usuario, @Pin, 'USAR', @Ok OUTPUT, @Motivo OUTPUT;
    IF @Ok = 0 BEGIN SELECT CAST(0 AS BIT) AS Ok, @Motivo AS Mensaje; RETURN; END
    SET @Moneda = UPPER(LTRIM(RTRIM(@Moneda)));
    IF NOT EXISTS (SELECT 1 FROM dbo.LetMoneda WHERE Codigo = @Moneda AND Activa = 1) BEGIN SELECT CAST(0 AS BIT) AS Ok, N'La moneda no existe o esta inactiva' AS Mensaje; RETURN; END
    IF @Contado IS NULL OR @Contado < 0 BEGIN SELECT CAST(0 AS BIT) AS Ok, N'Lo contado no puede ser negativo' AS Mensaje; RETURN; END
    IF @Jornada IS NULL BEGIN SELECT CAST(0 AS BIT) AS Ok, N'Falta la jornada' AS Mensaje; RETURN; END

    DECLARE @Esperado DECIMAL(14,2), @Pesos DECIMAL(14,2);
    SELECT @Esperado = ISNULL(SUM(p.MontoMoneda), 0), @Pesos = ISNULL(SUM(p.MontoPesos), 0)
      FROM dbo.LetPagoMoneda p
     WHERE p.Moneda = @Moneda AND (@PosId IS NULL OR p.PosId = @PosId) AND ISNULL(p.Jornada, CAST(p.Fecha AS DATE)) = @Jornada AND (@Turno IS NULL OR p.Turno = @Turno);
    -- Doble clic: la misma declaracion del mismo usuario en los ultimos 30 segundos no se repite.
    IF EXISTS (SELECT 1 FROM dbo.LetCierreMoneda WHERE ISNULL(PosId, -1) = ISNULL(@PosId, -1) AND Jornada = @Jornada AND ISNULL(Turno, N'') = ISNULL(@Turno, N'')
                  AND Moneda = @Moneda AND Contado = @Contado AND Usuario = @Usuario AND Fecha > DATEADD(SECOND, -30, GETDATE()))
    BEGIN SELECT CAST(1 AS BIT) AS Ok, N'Esa declaracion ya estaba registrada (no se repite)' AS Mensaje; RETURN; END

    INSERT dbo.LetCierreMoneda (PosId, Jornada, Turno, Moneda, Esperado, Contado, PesosAgora, Usuario) VALUES (@PosId, @Jornada, @Turno, @Moneda, @Esperado, @Contado, @Pesos, @Usuario);
    DECLARE @Dif DECIMAL(14,2) = @Contado - @Esperado;
    SELECT CAST(1 AS BIT) AS Ok,
           CASE WHEN @Dif = 0 THEN N'Declarado: cuadra (' + CONVERT(NVARCHAR(30), @Contado) + N' ' + @Moneda + N')'
                WHEN @Dif > 0 THEN N'Declarado: SOBRAN ' + CONVERT(NVARCHAR(30), @Dif) + N' ' + @Moneda + N' (esperado ' + CONVERT(NVARCHAR(30), @Esperado) + N')'
                ELSE N'Declarado: FALTAN ' + CONVERT(NVARCHAR(30), -@Dif) + N' ' + @Moneda + N' (esperado ' + CONVERT(NVARCHAR(30), @Esperado) + N')' END AS Mensaje;
END
GO

------------------------------------------------------------ LetTurnosCaja
-- Los turnos de una caja en una jornada (o todos los de la jornada): los cerrados salen de PosCloseOut (el cierre de caja de Agora) y el abierto de Pos.
-- Turno es la clave que se pasa a LetCierreMonedas / LetCierreMonedaDeclarar para cerrar las monedas por turno. Solo lee.
IF OBJECT_ID(N'[dbo].[LetTurnosCaja]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetTurnosCaja] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetTurnosCaja] (@PosId INT = NULL, @Jornada DATE = NULL)
AS
BEGIN
    SET NOCOUNT ON;
    IF OBJECT_ID(N'dbo.PosCloseOut', N'U') IS NULL OR OBJECT_ID(N'dbo.Pos', N'U') IS NULL
    BEGIN SELECT CAST(NULL AS INT) AS PosId, CAST(NULL AS NVARCHAR(40)) AS Turno WHERE 1 = 0; RETURN; END
    EXEC sp_executesql N'
    SELECT t.PosId, t.Caja, t.Jornada, CONVERT(NVARCHAR(19), t.Apertura, 126) AS Turno, t.Apertura, t.Cierre, t.Abierto,
           ua.Name AS AbiertoPor, uc.Name AS CerradoPor, t.EfectivoEsperado, t.EfectivoContado
      FROM (SELECT c.PosId, p.Name AS Caja, CONVERT(DATE, c.BusinessDay) AS Jornada, c.OpenDate AS Apertura, c.CloseDate AS Cierre, CAST(0 AS BIT) AS Abierto,
                   c.OpenerUserId, c.CloserUserId, c.CashExpectedEndAmount AS EfectivoEsperado, c.CashActualEndAmount AS EfectivoContado
              FROM dbo.PosCloseOut c LEFT JOIN dbo.Pos p ON p.Id = c.PosId
            UNION ALL
            SELECT p.Id, p.Name, CONVERT(DATE, p.BusinessDay), p.OpenDate, NULL, CAST(1 AS BIT), NULL, NULL, NULL, NULL
              FROM dbo.Pos p WHERE p.BusinessDay IS NOT NULL) t
      LEFT JOIN dbo.[User] ua ON ua.Id = t.OpenerUserId
      LEFT JOIN dbo.[User] uc ON uc.Id = t.CloserUserId
     WHERE (@PosId IS NULL OR t.PosId = @PosId) AND (@Jornada IS NULL OR t.Jornada = @Jornada)
     ORDER BY t.Jornada, t.PosId, t.Apertura', N'@PosId INT, @Jornada DATE', @PosId, @Jornada;
END
GO

-- La pantalla original leia las monedas con dbo.ObtenerMoneda sobre la tabla anterior. Si ese procedimiento sigue apuntando a ella, se vuelve a escribir
-- para que devuelva lo mismo (Id, IdFormaPago, Tasa, Descripcion) desde la estructura nueva. Si no existe no se crea (no cambia nada en instalaciones nuevas).
IF OBJECT_ID(N'dbo.ObtenerMoneda', N'P') IS NOT NULL
   AND OBJECT_DEFINITION(OBJECT_ID(N'dbo.ObtenerMoneda')) LIKE N'%LetMoneda%'
   AND OBJECT_DEFINITION(OBJECT_ID(N'dbo.ObtenerMoneda')) NOT LIKE N'%LetMonedaFormaPago%'
    EXEC (N'ALTER PROCEDURE dbo.ObtenerMoneda AS
BEGIN
    SET NOCOUNT ON;
    SELECT CAST(ROW_NUMBER() OVER (ORDER BY x.AgoraPaymentId) AS INT) AS Id, x.AgoraPaymentId AS IdFormaPago,
           CAST(ISNULL(dbo.LetTasaVigente(x.Moneda, GETDATE()), 1) AS DECIMAL(18, 4)) AS Tasa, m.Nombre AS Descripcion
      FROM dbo.LetMonedaFormaPago x JOIN dbo.LetMoneda m ON m.Codigo = x.Moneda
     WHERE m.Activa = 1;
END')
GO
