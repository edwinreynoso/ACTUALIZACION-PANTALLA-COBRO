﻿-- 125_erp_hub.sql
-- Emisor hacia el ERP Financiero Hub (ADR-0019, fase 1). El servicio NO toca el flujo de cobro de Agora: lee, por cada turno de caja YA CERRADO (PosCloseOut), las ventas y notas de credito
-- que e-Fiscal ya acepto (LetFE_Cola) y arma los eventos del conector `agora` del ERP: venta.fiscalizada, nota.fiscalizada y, al final, turno.cerrado.
-- Un turno solo se encola cuando TODOS sus documentos estan aceptados y cuadran; si no, queda anotado en LetERP_Turno con el motivo (ESPERANDO o REVISAR) y se reintenta solo.
-- Idempotente. No lleva variables del instalador. Los importes viajan como texto con 2 decimales (contrato v1 del ERP) y las fechas con el desfase horario del equipo (@Offset).

IF OBJECT_ID(N'dbo.LetERP_FormaPago', N'U') IS NULL
CREATE TABLE dbo.LetERP_FormaPago (
    IdFormaPago INT NOT NULL CONSTRAINT PK_LetERP_FormaPago PRIMARY KEY,
    Metodo      VARCHAR(14) NOT NULL CONSTRAINT CK_LetERP_FormaPago CHECK (Metodo IN ('CASH','CARD','TRANSFER','COMPLIMENTARY','OTHER'))
)
GO
IF OBJECT_ID(N'dbo.LetERP_Cola', N'U') IS NULL
CREATE TABLE dbo.LetERP_Cola (
    Id             INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_LetERP_Cola PRIMARY KEY,
    EventId        NVARCHAR(120) NOT NULL CONSTRAINT UQ_LetERP_Cola_Evento UNIQUE,
    Tipo           VARCHAR(30)   NOT NULL,
    PosId          INT           NOT NULL,
    Turno          DATETIME      NOT NULL,
    Payload        NVARCHAR(MAX) NOT NULL,
    Estado         VARCHAR(12)   NOT NULL CONSTRAINT DF_LetERP_Cola_Estado DEFAULT ('PENDIENTE'),   -- PENDIENTE | ENVIADO | ERROR
    Intentos       INT           NOT NULL CONSTRAINT DF_LetERP_Cola_Intentos DEFAULT (0),
    ProximoIntento DATETIME      NOT NULL CONSTRAINT DF_LetERP_Cola_Prox DEFAULT (GETDATE()),
    UltimoError    NVARCHAR(500) NULL,
    Creado         DATETIME      NOT NULL CONSTRAINT DF_LetERP_Cola_Creado DEFAULT (GETDATE()),
    Enviado        DATETIME      NULL
)
GO
IF OBJECT_ID(N'dbo.LetERP_Turno', N'U') IS NULL
CREATE TABLE dbo.LetERP_Turno (
    PosId       INT           NOT NULL,
    Turno       DATETIME      NOT NULL,                       -- apertura del turno (PosCloseOut.OpenDate)
    Estado      VARCHAR(12)   NOT NULL,                       -- ENCOLADO | SIN_VENTAS | ESPERANDO | REVISAR
    Motivo      NVARCHAR(500) NULL,
    Documentos  INT           NULL,
    Actualizado DATETIME      NOT NULL CONSTRAINT DF_LetERP_Turno_Act DEFAULT (GETDATE()),
    CONSTRAINT PK_LetERP_Turno PRIMARY KEY (PosId, Turno)
)
GO

-- Forma de pago de Agora -> medio del ERP: por el codigo DGII (01 efectivo, 03 tarjeta, 02 cheque o transferencia); una forma llamada «cortesia» es COMPLIMENTARY; el resto, OTHER.
-- Solo agrega las que faltan: lo que el administrador cambio a mano no se pisa.
IF OBJECT_ID(N'[dbo].[LetERPFormasSembrar]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetERPFormasSembrar] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetERPFormasSembrar]
AS
BEGIN
    SET NOCOUNT ON;
    INSERT dbo.LetERP_FormaPago (IdFormaPago, Metodo)
    SELECT r.IdFormaPago,
           CASE WHEN r.Desrcipcion LIKE N'%cortes%' THEN 'COMPLIMENTARY'
                WHEN LTRIM(RTRIM(r.Tipo)) = '01' THEN 'CASH'
                WHEN LTRIM(RTRIM(r.Tipo)) = '03' THEN 'CARD'
                WHEN LTRIM(RTRIM(r.Tipo)) = '02' THEN 'TRANSFER'
                ELSE 'OTHER' END
      FROM (SELECT IdFormaPago, MIN(Tipo) AS Tipo, MIN(Desrcipcion) AS Desrcipcion FROM dbo.FacturaFormaPagoRelacion GROUP BY IdFormaPago) r
     WHERE NOT EXISTS (SELECT 1 FROM dbo.LetERP_FormaPago m WHERE m.IdFormaPago = r.IdFormaPago);
END
GO

-- Arma el JSON de UN documento (venta o nota ya aceptada). @Problema queda con el motivo si el documento no cuadra o no se puede enviar (entonces @Json queda nulo).
IF OBJECT_ID(N'[dbo].[LetERPDocumento]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetERPDocumento] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetERPDocumento] (@Serie NVARCHAR(10), @Numero INT, @Rnc VARCHAR(20), @Offset VARCHAR(6), @Dia DATE, @Apertura DATETIME, @Sucursal VARCHAR(20), @Json NVARCHAR(MAX) OUTPUT, @Problema NVARCHAR(500) OUTPUT)
AS
BEGIN
    SET NOCOUNT ON;
    SET @Json = NULL; SET @Problema = NULL;
    DECLARE @Doc CHAR(1), @Tipo INT, @Encf VARCHAR(20), @Estado VARCHAR(20), @RefEncf VARCHAR(20), @PosId INT, @Fecha DATETIME, @TotalAgora DECIMAL(14,2), @Ubic NVARCHAR(100);
    SELECT TOP (1) @Doc = c.Documento, @Tipo = c.TipoEcf, @Encf = c.Encf, @Estado = c.Estado, @RefEncf = c.ReferenciaEncf
      FROM dbo.LetFE_Cola c WHERE c.Serie = @Serie AND c.Numero = @Numero;
    SELECT TOP (1) @PosId = f.PosId, @Fecha = f.Fecha, @TotalAgora = ABS(f.TotalNeto), @Ubic = f.Ubicacion
      FROM dbo.Factura f WHERE f.Serie = @Serie AND f.Numero = @Numero ORDER BY f.Id DESC;
    IF @Doc IS NULL OR @PosId IS NULL BEGIN SET @Problema = N'El documento no esta en la cola de e-Fiscal o no tiene factura en Agora'; RETURN; END
    IF @Encf IS NULL OR @Encf NOT LIKE 'E%' OR LEN(@Encf) <> 13 BEGIN SET @Problema = N'El comprobante no tiene un e-NCF valido (' + ISNULL(@Encf, N'vacio') + N')'; RETURN; END
    IF @Doc = 'N' AND (@RefEncf IS NULL OR @RefEncf NOT LIKE 'E%' OR LEN(@RefEncf) <> 13) BEGIN SET @Problema = N'La nota de credito no tiene el e-NCF de la factura que modifica'; RETURN; END

    -- Importes: manda el ENCABEZADO de la factura (Base + Impuestos + Propina = lo cobrado; cuadra en todas las ventas de la base de ejemplo). El detalle de lineas de Agora no es confiable para el
    -- impuesto (en articulos «Itbis + Ley» el Impuesto de la linea no corresponde al 18 % ni al 28 %), asi que de cada linea solo se usa su neto como PESO para repartir los importes del documento.
    -- Impuestos del encabezado: con Propina > 0 el ITBIS es Impuestos y el cargo por servicio (ley 10 %) es Propina; si Propina = 0 y Impuestos es el 28 % de la base, es «Itbis + Ley» junto
    -- y se separa en ITBIS 18 % y cargo por servicio (el resto); en otro caso todo el Impuestos es ITBIS. Los centavos de redondeo van a la linea de mayor neto.
    DECLARE @Base DECIMAL(14,2), @ImpH DECIMAL(14,2), @Prop DECIMAL(14,2);
    SELECT TOP (1) @Base = ABS(ISNULL(f.BaseImponible, 0)), @ImpH = ABS(ISNULL(f.Impuestos, 0)), @Prop = ABS(ISNULL(f.Propina, 0)) FROM dbo.Factura f WHERE f.Serie = @Serie AND f.Numero = @Numero ORDER BY f.Id DESC;
    IF ABS(@Base + @ImpH + @Prop - @TotalAgora) > 0.05 BEGIN SET @Problema = N'La factura de Agora no cuadra: base + impuestos + propina no es el total cobrado'; RETURN; END
    DECLARE @TItbis DECIMAL(14,2) = @ImpH, @TServ DECIMAL(14,2) = @Prop;
    IF @Prop = 0 AND @Base > 0 AND ABS(@ImpH - ROUND(@Base * 0.28, 2)) <= 0.05 BEGIN SET @TItbis = ROUND(@Base * 0.18, 2); SET @TServ = @ImpH - @TItbis; END

    DECLARE @L TABLE (Id INT, Nombre NVARCHAR(300), Cant DECIMAL(14,4), Peso DECIMAL(14,2), Tasa DECIMAL(6,4), Neto DECIMAL(14,2), Imp DECIMAL(14,2), Serv DECIMAL(14,2), Dto DECIMAL(14,2), Tot DECIMAL(14,2));
    INSERT @L (Id, Nombre, Cant, Peso, Tasa, Neto, Imp, Serv, Dto, Tot)
    SELECT d.Id, LEFT(ISNULL(NULLIF(LTRIM(RTRIM(d.Descripcion)), N''), N'Articulo'), 300), CAST(ABS(ISNULL(d.Cantidad, 0)) AS DECIMAL(14,4)), ABS(ISNULL(d.Importe, 0)), 0, 0, 0, 0, ROUND(ABS(ISNULL(d.MontoDescuento, 0)), 2), 0
      FROM dbo.FacturaDetalle d WHERE d.Serie = @Serie AND d.Numero = @Numero;
    IF NOT EXISTS (SELECT 1 FROM @L) BEGIN SET @Problema = N'El documento no tiene lineas'; RETURN; END
    DECLARE @Pesos DECIMAL(14,2) = (SELECT SUM(Peso) FROM @L);
    IF @Pesos <= 0 BEGIN SET @Problema = N'Las lineas no tienen importe para repartir el documento'; RETURN; END
    UPDATE @L SET Neto = ROUND(@Base * Peso / @Pesos, 2), Imp = ROUND(@TItbis * Peso / @Pesos, 2), Serv = ROUND(@TServ * Peso / @Pesos, 2);
    DECLARE @Mayor INT = (SELECT TOP (1) Id FROM @L ORDER BY Peso DESC, Id);
    UPDATE @L SET Neto = Neto + (@Base - (SELECT SUM(Neto) FROM @L)), Imp = Imp + (@TItbis - (SELECT SUM(Imp) FROM @L)), Serv = Serv + (@TServ - (SELECT SUM(Serv) FROM @L)) WHERE Id = @Mayor;
    UPDATE @L SET Tot = Neto + Imp + Serv, Tasa = CASE WHEN Neto > 0 AND Imp / Neto <= 1 THEN CAST(Imp / Neto AS DECIMAL(6,4)) ELSE 0 END;
    DECLARE @SNeto DECIMAL(14,2), @SImp DECIMAL(14,2), @SServ DECIMAL(14,2), @STot DECIMAL(14,2);
    SELECT @SNeto = SUM(Neto), @SImp = SUM(Imp), @SServ = SUM(Serv), @STot = SUM(Tot) FROM @L;
    IF EXISTS (SELECT 1 FROM @L WHERE Neto < 0 OR Imp < 0 OR Serv < 0) BEGIN SET @Problema = N'El reparto del documento da importes negativos en una linea'; RETURN; END

    -- Pagos (en una nota, lo devuelto por medio; sin pagos la nota queda como saldo a favor en el ERP).
    DECLARE @P TABLE (Id INT, Metodo VARCHAR(14), Aplicado DECIMAL(14,2), Entregado DECIMAL(14,2), Vuelto DECIMAL(14,2), Propina DECIMAL(14,2));
    IF EXISTS (SELECT 1 FROM dbo.FacturaFormaPago p WHERE p.Serie = @Serie AND p.Numero = @Numero AND NOT EXISTS (SELECT 1 FROM dbo.LetERP_FormaPago m WHERE m.IdFormaPago = p.IdFormaPago))
    BEGIN SET @Problema = N'Hay una forma de pago sin medio asignado para el ERP (LetERP_FormaPago)'; RETURN; END
    INSERT @P (Id, Metodo, Aplicado, Entregado, Vuelto, Propina)
    SELECT p.Id, m.Metodo,
           ROUND(ABS(ISNULL(p.TotalPagado, 0)) - ABS(ISNULL(p.TotalDevuelta, 0)), 2), ROUND(ABS(ISNULL(p.TotalPagado, 0)), 2), ROUND(ABS(ISNULL(p.TotalDevuelta, 0)), 2), ROUND(ABS(ISNULL(p.TotalPropina, 0)), 2)
      FROM dbo.FacturaFormaPago p JOIN dbo.LetERP_FormaPago m ON m.IdFormaPago = p.IdFormaPago
     WHERE p.Serie = @Serie AND p.Numero = @Numero;
    IF @Doc = 'F' AND ABS(ISNULL((SELECT SUM(Aplicado) FROM @P), 0) - @STot) > 0.05
    BEGIN SET @Problema = N'Lo cobrado (' + CONVERT(NVARCHAR(30), ISNULL((SELECT SUM(Aplicado) FROM @P), 0)) + N') no cuadra con el total de la venta (' + CONVERT(NVARCHAR(30), @STot) + N')'; RETURN; END
    IF EXISTS (SELECT 1 FROM @P WHERE Aplicado < 0 OR (Vuelto > 0 AND Metodo <> 'CASH')) BEGIN SET @Problema = N'Un pago tiene importes que el ERP no acepta (negativo o vuelto en un medio que no es efectivo)'; RETURN; END

    DECLARE @RncC VARCHAR(20), @NomC NVARCHAR(200);
    SELECT TOP (1) @RncC = REPLACE(REPLACE(LTRIM(RTRIM(RNC)), '-', ''), ' ', ''), @NomC = LEFT(RazonSocial, 200) FROM dbo.FacturaComprobanteFiscal WHERE Serie = @Serie AND Numero = @Numero;
    IF @RncC IS NOT NULL AND (LEN(@RncC) NOT IN (9, 11) OR @RncC LIKE '%[^0-9]%') SET @RncC = NULL;
    DECLARE @EstadoErp VARCHAR(12) = CASE WHEN @Estado IN ('ACEPTADO', 'ACEPTADO_COND', 'REGULARIZADO') THEN 'ACEPTADO' ELSE 'PENDIENTE' END;
    DECLARE @Reloj NVARCHAR(6) = @Offset;

    SET @Json = (
        SELECT 1 AS schema_version, @Sucursal AS branch_code, @Rnc AS issuer_rnc, @PosId AS pos_id, CONVERT(VARCHAR(10), @Dia, 23) AS business_day,
               CONVERT(VARCHAR(19), @Apertura, 126) + @Reloj AS shift_opened_at,
               @Serie AS [document.series], @Numero AS [document.number], CONVERT(VARCHAR(19), @Fecha, 126) + @Reloj AS [document.closed_at],
               LEFT(@Ubic, 80) AS [document.center],
               RIGHT('0' + CAST(@Tipo AS VARCHAR(3)), 2) AS [document.fiscal.type], @Encf AS [document.fiscal.ncf], @EstadoErp AS [document.fiscal.status],
               @RncC AS [document.fiscal.buyer_rnc], @NomC AS [document.fiscal.buyer_name],
               CASE WHEN @Doc = 'N' THEN @RefEncf END AS [document.fiscal.related_ncf],
               CASE WHEN @Doc = 'N' THEN N'Nota de credito emitida en Agora' END AS [document.fiscal.reason],
               JSON_QUERY((SELECT CAST(l.Id AS VARCHAR(20)) AS line_id, l.Nombre AS name, CONVERT(VARCHAR(20), l.Cant) AS qty,
                                  CONVERT(VARCHAR(20), l.Neto) AS net, CONVERT(VARCHAR(10), l.Tasa) AS tax_rate, CONVERT(VARCHAR(20), l.Imp) AS tax,
                                  CONVERT(VARCHAR(20), l.Serv) AS service_charge, CONVERT(VARCHAR(20), l.Dto) AS discount, CONVERT(VARCHAR(20), l.Tot) AS total
                             FROM @L l ORDER BY l.Id FOR JSON PATH)) AS lines,
               CONVERT(VARCHAR(20), @SNeto) AS [totals.net], CONVERT(VARCHAR(20), @SImp) AS [totals.tax], CONVERT(VARCHAR(20), @SServ) AS [totals.service_charge], CONVERT(VARCHAR(20), @STot) AS [totals.total],
               JSON_QUERY(ISNULL((SELECT CAST(p.Id AS VARCHAR(20)) AS payment_id, p.Metodo AS method, 'DOP' AS currency, CONVERT(VARCHAR(20), p.Aplicado) AS applied,
                                         CONVERT(VARCHAR(20), p.Entregado) AS tendered, CONVERT(VARCHAR(20), p.Vuelto) AS change_given, CONVERT(VARCHAR(20), p.Propina) AS tip
                                    FROM @P p ORDER BY p.Id FOR JSON PATH), '[]')) AS payments
        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
END
GO

-- Recorre los turnos CERRADOS desde @Desde y encola los eventos de los que estan completos y cuadran. Devuelve el resumen de lo que hizo.
IF OBJECT_ID(N'[dbo].[LetERPEncolar]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetERPEncolar] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetERPEncolar] (@Rnc VARCHAR(20), @Offset VARCHAR(6) = '-04:00', @Desde DATE = NULL, @MaxTurnos INT = 20, @Sucursal VARCHAR(20) = 'PRINCIPAL')
AS
BEGIN
    SET NOCOUNT ON;
    EXEC dbo.LetERPFormasSembrar;
    DECLARE @Encolados INT = 0, @Esperando INT = 0, @Revisar INT = 0;
    DECLARE @T TABLE (PosId INT, Apertura DATETIME, Cierre DATETIME, Dia DATE, CajaInicial DECIMAL(14,2), CajaEsperada DECIMAL(14,2));
    INSERT @T
    SELECT TOP (@MaxTurnos) p.PosId, p.OpenDate, p.CloseDate, CAST(p.BusinessDay AS DATE), p.CashInitialAmount, p.CashExpectedEndAmount
      FROM dbo.PosCloseOut p
     WHERE p.CloseDate IS NOT NULL AND p.OpenDate IS NOT NULL AND (@Desde IS NULL OR CAST(p.BusinessDay AS DATE) >= @Desde)
       AND NOT EXISTS (SELECT 1 FROM dbo.LetERP_Turno t WHERE t.PosId = p.PosId AND t.Turno = p.OpenDate AND t.Estado IN ('ENCOLADO', 'SIN_VENTAS'))
     ORDER BY p.CloseDate;

    DECLARE @PosId INT, @Apertura DATETIME, @Cierre DATETIME, @Dia DATE, @CajaIni DECIMAL(14,2), @CajaEsp DECIMAL(14,2);
    DECLARE tc CURSOR LOCAL FAST_FORWARD FOR SELECT PosId, Apertura, Cierre, Dia, CajaInicial, CajaEsperada FROM @T ORDER BY Cierre;
    OPEN tc;
    FETCH NEXT FROM tc INTO @PosId, @Apertura, @Cierre, @Dia, @CajaIni, @CajaEsp;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        DECLARE @Docs TABLE (Serie NVARCHAR(10), Numero INT, Documento CHAR(1), Estado VARCHAR(20));
        DELETE @Docs;
        -- Documentos del turno: las facturas de esa caja entre la apertura y el cierre (varias filas con el mismo numero cuentan una vez).
        INSERT @Docs (Serie, Numero, Documento, Estado)
        SELECT f.Serie, f.Numero, MAX(c.Documento), MAX(c.Estado)
          FROM dbo.Factura f LEFT JOIN dbo.LetFE_Cola c ON c.Serie = f.Serie AND c.Numero = f.Numero
         WHERE f.PosId = @PosId AND f.Fecha >= @Apertura AND f.Fecha <= @Cierre
         GROUP BY f.Serie, f.Numero;

        DECLARE @Estado VARCHAR(12) = NULL, @Motivo NVARCHAR(500) = NULL, @N INT = (SELECT COUNT(*) FROM @Docs);
        IF @N = 0
        BEGIN
            MERGE dbo.LetERP_Turno AS t USING (SELECT @PosId AS PosId, @Apertura AS Turno) s ON t.PosId = s.PosId AND t.Turno = s.Turno
            WHEN MATCHED THEN UPDATE SET Estado = 'SIN_VENTAS', Motivo = NULL, Documentos = 0, Actualizado = GETDATE()
            WHEN NOT MATCHED THEN INSERT (PosId, Turno, Estado, Motivo, Documentos) VALUES (s.PosId, s.Turno, 'SIN_VENTAS', NULL, 0);
        END
        ELSE
        BEGIN
            IF EXISTS (SELECT 1 FROM @Docs WHERE Documento IS NULL)
            BEGIN SET @Estado = 'REVISAR'; SET @Motivo = CAST((SELECT COUNT(*) FROM @Docs WHERE Documento IS NULL) AS NVARCHAR(10)) + N' venta(s) del turno no pasaron por e-Fiscal (no estan en la cola); revise antes de enviar al ERP'; END
            ELSE IF EXISTS (SELECT 1 FROM @Docs WHERE Estado = 'DESCARTADO')
            BEGIN SET @Estado = 'REVISAR'; SET @Motivo = CAST((SELECT COUNT(*) FROM @Docs WHERE Estado = 'DESCARTADO') AS NVARCHAR(10)) + N' documento(s) descartado(s): decida con el contador como se registran antes de enviar el turno'; END
            ELSE IF EXISTS (SELECT 1 FROM @Docs WHERE Estado NOT IN ('ACEPTADO', 'ACEPTADO_COND', 'REGULARIZADO'))
            BEGIN SET @Estado = 'ESPERANDO'; SET @Motivo = CAST((SELECT COUNT(*) FROM @Docs WHERE Estado NOT IN ('ACEPTADO', 'ACEPTADO_COND', 'REGULARIZADO')) AS NVARCHAR(10)) + N' documento(s) sin aceptar por la DGII todavia'; END

            DECLARE @Ev TABLE (Orden INT IDENTITY(1,1), EventId NVARCHAR(120), Tipo VARCHAR(30), Payload NVARCHAR(MAX));
            DELETE @Ev;
            DECLARE @VentasTot DECIMAL(14,2) = 0, @NotasTot DECIMAL(14,2) = 0;
            IF @Estado IS NULL
            BEGIN
                DECLARE @Serie NVARCHAR(10), @Num INT, @Docu CHAR(1), @Json NVARCHAR(MAX), @Prob NVARCHAR(500), @Tot DECIMAL(14,2);
                DECLARE dc CURSOR LOCAL FAST_FORWARD FOR SELECT Serie, Numero, Documento FROM @Docs ORDER BY Serie, Numero;
                OPEN dc;
                FETCH NEXT FROM dc INTO @Serie, @Num, @Docu;
                WHILE @@FETCH_STATUS = 0
                BEGIN
                    EXEC dbo.LetERPDocumento @Serie, @Num, @Rnc, @Offset, @Dia, @Apertura, @Sucursal, @Json OUTPUT, @Prob OUTPUT;
                    IF @Json IS NULL
                    BEGIN SET @Estado = 'REVISAR'; SET @Motivo = LEFT(@Serie + N'-' + CAST(@Num AS NVARCHAR(10)) + N': ' + ISNULL(@Prob, N'no se pudo armar el documento'), 500); BREAK; END
                    SET @Tot = CAST(JSON_VALUE(@Json, '$.totals.total') AS DECIMAL(14,2));
                    IF @Docu = 'N' SET @NotasTot += @Tot ELSE SET @VentasTot += @Tot;
                    INSERT @Ev (EventId, Tipo, Payload)
                    VALUES (CASE WHEN @Docu = 'N' THEN N'nota:' ELSE N'venta:' END + @Sucursal + N':' + CAST(@PosId AS NVARCHAR(10)) + N':' + @Serie + N':' + CAST(@Num AS NVARCHAR(10)),
                            CASE WHEN @Docu = 'N' THEN 'nota.fiscalizada' ELSE 'venta.fiscalizada' END, @Json);
                    FETCH NEXT FROM dc INTO @Serie, @Num, @Docu;
                END
                CLOSE dc; DEALLOCATE dc;
            END

            IF @Estado IS NOT NULL
            BEGIN
                MERGE dbo.LetERP_Turno AS t USING (SELECT @PosId AS PosId, @Apertura AS Turno) s ON t.PosId = s.PosId AND t.Turno = s.Turno
                WHEN MATCHED THEN UPDATE SET Estado = @Estado, Motivo = @Motivo, Documentos = @N, Actualizado = GETDATE()
                WHEN NOT MATCHED THEN INSERT (PosId, Turno, Estado, Motivo, Documentos) VALUES (s.PosId, s.Turno, @Estado, @Motivo, @N);
                IF @Estado = 'ESPERANDO' SET @Esperando += 1 ELSE SET @Revisar += 1;
            END
            ELSE
            BEGIN
                -- Cierre del turno al final: declara cuantos documentos y que totales trae, para que el ERP sepa cuando esta completo.
                DECLARE @Cierre1 NVARCHAR(MAX) = (
                    SELECT 1 AS schema_version, @Sucursal AS branch_code, @Rnc AS issuer_rnc, @PosId AS pos_id, CONVERT(VARCHAR(10), @Dia, 23) AS business_day,
                           CONVERT(VARCHAR(19), @Apertura, 126) + @Offset AS shift_opened_at, CONVERT(VARCHAR(19), @Cierre, 126) + @Offset AS shift_closed_at,
                           CONVERT(VARCHAR(20), CAST(ISNULL(@CajaIni, 0) AS DECIMAL(14,2))) AS cash_initial, CONVERT(VARCHAR(20), CAST(ISNULL(@CajaEsp, 0) AS DECIMAL(14,2))) AS cash_expected,
                           @N AS [documents.count], CONVERT(VARCHAR(20), @VentasTot) AS [documents.sales_total], CONVERT(VARCHAR(20), @NotasTot) AS [documents.credit_notes_total]
                    FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
                INSERT @Ev (EventId, Tipo, Payload) VALUES (N'turno:' + @Sucursal + N':' + CAST(@PosId AS NVARCHAR(10)) + N':' + CONVERT(NVARCHAR(19), @Apertura, 126), 'turno.cerrado', @Cierre1);
                BEGIN TRAN;
                    INSERT dbo.LetERP_Cola (EventId, Tipo, PosId, Turno, Payload)
                    SELECT e.EventId, e.Tipo, @PosId, @Apertura, e.Payload FROM @Ev e
                     WHERE NOT EXISTS (SELECT 1 FROM dbo.LetERP_Cola q WHERE q.EventId = e.EventId) ORDER BY e.Orden;
                    MERGE dbo.LetERP_Turno AS t USING (SELECT @PosId AS PosId, @Apertura AS Turno) s ON t.PosId = s.PosId AND t.Turno = s.Turno
                    WHEN MATCHED THEN UPDATE SET Estado = 'ENCOLADO', Motivo = NULL, Documentos = @N, Actualizado = GETDATE()
                    WHEN NOT MATCHED THEN INSERT (PosId, Turno, Estado, Motivo, Documentos) VALUES (s.PosId, s.Turno, 'ENCOLADO', NULL, @N);
                COMMIT;
                SET @Encolados += 1;
            END
        END
        FETCH NEXT FROM tc INTO @PosId, @Apertura, @Cierre, @Dia, @CajaIni, @CajaEsp;
    END
    CLOSE tc; DEALLOCATE tc;
    SELECT @Encolados AS Encolados, @Esperando AS Esperando, @Revisar AS Revisar;
END
GO

-- Eventos por enviar (los mas viejos primero; un error definitivo no bloquea a los demas).
IF OBJECT_ID(N'[dbo].[LetERPPendientes]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetERPPendientes] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetERPPendientes] (@Max INT = 20)
AS
BEGIN
    SET NOCOUNT ON;
    SELECT TOP (@Max) Id, EventId, Tipo, Payload, Intentos
      FROM dbo.LetERP_Cola WHERE Estado = 'PENDIENTE' AND ProximoIntento <= GETDATE() ORDER BY Id;
END
GO

-- Resultado de un envio. ENVIADO: listo. PENDIENTE: se reintenta con espera creciente. ERROR: necesita a una persona (el ERP rechazo el contenido); «Reintentar» lo vuelve a PENDIENTE.
IF OBJECT_ID(N'[dbo].[LetERPResultado]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetERPResultado] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetERPResultado] (@Id INT, @Estado VARCHAR(12), @Error NVARCHAR(500) = NULL)
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE dbo.LetERP_Cola
       SET Estado = @Estado, Intentos = Intentos + 1, UltimoError = CASE WHEN @Estado = 'ENVIADO' THEN NULL ELSE LEFT(@Error, 500) END,
           Enviado = CASE WHEN @Estado = 'ENVIADO' THEN GETDATE() ELSE Enviado END,
           ProximoIntento = CASE WHEN @Estado = 'PENDIENTE' THEN DATEADD(SECOND, CASE WHEN Intentos >= 8 THEN 900 ELSE POWER(2, Intentos + 2) * 5 END, GETDATE()) ELSE ProximoIntento END
     WHERE Id = @Id;
END
GO

-- Resumen para el reporte y el panel de salud.
IF OBJECT_ID(N'[dbo].[LetERPResumen]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetERPResumen] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetERPResumen]
AS
BEGIN
    SET NOCOUNT ON;
    SELECT (SELECT COUNT(*) FROM dbo.LetERP_Cola WHERE Estado = 'PENDIENTE') AS Pendientes,
           (SELECT COUNT(*) FROM dbo.LetERP_Cola WHERE Estado = 'ERROR') AS Errores,
           (SELECT COUNT(*) FROM dbo.LetERP_Cola WHERE Estado = 'ENVIADO') AS Enviados,
           (SELECT COUNT(*) FROM dbo.LetERP_Turno WHERE Estado = 'ESPERANDO') AS TurnosEsperando,
           (SELECT COUNT(*) FROM dbo.LetERP_Turno WHERE Estado = 'REVISAR') AS TurnosPorRevisar;
    SELECT TOP (50) PosId, Turno, Estado, Motivo, Documentos FROM dbo.LetERP_Turno WHERE Estado IN ('ESPERANDO', 'REVISAR') ORDER BY Turno DESC;
END
GO
EXEC dbo.LetERPFormasSembrar
GO
