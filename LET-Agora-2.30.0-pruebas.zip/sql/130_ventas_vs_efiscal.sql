-- 130_ventas_vs_efiscal.sql
-- Reporte "Ventas vs e-Fiscal Cloud" del portal (/ventas-efiscal): todas las ventas y notas de credito de Agora en un rango de fechas, cuales pasaron a e-Fiscal Cloud y
-- cuales no, y cuales son operaciones internas de tipo F (dbo.LetOperacionInterna). Idempotente.
-- Codigo de resultado: 1 enviada y aceptada, 2 enviada con problema o sin respuesta, 3 interna tipo F pendiente de fiscalizar (no enviada), 4 descartada a proposito,
--                      5 venta electronica que no esta en la cola de envio, 6 comprobante tradicional (B...) de antes de e-Fiscal, 7 sin comprobante fiscal.
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID(N'[dbo].[LetFEVentasVsEfiscal]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetFEVentasVsEfiscal] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetFEVentasVsEfiscal] (@Desde DATE = NULL, @Hasta DATE = NULL, @Resultado INT = NULL, @SoloF BIT = 0, @Texto NVARCHAR(40) = NULL, @Max INT = 500)
AS
BEGIN
    SET NOCOUNT ON;
    SET @Hasta = ISNULL(@Hasta, CAST(GETDATE() AS DATE));
    SET @Desde = ISNULL(@Desde, @Hasta);
    SET @Texto = NULLIF(LTRIM(RTRIM(@Texto)), N'');
    SET @Max = CASE WHEN @Max IS NULL OR @Max < 1 THEN 500 WHEN @Max > 100000 THEN 100000 ELSE @Max END;

    SELECT f.Serie, f.Numero, f.Fecha, f.TotalNeto AS TotalAgora, f.Usuario, f.PosId,
           fc.Tipo AS TipoAgora, fc.NCF AS NcfAgora, fc.RNC, fc.RazonSocial,
           q.Id AS ColaId, q.ClientUuid, q.Encf, q.Estado AS EstadoEfiscal, q.EstadoDgii, q.TotalEnviado, q.TotalAgora AS TotalAgoraCola, q.UltimoError,
           o.Referencia AS ReferenciaF, o.EstadoFiscal AS EstadoFiscalF,
           CAST(CASE WHEN o.Id IS NOT NULL THEN 1 ELSE 0 END AS BIT) AS EsF,
           CAST(CASE WHEN f.TotalNeto < 0 THEN 1 ELSE 0 END AS BIT) AS EsNota,
           CAST(CASE
                  WHEN q.Id IS NOT NULL AND q.Estado IN ('ACEPTADO', 'ACEPTADO_COND', 'REGULARIZADO') THEN 1
                  WHEN q.Id IS NOT NULL AND q.Estado = 'DIFERIDO' THEN 3
                  WHEN q.Id IS NOT NULL AND q.Estado = 'DESCARTADO' THEN 4
                  WHEN q.Id IS NOT NULL THEN 2
                  WHEN fc.NCF LIKE 'B%' THEN 6
                  WHEN fc.Tipo IS NOT NULL AND dbo.LetFETipoEcf(fc.Tipo) IS NOT NULL THEN 5
                  ELSE 7 END AS INT) AS Codigo
      INTO #v
      FROM dbo.Factura f
      OUTER APPLY (SELECT TOP (1) c.Tipo, c.NCF, c.RNC, c.RazonSocial FROM dbo.FacturaComprobanteFiscal c WHERE c.Serie = f.Serie AND c.Numero = f.Numero ORDER BY c.Id) fc
      OUTER APPLY (SELECT TOP (1) x.Id, x.ClientUuid, x.Encf, x.Estado, x.EstadoDgii, x.TotalEnviado, x.TotalAgora, x.UltimoError FROM dbo.LetFE_Cola x WHERE x.Serie = f.Serie AND x.Numero = f.Numero ORDER BY x.Id DESC) q
      OUTER APPLY (SELECT TOP (1) i.Id, i.Referencia, i.EstadoFiscal FROM dbo.LetOperacionInterna i WHERE i.Serie = f.Serie AND i.Numero = f.Numero ORDER BY i.Id) o
     WHERE f.Fecha >= @Desde AND f.Fecha < DATEADD(DAY, 1, @Hasta);

    -- 1. Resumen por resultado (de todo el rango).
    SELECT Codigo, COUNT(*) AS Documentos, SUM(TotalAgora) AS Total FROM #v GROUP BY Codigo ORDER BY Codigo;

    -- 2. Tipo F (operaciones internas): cuantas son, cuanto suman y cuantas siguen pendientes de fiscalizar.
    SELECT COUNT(*) AS Documentos, ISNULL(SUM(TotalAgora), 0) AS Total, ISNULL(SUM(CASE WHEN Codigo = 3 THEN 1 ELSE 0 END), 0) AS Pendientes,
           ISNULL(SUM(CASE WHEN Codigo = 1 THEN 1 ELSE 0 END), 0) AS Fiscalizadas
      FROM #v WHERE EsF = 1;

    -- 3. Detalle (filtrado). Con @Max = 100000 sirve para la descarga completa.
    SELECT TOP (@Max) Serie, Numero, Fecha, TotalAgora, Usuario, PosId, TipoAgora, NcfAgora, RNC, RazonSocial, ClientUuid, Encf, EstadoEfiscal, EstadoDgii, TotalEnviado, UltimoError,
           ReferenciaF, EstadoFiscalF, EsF, EsNota, Codigo,
           CAST(CASE WHEN ColaId IS NOT NULL AND ABS(ISNULL(TotalAgoraCola, 0) - ISNULL(TotalEnviado, 0)) >= 0.01 THEN 1 ELSE 0 END AS BIT) AS TotalDistinto
      FROM #v
     WHERE (@Resultado IS NULL OR Codigo = @Resultado)
       AND (@SoloF = 0 OR EsF = 1)
       AND (@Texto IS NULL OR Serie + N'-' + CONVERT(NVARCHAR(12), Numero) LIKE N'%' + @Texto + N'%' OR CONVERT(NVARCHAR(12), Numero) = @Texto
            OR NcfAgora LIKE N'%' + @Texto + N'%' OR Encf LIKE N'%' + @Texto + N'%' OR RNC LIKE N'%' + @Texto + N'%' OR RazonSocial LIKE N'%' + @Texto + N'%'
            OR ReferenciaF LIKE N'%' + @Texto + N'%')
     ORDER BY Fecha DESC, Serie, Numero DESC;

    -- 4. Fecha de la primera venta (para el boton "desde el inicio").
    SELECT CAST(MIN(Fecha) AS DATE) AS Primera FROM dbo.Factura;
END
GO
