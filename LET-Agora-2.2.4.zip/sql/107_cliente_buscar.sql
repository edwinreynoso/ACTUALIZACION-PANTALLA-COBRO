-- 107_cliente_buscar.sql
-- dbo.LetClienteBuscar(@Texto): busca un cliente en la tabla de clientes de Agora (dbo.Customer) por nombre, nombre comercial, RNC o cedula (Cif) o codigo de cuenta.
-- Sin texto devuelve los primeros clientes de Agora. Si el texto son numeros (3 o mas) tambien mira el padron de la DGII por el comienzo del RNC (tiene indice,
-- IX_DGII_RNC_RNC de 102); por nombre NO recorre el padron: tarda decenas de segundos.
-- Devuelve hasta 20 filas: Origen (Agora o DGII), Rnc (vacio si el cliente de Agora no tiene) y Nombre. Alimenta el buscador de la pagina "Clientes y formas de pago".
-- Solo lee. Sin variables del instalador.
SET NOCOUNT ON;
GO
IF OBJECT_ID(N'[dbo].[LetClienteBuscar]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetClienteBuscar] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetClienteBuscar] (@Texto NVARCHAR(100) = NULL)
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @t NVARCHAR(100) = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(@Texto, N''), N'%', N''), N'_', N''), N'[', N''), N']', N'')));
    DECLARE @num NVARCHAR(100) = REPLACE(REPLACE(@t, N'-', N''), N' ', N'');
    DECLARE @esNumero BIT = CASE WHEN LEN(@num) > 0 AND @num NOT LIKE N'%[^0-9]%' THEN 1 ELSE 0 END;
    CREATE TABLE #r (Orden INT IDENTITY(1,1), Origen NVARCHAR(10), Rnc VARCHAR(20), Nombre NVARCHAR(200));

    -- clientes de Agora
    IF OBJECT_ID(N'dbo.Customer', N'U') IS NOT NULL
        INSERT #r (Origen, Rnc, Nombre)
        SELECT TOP (20) N'Agora', LEFT(REPLACE(ISNULL(c.Cif, N''), N'-', N''), 20), LEFT(COALESCE(NULLIF(c.FiscalName, N''), c.BusinessName, N''), 200)
        FROM dbo.Customer c
        WHERE c.DeletionDate IS NULL
          AND (@t = N''
            OR c.FiscalName LIKE N'%' + @t + N'%' OR c.BusinessName LIKE N'%' + @t + N'%' OR c.AccountCode LIKE N'%' + @t + N'%'
            OR REPLACE(ISNULL(c.Cif, N''), N'-', N'') LIKE N'%' + @num + N'%' AND LEN(@num) >= 3)
        ORDER BY CASE WHEN ISNULL(c.Cif, N'') IN (N'', N'0') OR REPLACE(ISNULL(c.Cif, N''), N'0', N'') = N'' THEN 1 ELSE 0 END, c.FiscalName;

    -- padron de la DGII: solo por el comienzo del RNC o de la cedula (rapido, con indice)
    IF @esNumero = 1 AND LEN(@num) >= 3 AND OBJECT_ID(N'dbo.DGII_RNC', N'U') IS NOT NULL
        INSERT #r (Origen, Rnc, Nombre)
        SELECT TOP (10) N'DGII', p.RNC, LEFT(ISNULL(p.RAZONSOCIAL, N''), 200)
        FROM dbo.DGII_RNC p WHERE p.RNC LIKE CAST(@num AS VARCHAR(20)) + '%' ORDER BY p.RNC;

    -- si el mismo RNC esta en los dos origenes se queda el de Agora
    SELECT TOP (20) Origen, Rnc, Nombre
    FROM (SELECT Orden, Origen, Rnc, Nombre,
                 ROW_NUMBER() OVER (PARTITION BY CASE WHEN Rnc = '' THEN 'x' + CAST(Orden AS VARCHAR(10)) ELSE Rnc END ORDER BY CASE Origen WHEN N'Agora' THEN 0 ELSE 1 END, Orden) AS n
          FROM #r) x
    WHERE n = 1
    ORDER BY CASE Origen WHEN N'Agora' THEN 0 ELSE 1 END, Orden;
END
GO
