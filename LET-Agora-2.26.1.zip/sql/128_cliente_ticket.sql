-- 128: cliente asignado a una cuenta desde la pantalla de cobro (Cobro rapido o Cobrar ticket).
-- Lo guarda la pantalla, no el POS de Agora: sirve para aplicar las reglas del cliente (forma de pago asignada) y llevar su RNC y datos a la factura.
-- Idempotente: se puede aplicar mas de una vez.
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'dbo.LetClienteTicket') IS NULL
BEGIN
    CREATE TABLE dbo.LetClienteTicket (
        TicketGlobalId UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_LetClienteTicket PRIMARY KEY,
        Rnc            NVARCHAR(30)  NOT NULL,
        Nombre         NVARCHAR(200) NULL,
        Correo         NVARCHAR(200) NULL,
        Telefono       NVARCHAR(50)  NULL,
        Actualizado    DATETIME      NOT NULL CONSTRAINT DF_LetClienteTicket_Act DEFAULT (GETDATE())
    )
END
GO
