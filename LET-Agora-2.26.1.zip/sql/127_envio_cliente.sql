-- 127: envio al cliente de la factura firmada por e-Fiscal Cloud (correo ahora; el WhatsApp solo se guarda).
-- Cuando una factura que no es de consumo sale en contingencia, el cajero deja el correo o el WhatsApp del cliente:
-- el servicio de impresion envia el correo cuando e-Fiscal Cloud firma el comprobante.
-- Idempotente: se puede aplicar mas de una vez.
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'dbo.LetFEEnvioCliente') IS NULL
BEGIN
    CREATE TABLE dbo.LetFEEnvioCliente (
        Id          INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_LetFEEnvioCliente PRIMARY KEY,
        PosTicketId NVARCHAR(40)  NOT NULL,                      -- el mismo valor que dbo.LetFE_Cola.PosTicketId
        Correo      NVARCHAR(200) NULL,
        Whatsapp    NVARCHAR(40)  NULL,                          -- solo se guarda: el envio por WhatsApp se configura despues
        Estado      VARCHAR(20)   NOT NULL CONSTRAINT DF_LetFEEnvioCliente_Estado DEFAULT ('PENDIENTE'),   -- PENDIENTE, ENVIADO, ERROR, SIN_CORREO
        Intentos    INT           NOT NULL CONSTRAINT DF_LetFEEnvioCliente_Intentos DEFAULT (0),
        UltimoError NVARCHAR(500) NULL,
        Creado      DATETIME      NOT NULL CONSTRAINT DF_LetFEEnvioCliente_Creado DEFAULT (GETDATE()),
        Actualizado DATETIME      NOT NULL CONSTRAINT DF_LetFEEnvioCliente_Act DEFAULT (GETDATE()),
        Enviado     DATETIME      NULL,
        CONSTRAINT UQ_LetFEEnvioCliente_Ticket UNIQUE (PosTicketId)
    )
END
GO
CREATE OR ALTER PROCEDURE dbo.LetFEEnvioClienteRegistrar
    @PosTicketId NVARCHAR(40), @Correo NVARCHAR(200) = NULL, @Whatsapp NVARCHAR(40) = NULL
AS
BEGIN
    SET NOCOUNT ON
    SET @Correo = NULLIF(LTRIM(RTRIM(@Correo)), N'')
    SET @Whatsapp = NULLIF(LTRIM(RTRIM(@Whatsapp)), N'')
    IF NULLIF(LTRIM(RTRIM(@PosTicketId)), N'') IS NULL RETURN
    IF @Correo IS NULL AND @Whatsapp IS NULL
    BEGIN
        DELETE dbo.LetFEEnvioCliente WHERE PosTicketId = @PosTicketId AND Estado <> 'ENVIADO'
        RETURN
    END
    IF EXISTS (SELECT 1 FROM dbo.LetFEEnvioCliente WHERE PosTicketId = @PosTicketId)
        UPDATE dbo.LetFEEnvioCliente
           SET Correo = @Correo, Whatsapp = @Whatsapp,
               Estado = CASE WHEN @Correo IS NULL THEN 'SIN_CORREO' WHEN Estado = 'ENVIADO' AND Correo = @Correo THEN Estado ELSE 'PENDIENTE' END,
               Intentos = CASE WHEN Estado = 'ENVIADO' AND Correo = @Correo THEN Intentos ELSE 0 END,
               Actualizado = GETDATE()
         WHERE PosTicketId = @PosTicketId
    ELSE
        INSERT dbo.LetFEEnvioCliente (PosTicketId, Correo, Whatsapp, Estado)
        VALUES (@PosTicketId, @Correo, @Whatsapp, CASE WHEN @Correo IS NULL THEN 'SIN_CORREO' ELSE 'PENDIENTE' END)
END
GO
-- Los que ya se pueden enviar: el comprobante tiene su e-NCF y la firma de e-Fiscal Cloud. Reintenta con espera creciente.
CREATE OR ALTER PROCEDURE dbo.LetFEEnvioClientePendientes
    @Maximo INT = 20, @MaxIntentos INT = 5
AS
BEGIN
    SET NOCOUNT ON
    SELECT TOP (@Maximo) e.Id, e.PosTicketId, e.Correo, e.Whatsapp, e.Intentos,
           q.Serie, q.Numero, q.TipoEcf, q.Encf, q.Fecha, q.TotalEnviado, q.CodigoSeguridad, q.FechaFirma, q.QrData, q.EstadoDgii
      FROM dbo.LetFEEnvioCliente e
      JOIN dbo.LetFE_Cola q ON q.PosTicketId = e.PosTicketId AND q.Documento = 'F'
     WHERE e.Estado IN ('PENDIENTE', 'ERROR') AND e.Correo IS NOT NULL AND e.Intentos < @MaxIntentos
       AND q.Encf IS NOT NULL AND q.FechaFirma IS NOT NULL AND q.Estado IN ('EMITIDO', 'ACEPTADO', 'ACEPTADO_COND')
       AND e.Actualizado <= DATEADD(MINUTE, -(e.Intentos * 5), GETDATE())
     ORDER BY e.Id
END
GO
CREATE OR ALTER PROCEDURE dbo.LetFEEnvioClienteResultado
    @Id INT, @Enviado BIT, @Error NVARCHAR(500) = NULL
AS
BEGIN
    SET NOCOUNT ON
    UPDATE dbo.LetFEEnvioCliente
       SET Estado = CASE WHEN @Enviado = 1 THEN 'ENVIADO' ELSE 'ERROR' END,
           Intentos = Intentos + 1, UltimoError = CASE WHEN @Enviado = 1 THEN NULL ELSE LEFT(@Error, 500) END,
           Enviado = CASE WHEN @Enviado = 1 THEN GETDATE() ELSE Enviado END, Actualizado = GETDATE()
     WHERE Id = @Id
END
GO
