﻿-- 132_erp_catalogo.sql
-- Catalogo ERP -> Agora (ADR-0019). El ERP es el maestro de los articulos que se venden en el punto de venta: este servicio baja del ERP los articulos marcados "Se vende en el punto de venta"
-- y los crea o actualiza en Agora (nombre, precio por lista, impuesto y baja logica), sin API de IGT, escribiendo directo en las tablas del catalogo de Agora.
-- Seguridad: apagado por omision; todo en UNA transaccion por articulo; solo las tablas Product, SaleFormat, SaleFormatPrice, ProductCategory, ProductDataSheet, CostPriceByWarehouse y StorageOptions;
-- un articulo nuevo se CLONA de un articulo plantilla (copia todas las columnas que Agora tenga, asi no depende de la lista exacta de columnas); se niega a escribir si la version de la base
-- de Agora (DBVersion) no esta en la lista de versiones probadas; con @Simular = 1 hace todo y deshace (ensayo). Idempotente. Compatible con el nivel 120 de la base (sin STRING_SPLIT).

IF OBJECT_ID(N'dbo.LetERP_Catalogo', N'U') IS NULL
CREATE TABLE dbo.LetERP_Catalogo (
    CodigoErp   NVARCHAR(40)  NOT NULL CONSTRAINT PK_LetERP_Catalogo PRIMARY KEY,   -- codigo del articulo en el ERP
    ProductoId  INT           NULL,                                                 -- Product.Id en Agora
    FormatoId   INT           NULL,                                                 -- SaleFormat.Id base
    Version     NVARCHAR(64)  NULL,                                                 -- ultima version del ERP aplicada
    Estado      VARCHAR(12)   NOT NULL CONSTRAINT DF_LetERP_Catalogo_Estado DEFAULT ('APLICADO'),   -- APLICADO | ERROR
    Informado   BIT           NOT NULL CONSTRAINT DF_LetERP_Catalogo_Inf DEFAULT (0),               -- el ERP ya sabe que id de Agora le toco
    Mensaje     NVARCHAR(500) NULL,
    Actualizado DATETIME      NOT NULL CONSTRAINT DF_LetERP_Catalogo_Act DEFAULT (GETDATE())
)
GO
IF OBJECT_ID(N'dbo.LetERP_CatalogoEstado', N'U') IS NULL
CREATE TABLE dbo.LetERP_CatalogoEstado (
    Clave VARCHAR(40)   NOT NULL CONSTRAINT PK_LetERP_CatalogoEstado PRIMARY KEY,
    Valor NVARCHAR(400) NULL
)
GO

-- Clona las filas de @Tabla donde @ColLlave = @Origen hacia @Destino, con TODAS las columnas que tenga la tabla salvo las identidad, calculadas y timestamp. Las columnas de #Sobre
-- (Col, Expr) cambian su valor por la expresion indicada; @ColLlave siempre toma @Destino. @Extra (opcional) es un filtro adicional de confianza interna (solo numeros). @Primera = 1 copia una sola fila.
-- Devuelve en @NuevoId el ultimo identity generado (si la tabla lo tiene). Requiere que el que llama cree la tabla temporal #Sobre.
IF OBJECT_ID(N'[dbo].[LetERPClonar]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetERPClonar] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetERPClonar]
    @Tabla SYSNAME, @ColLlave SYSNAME, @Origen INT, @Destino INT, @Extra NVARCHAR(200) = N'', @Primera BIT = 0, @NuevoId INT = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @cols NVARCHAR(MAX) = N'', @sel NVARCHAR(MAX) = N'', @sql NVARCHAR(MAX);
    SELECT @cols = @cols + N',' + QUOTENAME(c.name),
           @sel  = @sel  + N',' + CASE
                    WHEN c.name = @ColLlave THEN CAST(@Destino AS NVARCHAR(20))
                    WHEN o.Col IS NOT NULL THEN o.Expr
                    ELSE QUOTENAME(c.name) END
    FROM sys.columns c
    LEFT JOIN #Sobre o ON o.Col = c.name
    WHERE c.object_id = OBJECT_ID(@Tabla) AND c.is_identity = 0 AND c.is_computed = 0 AND c.system_type_id <> 189
    ORDER BY c.column_id;
    IF LEN(@cols) = 0 RAISERROR(N'No se encontro la tabla %s.', 16, 1, @Tabla);
    SET @cols = STUFF(@cols, 1, 1, N''); SET @sel = STUFF(@sel, 1, 1, N'');
    SET @sql = N'INSERT ' + @Tabla + N' (' + @cols + N') SELECT ' + CASE WHEN @Primera = 1 THEN N'TOP (1) ' ELSE N'' END + @sel + N' FROM ' + @Tabla + N' WHERE ' + QUOTENAME(@ColLlave) + N' = ' + CAST(@Origen AS NVARCHAR(20))
             + CASE WHEN LEN(@Extra) > 0 THEN N' AND ' + @Extra ELSE N'' END + N'; SET @nid = SCOPE_IDENTITY();';
    EXEC sp_executesql @sql, N'@nid INT OUTPUT', @nid = @NuevoId OUTPUT;
END
GO

-- Aplica UN articulo del ERP. Devuelve una fila: Resultado (CREADO, ACTUALIZADO, VINCULADO, SIN_CAMBIOS, OMITIDO, ERROR; con prefijo SIMULADO_ si @Simular = 1), ProductoId, FormatoId y Mensaje.
-- @Activo = 0 da de baja el articulo en Agora (borrado logico: las ventas pasadas siguen intactas). @VatId (nulo = deja el de la plantilla o el que ya tiene).
-- @Listas: ids de PriceList separados por coma; vacio = todas las no borradas. @VersionesBd: versiones mayores de DBVersion probadas (p. ej. '880'); vacio = no verifica.
IF OBJECT_ID(N'[dbo].[LetERPCatalogoAplicar]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetERPCatalogoAplicar] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetERPCatalogoAplicar]
    @Codigo NVARCHAR(40), @Nombre NVARCHAR(240), @Precio DECIMAL(12,3), @Activo BIT, @VatId INT = NULL, @Plantilla INT,
    @Listas VARCHAR(200) = '', @Version NVARCHAR(64), @Simular BIT = 1, @VersionesBd VARCHAR(100) = '', @Crear BIT = 1
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    DECLARE @pid INT, @fid INT, @prev NVARCHAR(64), @res VARCHAR(16), @msg NVARCHAR(500) = N'', @plu NVARCHAR(28), @nuevo BIT = 0;
    DECLARE @L TABLE (Id INT PRIMARY KEY);
    BEGIN TRY
        SET @Codigo = LTRIM(RTRIM(@Codigo)); SET @Nombre = LTRIM(RTRIM(@Nombre));
        IF LEN(@Codigo) = 0 OR LEN(@Nombre) = 0 RAISERROR(N'El articulo no trae codigo o nombre.', 16, 1);
        IF @Precio IS NULL OR @Precio < 0 RAISERROR(N'El precio no es valido.', 16, 1);

        -- 1) Version de la base de Agora: solo se escribe en versiones probadas.
        IF LEN(@VersionesBd) > 0
        BEGIN
            DECLARE @v VARCHAR(40) = (SELECT TOP 1 [version] FROM dbo.DBVersion);
            IF @v IS NULL OR CHARINDEX(',' + LEFT(@v, CHARINDEX('.', @v + '.') - 1) + ',', ',' + REPLACE(@VersionesBd, ' ', '') + ',') = 0
                RAISERROR(N'La base de Agora es la version %s y no esta entre las probadas (%s): no se escribe.', 16, 1, @v, @VersionesBd);
        END

        -- 2) Listas de precios destino.
        IF LEN(@Listas) > 0
        BEGIN
            DECLARE @resto VARCHAR(200) = @Listas + ',', @i INT, @t VARCHAR(20);
            WHILE LEN(@resto) > 0
            BEGIN
                SET @i = CHARINDEX(',', @resto); SET @t = LTRIM(RTRIM(LEFT(@resto, @i - 1))); SET @resto = SUBSTRING(@resto, @i + 1, 200);
                IF LEN(@t) > 0
                BEGIN
                    IF ISNUMERIC(@t) = 0 OR @t LIKE '%[^0-9]%' RAISERROR(N'La lista de precios "%s" no es un numero.', 16, 1, @t);
                    INSERT @L (Id) SELECT p.Id FROM dbo.PriceList p WHERE p.Id = CAST(@t AS INT) AND p.DeletionDate IS NULL AND NOT EXISTS (SELECT 1 FROM @L x WHERE x.Id = p.Id);
                END
            END
            IF NOT EXISTS (SELECT 1 FROM @L) RAISERROR(N'Ninguna de las listas de precios indicadas existe en Agora.', 16, 1);
        END
        ELSE INSERT @L (Id) SELECT Id FROM dbo.PriceList WHERE DeletionDate IS NULL;
        IF NOT EXISTS (SELECT 1 FROM @L) RAISERROR(N'Agora no tiene listas de precios.', 16, 1);

        -- 3) Lo que ya conocemos de este articulo.
        SELECT @pid = ProductoId, @fid = FormatoId, @prev = Version FROM dbo.LetERP_Catalogo WHERE CodigoErp = @Codigo;
        IF @pid IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.Product WHERE Id = @pid) BEGIN SET @pid = NULL; SET @fid = NULL; SET @prev = NULL; END
        IF @pid IS NOT NULL AND @prev = @Version AND @Simular = 0
        BEGIN
            SELECT 'SIN_CAMBIOS' AS Resultado, @pid AS ProductoId, @fid AS FormatoId, CAST(NULL AS NVARCHAR(500)) AS Mensaje;
            RETURN;
        END

        -- Un articulo que ya no se vende en el punto de venta y que Agora no conoce no se crea (ni se vincula por PLU): @Crear = 0.
        IF @pid IS NULL AND @Crear = 0
        BEGIN
            SELECT 'OMITIDO' AS Resultado, CAST(NULL AS INT) AS ProductoId, CAST(NULL AS INT) AS FormatoId, CAST(NULL AS NVARCHAR(500)) AS Mensaje;
            RETURN;
        END

        SET @plu = CASE WHEN LEN(@Codigo) <= 28 THEN @Codigo ELSE N'' END;
        CREATE TABLE #Sobre (Col SYSNAME COLLATE DATABASE_DEFAULT NOT NULL, Expr NVARCHAR(600) COLLATE DATABASE_DEFAULT NOT NULL);   -- la base de Agora no usa la collation de tempdb
        BEGIN TRAN;

        IF @pid IS NULL
        BEGIN
            -- 4a) Ya existe en Agora un articulo con ese PLU? Se vincula en vez de duplicarlo.
            IF LEN(@plu) > 0 SELECT TOP 1 @pid = Id FROM dbo.Product WHERE PriceLookUpCode = @plu AND DeletionDate IS NULL ORDER BY Id;
            IF @pid IS NOT NULL
            BEGIN
                SELECT TOP 1 @fid = Id FROM dbo.SaleFormat WHERE ProductId = @pid AND DeletionDate IS NULL ORDER BY IsBase DESC, Id;
                IF @fid IS NULL RAISERROR(N'El articulo %s ya existe en Agora pero no tiene formato de venta.', 16, 1, @plu);
                SET @res = 'VINCULADO'; SET @msg = N'Ya existia en Agora con ese PLU: se vincula y se actualiza.';
            END
            ELSE
            BEGIN
                -- 4b) Articulo nuevo: se clona de la plantilla.
                IF NOT EXISTS (SELECT 1 FROM dbo.Product WHERE Id = @Plantilla AND DeletionDate IS NULL) RAISERROR(N'El articulo plantilla %d no existe o esta borrado.', 16, 1, @Plantilla);
                DECLARE @tfid INT = (SELECT TOP 1 Id FROM dbo.SaleFormat WHERE ProductId = @Plantilla AND DeletionDate IS NULL ORDER BY IsBase DESC, Id);
                IF @tfid IS NULL RAISERROR(N'El articulo plantilla %d no tiene formato de venta.', 16, 1, @Plantilla);
                DECLARE @lit NVARCHAR(600) = N'N''' + REPLACE(@Nombre, N'''', N'''''') + N'''';
                DECLARE @pluLit NVARCHAR(100) = N'N''' + REPLACE(@plu, N'''', N'''''') + N'''';
                INSERT #Sobre VALUES (N'Name', @lit), (N'PriceLookUpCode', @pluLit), (N'DeletionDate', N'NULL'), (N'AvgCostPrice', N'0'), (N'BarcodeSummary', N'N''''');
                IF @VatId IS NOT NULL INSERT #Sobre VALUES (N'VatId', CAST(@VatId AS NVARCHAR(20)));
                EXEC dbo.LetERPClonar @Tabla = N'dbo.Product', @ColLlave = N'Id', @Origen = @Plantilla, @Destino = 0, @NuevoId = @pid OUTPUT;
                IF @pid IS NULL RAISERROR(N'No se pudo crear el articulo.', 16, 1);
                -- Product.Id es identity: la llave no se copia; las tablas hijas apuntan al id nuevo.
                DELETE #Sobre;
                INSERT #Sobre VALUES (N'Name', @lit), (N'DeletionDate', N'NULL');
                EXEC dbo.LetERPClonar @Tabla = N'dbo.SaleFormat', @ColLlave = N'ProductId', @Origen = @Plantilla, @Destino = @pid, @Extra = N'DeletionDate IS NULL', @Primera = 1, @NuevoId = @fid OUTPUT;
                IF @fid IS NULL RAISERROR(N'No se pudo crear el formato de venta.', 16, 1);
                DELETE #Sobre;
                EXEC dbo.LetERPClonar @Tabla = N'dbo.ProductCategory',   @ColLlave = N'ProductId', @Origen = @Plantilla, @Destino = @pid;
                EXEC dbo.LetERPClonar @Tabla = N'dbo.ProductDataSheet',  @ColLlave = N'ProductId', @Origen = @Plantilla, @Destino = @pid;
                INSERT #Sobre VALUES (N'CostPrice', N'0');
                EXEC dbo.LetERPClonar @Tabla = N'dbo.CostPriceByWarehouse', @ColLlave = N'ProductId', @Origen = @Plantilla, @Destino = @pid;
                DELETE #Sobre;
                EXEC dbo.LetERPClonar @Tabla = N'dbo.StorageOptions',    @ColLlave = N'ProductId', @Origen = @Plantilla, @Destino = @pid;
                SET @res = 'CREADO'; SET @nuevo = 1; SET @msg = N'Creado a partir del articulo plantilla ' + CAST(@Plantilla AS NVARCHAR(20)) + N'.';
            END
        END
        ELSE SET @res = 'ACTUALIZADO';

        DECLARE @fnom NVARCHAR(240) = (SELECT Name FROM dbo.SaleFormat WHERE Id = @fid);   -- nombre anterior del formato (para renombrar sus textos solo si seguian iguales)
        -- 5) Nombre, impuesto y baja logica (en articulos que ya existian; en los nuevos ya van en la copia).
        IF @nuevo = 0
        BEGIN
            UPDATE dbo.Product SET Name = @Nombre, VatId = COALESCE(@VatId, VatId),
                   DeletionDate = CASE WHEN @Activo = 1 THEN NULL ELSE COALESCE(DeletionDate, GETDATE()) END
            WHERE Id = @pid;
            UPDATE dbo.SaleFormat SET Name = @Nombre, DeletionDate = CASE WHEN @Activo = 1 THEN NULL ELSE COALESCE(DeletionDate, GETDATE()) END WHERE Id = @fid;
        END
        ELSE IF @Activo = 0
        BEGIN
            UPDATE dbo.Product SET DeletionDate = GETDATE() WHERE Id = @pid;
            UPDATE dbo.SaleFormat SET DeletionDate = GETDATE() WHERE Id = @fid;
        END

        -- 5b) Textos del formato (ticket, comanda y boton): Agora los guarda igual que el nombre; al clonar la plantilla traian el de ella. Nuevo: siempre; existente: solo si seguian iguales al nombre anterior.
        UPDATE dbo.SaleFormat SET
            DocumentText    = CASE WHEN @nuevo = 1 OR DocumentText    = @fnom THEN LEFT(@Nombre, 120) ELSE DocumentText    END,
            PreparationText = CASE WHEN @nuevo = 1 OR PreparationText = @fnom THEN LEFT(@Nombre, 120) ELSE PreparationText END,
            StyleText       = CASE WHEN @nuevo = 1 OR StyleText       = @fnom THEN LEFT(@Nombre, 100) ELSE StyleText       END
        WHERE Id = @fid;

        -- 6) Precio por lista.
        DECLARE @antes NVARCHAR(200) = N'', @lid INT, @main DECIMAL(12,3), @srcFmt INT;
        SELECT TOP 1 @srcFmt = f.Id FROM dbo.SaleFormat f WHERE f.ProductId = @Plantilla AND f.DeletionDate IS NULL ORDER BY f.IsBase DESC, f.Id;
        DECLARE cur CURSOR LOCAL FAST_FORWARD FOR SELECT Id FROM @L ORDER BY Id;
        OPEN cur; FETCH NEXT FROM cur INTO @lid;
        WHILE @@FETCH_STATUS = 0
        BEGIN
            SET @main = (SELECT TOP 1 Main FROM dbo.SaleFormatPrice WHERE SaleFormatId = @fid AND PriceListId = @lid);
            IF EXISTS (SELECT 1 FROM dbo.SaleFormatPrice WHERE SaleFormatId = @fid AND PriceListId = @lid)
            BEGIN
                IF @main IS NULL OR @main <> @Precio OR (@VatId IS NOT NULL AND EXISTS (SELECT 1 FROM dbo.SaleFormatPrice WHERE SaleFormatId = @fid AND PriceListId = @lid AND COALESCE(SpecificVatId, -1) <> @VatId))
                BEGIN
                    UPDATE dbo.SaleFormatPrice SET Main = @Precio, UpdatedAt = GETDATE(), SpecificVatId = COALESCE(@VatId, SpecificVatId) WHERE SaleFormatId = @fid AND PriceListId = @lid;
                    IF @main IS NOT NULL AND @main <> @Precio SET @antes = @antes + N' lista ' + CAST(@lid AS NVARCHAR(10)) + N': ' + CAST(@main AS NVARCHAR(30)) + N' -> ' + CAST(@Precio AS NVARCHAR(30)) + N';';
                END
            END
            ELSE
            BEGIN
                -- La lista aun no tiene precio para este formato: se copia una fila de precios (de la plantilla si tiene para esa lista, si no de cualquiera) y se pone el del ERP.
                DELETE #Sobre;
                INSERT #Sobre VALUES (N'PriceListId', CAST(@lid AS NVARCHAR(20))), (N'Main', CAST(@Precio AS NVARCHAR(30))), (N'UpdatedAt', N'GETDATE()');
                IF @VatId IS NOT NULL INSERT #Sobre VALUES (N'SpecificVatId', CAST(@VatId AS NVARCHAR(20)));
                DECLARE @src INT = NULL, @ext NVARCHAR(200) = N'PriceListId = ' + CAST(@lid AS NVARCHAR(20));
                IF @srcFmt IS NOT NULL AND EXISTS (SELECT 1 FROM dbo.SaleFormatPrice WHERE SaleFormatId = @srcFmt AND PriceListId = @lid) SET @src = @srcFmt;
                ELSE IF @srcFmt IS NOT NULL AND EXISTS (SELECT 1 FROM dbo.SaleFormatPrice WHERE SaleFormatId = @srcFmt) BEGIN SET @src = @srcFmt; SET @ext = N''; END
                ELSE BEGIN SET @src = (SELECT TOP 1 SaleFormatId FROM dbo.SaleFormatPrice WHERE SaleFormatId <> @fid ORDER BY UpdatedAt DESC); SET @ext = N''; END
                IF @src IS NULL RAISERROR(N'No hay ninguna fila de precios de Agora que copiar.', 16, 1);
                EXEC dbo.LetERPClonar @Tabla = N'dbo.SaleFormatPrice', @ColLlave = N'SaleFormatId', @Origen = @src, @Destino = @fid, @Extra = @ext, @Primera = 1;
                IF NOT EXISTS (SELECT 1 FROM dbo.SaleFormatPrice WHERE SaleFormatId = @fid AND PriceListId = @lid) RAISERROR(N'No se pudo crear el precio de la lista %d.', 16, 1, @lid);
            END
            FETCH NEXT FROM cur INTO @lid;
        END
        CLOSE cur; DEALLOCATE cur;

        IF LEN(@antes) > 0 SET @msg = LTRIM(@msg + N' Precio anterior en Agora:' + @antes);

        IF @Simular = 1
        BEGIN
            ROLLBACK;
            DROP TABLE #Sobre;
            SELECT 'SIMULADO_' + @res AS Resultado, @pid AS ProductoId, @fid AS FormatoId, @msg AS Mensaje;
            RETURN;
        END

        MERGE dbo.LetERP_Catalogo AS d USING (SELECT @Codigo AS CodigoErp) AS s ON d.CodigoErp = s.CodigoErp
        WHEN MATCHED THEN UPDATE SET ProductoId = @pid, FormatoId = @fid, Version = @Version, Estado = 'APLICADO', Mensaje = NULLIF(@msg, N''), Actualizado = GETDATE(),
                                     Informado = CASE WHEN @res IN ('CREADO', 'VINCULADO') OR d.ProductoId IS NULL OR d.ProductoId <> @pid THEN 0 ELSE d.Informado END
        WHEN NOT MATCHED THEN INSERT (CodigoErp, ProductoId, FormatoId, Version, Estado, Informado, Mensaje) VALUES (@Codigo, @pid, @fid, @Version, 'APLICADO', 0, NULLIF(@msg, N''));
        COMMIT;
        DROP TABLE #Sobre;
        SELECT @res AS Resultado, @pid AS ProductoId, @fid AS FormatoId, NULLIF(@msg, N'') AS Mensaje;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK;
        IF OBJECT_ID('tempdb..#Sobre') IS NOT NULL DROP TABLE #Sobre;
        DECLARE @err NVARCHAR(500) = LEFT(ERROR_MESSAGE(), 500);
        IF @Simular = 0 AND LEN(@Codigo) > 0
        BEGIN
            MERGE dbo.LetERP_Catalogo AS d USING (SELECT @Codigo AS CodigoErp) AS s ON d.CodigoErp = s.CodigoErp
            WHEN MATCHED THEN UPDATE SET Estado = 'ERROR', Mensaje = @err, Actualizado = GETDATE()
            WHEN NOT MATCHED THEN INSERT (CodigoErp, Estado, Mensaje) VALUES (@Codigo, 'ERROR', @err);
        END
        SELECT 'ERROR' AS Resultado, CAST(NULL AS INT) AS ProductoId, CAST(NULL AS INT) AS FormatoId, @err AS Mensaje;
    END CATCH
END
GO

-- Articulos aplicados cuyo id de Agora el ERP aun no conoce (para el evento catalogo.mapeado).
IF OBJECT_ID(N'[dbo].[LetERPCatalogoPorInformar]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetERPCatalogoPorInformar] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetERPCatalogoPorInformar] @Max INT = 100
AS
BEGIN
    SET NOCOUNT ON;
    SELECT TOP (@Max) c.CodigoErp, c.ProductoId, p.Name
    FROM dbo.LetERP_Catalogo c JOIN dbo.Product p ON p.Id = c.ProductoId
    WHERE c.Estado = 'APLICADO' AND c.Informado = 0 AND c.ProductoId IS NOT NULL
    ORDER BY c.Actualizado;
END
GO
IF OBJECT_ID(N'[dbo].[LetERPCatalogoInformado]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetERPCatalogoInformado] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetERPCatalogoInformado] @Codigo NVARCHAR(40)
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE dbo.LetERP_Catalogo SET Informado = 1 WHERE CodigoErp = @Codigo;
END
GO
-- Resumen para el portal.
IF OBJECT_ID(N'[dbo].[LetERPCatalogoResumen]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetERPCatalogoResumen] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetERPCatalogoResumen]
AS
BEGIN
    SET NOCOUNT ON;
    SELECT SUM(CASE WHEN Estado = 'APLICADO' THEN 1 ELSE 0 END) AS Aplicados, SUM(CASE WHEN Estado = 'ERROR' THEN 1 ELSE 0 END) AS Errores,
           SUM(CASE WHEN Estado = 'APLICADO' AND Informado = 0 THEN 1 ELSE 0 END) AS PorInformar FROM dbo.LetERP_Catalogo;
    SELECT TOP (20) CodigoErp, Estado, Mensaje, Actualizado FROM dbo.LetERP_Catalogo WHERE Estado = 'ERROR' ORDER BY Actualizado DESC;
END
GO
