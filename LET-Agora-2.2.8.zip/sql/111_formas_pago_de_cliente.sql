﻿-- 111_formas_pago_de_cliente.sql
-- dbo.ObtenerMetodoPagos (las formas de pago que carga la pantalla de cobro) incluye tambien las formas de pago OCULTAS que estan asignadas a un cliente
-- (dbo.LetClienteRestringido activo): una forma de pago oculta para todos solo la ve ese cliente. Misma definicion que 010_procedimientos.sql,
-- repetida para que una actualizacion desde el portal la aplique.
IF OBJECT_ID(N'[dbo].[ObtenerMetodoPagos]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[ObtenerMetodoPagos] AS RETURN 0')
GO
ALTER PROC [dbo].[ObtenerMetodoPagos]
AS
BEGIN
SELECT m.[Id]
      ,m.[Name]
      ,m.[GiveChange]
      ,m.[IncludeInBalance]
      ,m.[IncludeTipInBalance]
      ,m.[IsValidForSale]
      ,m.[IsValidForPurchase]
      ,m.[OpenCashDrawer]
      ,m.[RegisterTip]
      ,m.[AllowOverPaid]
      ,m.[AllowExtraInformation]
      -- El boton se ve como en Agora: su texto, su color (ARGB, 0xFFRRGGBB) y su imagen.
      ,ISNULL(NULLIF(p.StyleText, N''), m.[Name]) AS ButtonText
      ,ISNULL(p.StyleBackColor, m.[Color]) AS Color
      ,CAST(CASE WHEN img.Id IS NULL THEN 0 ELSE 1 END AS BIT) AS TieneImagen
      ,m.[ExtractTipFromCashdrawer]
      ,m.[Priority]
      ,m.[RequireCustomer]
      ,m.[MaxAllowedPayment]
      ,m.[IsValidForPhoneOrder]
      ,m.[IsRefundVoucher]
      ,m.[IsValidForRefund]
      ,m.[DeletionDate]
      ,m.[Rate]
      ,m.[PaymentId]
      ,m.[AgoraPaymentId]
      ,m.IsFractional
      -- Forma de pago que cubre el ITBIS de las ventas de regimen especial (no se muestra como boton).
      ,CAST(CASE WHEN r.Tipo = 'EX' THEN 1 ELSE 0 END AS BIT) AS EsExencion
      -- Forma de pago de delivery: los centros de venta de delivery donde se acepta ('' si no hay ninguno).
      -- NULL: se acepta en cualquier centro.
      ,CASE WHEN m.SoloDelivery = 1
            THEN ISNULL(STUFF((SELECT ',' + CAST(c.SaleCenterId AS VARCHAR(10)) FROM dbo.LetCentroVentaDelivery c
                               ORDER BY c.SaleCenterId FOR XML PATH('')), 1, 1, ''), '') END AS CentrosDelivery
  FROM [dbo].[LETMetodoPagos] m
  LEFT JOIN dbo.PaymentMethod p ON p.Id = m.AgoraPaymentId
  LEFT JOIN dbo.[Image] img ON img.Id = p.StyleImageId
  OUTER APPLY (SELECT TOP (1) x.Tipo FROM dbo.FacturaFormaPagoRelacion x WHERE x.IdFormaPago = m.AgoraPaymentId ORDER BY x.Id) r
  -- Solo las que se muestran (el instalador oculta las que no se usan o se borraron en Agora), la de exencion y las ocultas que estan asignadas a un cliente
  -- (Clientes y formas de pago): la pantalla de cobro solo se las muestra a ese cliente.
  WHERE (m.DeletionDate IS NULL OR r.Tipo = 'EX'
         OR EXISTS (SELECT 1 FROM dbo.LetClienteRestringido c WHERE c.Activo = 1 AND c.IdFormaPagoPermitida = m.AgoraPaymentId))
    AND p.DeletionDate IS NULL
  ORDER BY m.Priority, m.AgoraPaymentId
END
GO
