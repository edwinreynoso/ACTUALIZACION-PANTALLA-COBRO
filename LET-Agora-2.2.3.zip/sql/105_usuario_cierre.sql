﻿-- 105_usuario_cierre.sql
-- LetFacturaAgoraCabecera devuelve tambien UsuarioCierre: quien cerro (cobro) la cuenta, de dbo.Invoice.UserId. Usuario sigue siendo quien la abrio
-- (dbo.Ticket.OpenerUserId). El ticket imprime "Abrio" y "Cerro". Misma definicion que 010_procedimientos.sql, repetida para que una actualizacion
-- desde el portal la aplique. Sin variables del instalador.
IF OBJECT_ID(N'[dbo].[LetFacturaAgoraCabecera]') IS NULL EXEC (N'CREATE FUNCTION [dbo].[LetFacturaAgoraCabecera]() RETURNS TABLE AS RETURN SELECT 1 AS c')
GO
ALTER FUNCTION [dbo].[LetFacturaAgoraCabecera] (@Serie NVARCHAR(10), @Number INT)
RETURNS TABLE
AS
RETURN
    SELECT
        i.Serie,
        i.Number AS Numero,
        CONVERT(DECIMAL(12,2), t.Gross) AS BaseImponible,
        CONVERT(DECIMAL(12,2), ISNULL(imp.Itbis, 0)) AS Impuestos,
        CONVERT(DECIMAL(12,2), t.Net) AS TotalNeto,
        i.CreationDate AS Fecha,
        CONVERT(DECIMAL(12,2), ISNULL(imp.Propina, 0)) AS Propina,
        CASE WHEN ISNULL(imp.Propina, 0) <> 0 THEN ISNULL(cfg.MensajePropina, N'PROPINA LEGAL') ELSE N'' END AS MensajePropina,
        t.SaleCenterName AS Ubicacion,
        t.SaleLocationName AS Mesa,
        u.Name AS Usuario,
        i.Id AS IdInvoice,
        t.Id AS IdTicket,
        i.RelatedInvoiceId,
        -- La tasa del dolar de la tabla de tasas (LetTasaCambio); si nunca se registro una, la de siempre.
        COALESCE(dbo.LetTasaVigente(N'USD', GETDATE()),
                 (SELECT TOP (1) m.TasaDolar FROM dbo.MonitorParametros m WHERE m.IdPOS = i.PosId),
                 (SELECT TOP (1) m.TasaDolar FROM dbo.MonitorParametros m ORDER BY m.Id)) AS TasaUSD,
        CONVERT(DECIMAL(12,2), 0) AS MontoTotalUSD,
        CONVERT(DECIMAL(12,2), 0) AS Descuento,
        CONVERT(DECIMAL(12,2), 0) AS DescuentoPorcentaje,
        CONVERT(DECIMAL(12,2), 0) AS MontoTotalDescuento,
        i.PosId,
        -- Quien CERRO la cuenta (la factura la crea el usuario que cobra); Usuario es quien la ABRIO.
        uc.Name AS UsuarioCierre
    FROM dbo.Ticket t
    INNER JOIN dbo.InvoiceItem ii ON ii.TicketId = t.Id
    INNER JOIN dbo.Invoice i ON ii.InvoiceId = i.Id
    INNER JOIN dbo.[User] u ON t.OpenerUserId = u.Id
    LEFT JOIN dbo.[User] uc ON uc.Id = i.UserId
    OUTER APPLY (SELECT TOP (1) c.MensajePropina FROM dbo.LetConfiguracionFiscal c) cfg
    OUTER APPLY dbo.LetImpuestosTicket(t.Id) imp
    WHERE i.Serie = @Serie AND i.Number = @Number
GO
