﻿-- 106_nota_credito_comprador.sql
-- dbo.LetFEPendientes: una nota de credito sin comprador toma el RNC y la razon social de su factura original, porque e-Fiscal Cloud los exige cuando la
-- factura los llevaba (E31, E41, E44, E45...) y Agora no los guarda en la nota. Misma definicion que 005_efiscal.sql, repetida para que una
-- actualizacion desde el portal la aplique (005 usa variables del instalador).
IF OBJECT_ID(N'[dbo].[LetFEPendientes]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetFEPendientes] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetFEPendientes] (@Max INT = 10, @PosIds VARCHAR(200) = NULL)
AS
BEGIN
    SET NOCOUNT ON;

    -- Notas de credito que no se podran enviar nunca (factura original no emitida por e-Fiscal Cloud, no encontrada o rechazada):
    -- quedan en ERROR con el motivo, que se ve en el reporte, en el diagnostico y en la pantalla de la caja.
    UPDATE c SET Estado = 'ERROR', UltimoError = LEFT(r.Motivo, 1000), Actualizado = GETDATE()
    FROM dbo.LetFE_Cola c
    CROSS APPLY dbo.LetFEReferencia(c.Serie, c.Numero) r
    WHERE c.Documento = 'N' AND c.Estado = 'PENDIENTE' AND c.Encf IS NULL AND r.Fatal = 1
      AND (@PosIds IS NULL OR CHARINDEX(',' + CAST(c.PosId AS VARCHAR(10)) + ',', ',' + REPLACE(@PosIds, ' ', '') + ',') > 0);
    -- Las que solo esperan la aceptacion de su factura dejan escrito que esperan (antes esperaban en silencio).
    UPDATE c SET UltimoError = LEFT(r.Motivo, 1000)
    FROM dbo.LetFE_Cola c
    CROSS APPLY dbo.LetFEReferencia(c.Serie, c.Numero) r
    WHERE c.Documento = 'N' AND c.Estado = 'PENDIENTE' AND c.Encf IS NULL AND r.Lista = 0 AND r.Fatal = 0
      AND ISNULL(c.UltimoError, N'') <> r.Motivo
      AND (@PosIds IS NULL OR CHARINDEX(',' + CAST(c.PosId AS VARCHAR(10)) + ',', ',' + REPLACE(@PosIds, ' ', '') + ',') > 0);

    DECLARE @Tomadas TABLE (Id INT PRIMARY KEY);
    UPDATE q SET Estado = 'ENVIANDO', Intentos = Intentos + 1, Actualizado = GETDATE()
    OUTPUT inserted.Id INTO @Tomadas
    FROM dbo.LetFE_Cola q
    WHERE q.Id IN (
        SELECT TOP (@Max) c.Id FROM dbo.LetFE_Cola c WITH (UPDLOCK, READPAST, ROWLOCK)
        WHERE ((c.Estado = 'PENDIENTE' AND c.ProximoIntento <= GETDATE())
            OR (c.Estado = 'ENVIANDO' AND c.Actualizado < DATEADD(MINUTE, -2, GETDATE())))
          AND (@PosIds IS NULL OR CHARINDEX(',' + CAST(c.PosId AS VARCHAR(10)) + ',', ',' + REPLACE(@PosIds, ' ', '') + ',') > 0)
          AND (c.Documento = 'F' OR EXISTS (SELECT 1 FROM dbo.LetFEReferencia(c.Serie, c.Numero) r WHERE r.Lista = 1))
        ORDER BY c.Id);

    -- La nota queda con la referencia exacta que se le manda a e-Fiscal Cloud.
    UPDATE q SET ReferenciaEncf = r.Encf, ReferenciaFecha = r.Fecha
    FROM dbo.LetFE_Cola q
    INNER JOIN @Tomadas t ON t.Id = q.Id
    CROSS APPLY dbo.LetFEReferencia(q.Serie, q.Numero) r
    WHERE q.Documento = 'N';

    -- Agora guarda la nota de credito sin el comprador, pero e-Fiscal Cloud lo exige cuando la factura original lo llevaba (E31, E41, E44, E45...):
    -- la nota toma el RNC y la razon social de su factura original. Si la original no tenia RNC (consumo) la nota queda como esta.
    UPDATE q SET Json = JSON_MODIFY(q.Json, '$.buyer', JSON_QUERY((SELECT rncCedula = o.RNC, name = ISNULL(NULLIF(o.RazonSocial, N''), JSON_VALUE(q.Json, '$.buyer.name')) FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)))
    FROM dbo.LetFE_Cola q
    INNER JOIN @Tomadas t ON t.Id = q.Id
    CROSS APPLY dbo.LetFEReferencia(q.Serie, q.Numero) r
    CROSS APPLY (SELECT TOP (1) fc.RNC, fc.RazonSocial FROM dbo.FacturaComprobanteFiscal fc WHERE fc.NCF = r.Encf AND ISNULL(fc.RNC, '') <> '') o
    WHERE q.Documento = 'N' AND ISNULL(JSON_VALUE(q.Json, '$.buyer.rncCedula'), '') = '' AND JSON_VALUE(q.Json, '$.buyer.foreignId') IS NULL;

    SELECT q.Id, q.Serie, q.Numero, q.Documento, q.TipoEcf, q.PosTicketId, CONVERT(VARCHAR(36), q.ClientUuid) AS ClientUuid,
           q.Intentos, q.TotalEnviado, q.Json, ref.Encf AS ReferenciaEncf, ref.Fecha AS ReferenciaFecha, q.RncOmitido
    FROM dbo.LetFE_Cola q
    INNER JOIN @Tomadas t ON t.Id = q.Id
    OUTER APPLY (SELECT TOP (1) r.Encf, r.Fecha FROM dbo.LetFEReferencia(q.Serie, q.Numero) r WHERE q.Documento = 'N') ref
    ORDER BY q.Id;
END
GO
