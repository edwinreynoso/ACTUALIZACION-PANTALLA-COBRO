﻿-- 102_padron_indice.sql
-- El padron de la DGII (dbo.DGII_RNC, ~800 mil filas) viene de Agora SIN indice y con la columna RNC como varchar(max):
-- cada busqueda de un RNC recorria toda la tabla (varios segundos) y las que usan UPDLOCK/HOLDLOCK bloqueaban la caja.
-- Se pasa RNC a varchar(20) (solo si ningun valor es mas largo) y se crea un indice. No cambia ni pierde datos; es reversible
-- (ALTER COLUMN RNC varchar(max)). Agora lo sigue usando igual. Se puede ejecutar varias veces.
SET NOCOUNT ON;
IF OBJECT_ID(N'dbo.DGII_RNC', N'U') IS NOT NULL
BEGIN
    DECLARE @largo int = (SELECT max_length FROM sys.columns WHERE object_id = OBJECT_ID(N'dbo.DGII_RNC') AND name = N'RNC');
    IF @largo = -1 AND NOT EXISTS (SELECT 1 FROM dbo.DGII_RNC WHERE LEN(RNC) > 20)
    BEGIN
        ALTER TABLE dbo.DGII_RNC ALTER COLUMN RNC varchar(20) NULL;
        PRINT 'DGII_RNC.RNC ahora es varchar(20)';
    END
    SET @largo = (SELECT max_length FROM sys.columns WHERE object_id = OBJECT_ID(N'dbo.DGII_RNC') AND name = N'RNC');
    IF @largo <> -1 AND NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.DGII_RNC') AND name = N'IX_DGII_RNC_RNC')
    BEGIN
        CREATE NONCLUSTERED INDEX IX_DGII_RNC_RNC ON dbo.DGII_RNC (RNC);
        PRINT 'Indice IX_DGII_RNC_RNC creado en el padron de la DGII';
    END
END
