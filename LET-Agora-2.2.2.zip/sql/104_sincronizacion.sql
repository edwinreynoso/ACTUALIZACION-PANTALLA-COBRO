-- 104_sincronizacion.sql
-- dbo.LetSincronizar: vuelve a leer de Agora lo que el instalador precarga (formas de pago, impuestos y centros de venta de delivery) SIN pisar lo que ya se configuro.
--   @Aplicar = 0  solo dice que cambiaria (no escribe nada).        @Aplicar = 1  lo aplica.
-- Devuelve una fila por cambio: Tipo, Nombre, Cambio (Nueva, Nuevo, Oculta, Actualizada, Actualizado, Quitado) y Detalle.
-- Reglas (las mismas del instalador, sin los valores del formulario):
--   * Forma de pago nueva en Agora: se agrega su boton y se propone su codigo DGII por el nombre (se cambia luego en Formas de pago).
--   * Forma de pago ya existente: conserva su codigo DGII, si el boton esta visible, la tasa y si es de delivery; solo sigue a Agora en nombre y reglas de cobro.
--   * Forma de pago borrada en Agora: se oculta (no se borra).
--   * Impuesto nuevo en Agora: se agrega con la separacion propuesta (ITBIS + propina). Los existentes conservan lo definido salvo que cambie su tasa en Agora.
--   * Centro de venta de delivery que ya no existe en Agora: se quita de la lista. Los centros nuevos no son delivery hasta que se marquen.
-- No tiene variables del instalador: se puede aplicar desde una actualizacion o desde el portal.
SET NOCOUNT ON;
GO
IF OBJECT_ID(N'[dbo].[LetSincronizar]') IS NULL EXEC (N'CREATE PROCEDURE [dbo].[LetSincronizar] AS RETURN 0')
GO
ALTER PROCEDURE [dbo].[LetSincronizar] (@Aplicar BIT = 0)
AS
BEGIN
    SET NOCOUNT ON;
    CREATE TABLE #Cambios (Tipo NVARCHAR(30), Nombre NVARCHAR(150), Cambio NVARCHAR(20), Detalle NVARCHAR(250));

    ---------------------------------------------------------------- formas de pago
    DECLARE @Agora TABLE (Id INT PRIMARY KEY, Nombre NVARCHAR(120), Propuesto VARCHAR(2));
    IF OBJECT_ID(N'dbo.PaymentMethod', N'U') IS NOT NULL
        INSERT INTO @Agora (Id, Nombre, Propuesto)
        SELECT p.Id, p.Name,
               CASE
                   WHEN UPPER(p.Name) LIKE '%EXEN%' OR UPPER(p.Name) LIKE '%EXON%' THEN 'EX'
                   WHEN p.IsRefundVoucher = 1 OR UPPER(p.Name) LIKE '%NOTA%CREDITO%' OR UPPER(p.Name) LIKE '%DEVOLUCI%' THEN '07'
                   WHEN UPPER(p.Name) LIKE '%EFECTIVO%' OR UPPER(p.Name) LIKE '%CASH%' OR UPPER(p.Name) LIKE '%DOLAR%' OR UPPER(p.Name) LIKE '%EURO%' THEN '01'
                   WHEN UPPER(p.Name) LIKE '%CHEQUE%' OR UPPER(p.Name) LIKE '%TRAN%FER%' OR UPPER(p.Name) LIKE '%DEPOSITO%' OR UPPER(p.Name) LIKE '%DEPÓSITO%' THEN '02'
                   WHEN UPPER(p.Name) LIKE '%TARJETA%' OR UPPER(p.Name) LIKE '%VISA%' OR UPPER(p.Name) LIKE '%MASTER%' OR UPPER(p.Name) LIKE '%AMEX%'
                     OR UPPER(p.Name) LIKE '%DEBITO%' OR UPPER(p.Name) LIKE '%DÉBITO%' OR UPPER(p.Name) LIKE '%CARD%' THEN '03'
                   WHEN UPPER(p.Name) LIKE '%CREDITO%' OR UPPER(p.Name) LIKE '%CRÉDITO%' OR UPPER(p.Name) LIKE '%CUENTA%' THEN '04'
                   WHEN UPPER(p.Name) LIKE '%BONO%' OR UPPER(p.Name) LIKE '%CERTIFICADO%' OR UPPER(p.Name) LIKE '%REGALO%' OR UPPER(p.Name) LIKE '%GIFT%' THEN '05'
                   WHEN UPPER(p.Name) LIKE '%PERMUTA%' THEN '06'
                   ELSE '08'
               END
        FROM dbo.PaymentMethod p
        WHERE p.DeletionDate IS NULL;

    INSERT #Cambios (Tipo, Nombre, Cambio, Detalle)
    SELECT N'Forma de pago', a.Nombre, N'Nueva', N'Se agrega su boton. Codigo DGII propuesto: ' + a.Propuesto + N' (revise Formas de pago)'
    FROM @Agora a WHERE NOT EXISTS (SELECT 1 FROM dbo.LETMetodoPagos m WHERE m.AgoraPaymentId = a.Id);

    INSERT #Cambios (Tipo, Nombre, Cambio, Detalle)
    SELECT N'Forma de pago', m.Name, N'Oculta', N'Ya no existe en Agora: se oculta'
    FROM dbo.LETMetodoPagos m
    WHERE m.DeletionDate IS NULL AND m.AgoraPaymentId IS NOT NULL AND NOT EXISTS (SELECT 1 FROM @Agora a WHERE a.Id = m.AgoraPaymentId);

    INSERT #Cambios (Tipo, Nombre, Cambio, Detalle)
    SELECT N'Forma de pago', p.Name, N'Actualizada', N'Nombre o reglas de cobro distintos a Agora (cambio, cliente obligatorio, prioridad)'
    FROM dbo.LETMetodoPagos m
    JOIN dbo.PaymentMethod p ON p.Id = m.AgoraPaymentId
    JOIN @Agora a ON a.Id = p.Id
    WHERE EXISTS (SELECT m.Name, m.GiveChange, m.AllowOverPaid, m.RequireCustomer, m.Priority EXCEPT SELECT p.Name, p.GiveChange, p.AllowOverPaid, p.RequireCustomer, p.Priority);

    ---------------------------------------------------------------- impuestos
    DECLARE @Tipo VARCHAR(15) = 'RETAIL', @Propina DECIMAL(9,6) = 0;
    SELECT TOP (1) @Tipo = TipoNegocio, @Propina = TasaPropina FROM dbo.LetConfiguracionFiscal ORDER BY Id;
    DECLARE @Propuesta TABLE (VatId INT PRIMARY KEY, Nombre NVARCHAR(100), TasaAgora DECIMAL(9,6), TasaItbis DECIMAL(9,6), TasaPropina DECIMAL(9,6));
    IF OBJECT_ID(N'dbo.Vat', N'U') IS NOT NULL
    BEGIN
        INSERT INTO @Propuesta (VatId, Nombre, TasaAgora, TasaItbis, TasaPropina)
        SELECT v.Id, v.Name, v.VatRate,
               CASE WHEN p.Separa = 1 THEN v.VatRate - @Propina ELSE v.VatRate END,
               CASE WHEN p.Separa = 1 THEN @Propina ELSE 0 END
        FROM dbo.Vat v
        CROSS APPLY (SELECT CASE WHEN @Tipo = 'RESTAURANTE' AND @Propina > 0 AND v.VatRate >= @Propina
                                  AND v.VatRate - @Propina IN (0.18, 0.16, 0) THEN 1 ELSE 0 END AS Separa) p
        WHERE v.Enabled = 1 OR EXISTS (SELECT 1 FROM dbo.LetImpuestos i WHERE i.VatId = v.Id);

        INSERT #Cambios (Tipo, Nombre, Cambio, Detalle)
        SELECT N'Impuesto', ISNULL(o.Nombre, CAST(o.VatId AS NVARCHAR(10))), N'Nuevo',
               N'Se agrega: ITBIS ' + CAST(CAST(o.TasaItbis * 100 AS DECIMAL(5,2)) AS NVARCHAR(10)) + N'% + propina ' + CAST(CAST(o.TasaPropina * 100 AS DECIMAL(5,2)) AS NVARCHAR(10)) + N'%'
        FROM @Propuesta o WHERE NOT EXISTS (SELECT 1 FROM dbo.LetImpuestos i WHERE i.VatId = o.VatId);

        INSERT #Cambios (Tipo, Nombre, Cambio, Detalle)
        SELECT N'Impuesto', ISNULL(o.Nombre, CAST(o.VatId AS NVARCHAR(10))), N'Actualizado',
               N'Su tasa en Agora cambio de ' + CAST(CAST(d.TasaAgora * 100 AS DECIMAL(5,2)) AS NVARCHAR(10)) + N'% a ' + CAST(CAST(o.TasaAgora * 100 AS DECIMAL(5,2)) AS NVARCHAR(10)) + N'%: se vuelve a proponer la separacion'
        FROM @Propuesta o JOIN dbo.LetImpuestos d ON d.VatId = o.VatId WHERE d.TasaAgora <> o.TasaAgora;
    END

    ---------------------------------------------------------------- centros de venta de delivery
    IF OBJECT_ID(N'dbo.SaleCenter', N'U') IS NOT NULL AND OBJECT_ID(N'dbo.LetCentroVentaDelivery', N'U') IS NOT NULL
        INSERT #Cambios (Tipo, Nombre, Cambio, Detalle)
        SELECT N'Centro de venta', N'Centro ' + CAST(d.SaleCenterId AS NVARCHAR(10)), N'Quitado', N'Ya no existe en Agora: se quita de los centros de delivery'
        FROM dbo.LetCentroVentaDelivery d WHERE NOT EXISTS (SELECT 1 FROM dbo.SaleCenter s WHERE s.Id = d.SaleCenterId);

    ---------------------------------------------------------------- aplicar
    IF @Aplicar = 1
    BEGIN
        BEGIN TRANSACTION;
        BEGIN TRY
            -- Una relacion guardada con otro nombre era de otra forma de pago (Id reutilizado): se vuelve a proponer su codigo.
            UPDATE r SET Tipo = a.Propuesto
            FROM dbo.FacturaFormaPagoRelacion r JOIN @Agora a ON a.Id = r.IdFormaPago
            WHERE UPPER(LTRIM(RTRIM(ISNULL(r.Desrcipcion, N'')))) <> UPPER(LEFT(a.Nombre, 50)) AND r.Desrcipcion IS NOT NULL AND LTRIM(RTRIM(r.Desrcipcion)) <> N'';

            UPDATE r SET Desrcipcion = LEFT(a.Nombre, 50)
            FROM dbo.FacturaFormaPagoRelacion r JOIN @Agora a ON a.Id = r.IdFormaPago;

            INSERT INTO dbo.FacturaFormaPagoRelacion (IdFormaPago, Tipo, Desrcipcion)
            SELECT a.Id, a.Propuesto, LEFT(a.Nombre, 50) FROM @Agora a
            WHERE NOT EXISTS (SELECT 1 FROM dbo.FacturaFormaPagoRelacion r WHERE r.IdFormaPago = a.Id);

            INSERT INTO dbo.LETMetodoPagos (Name, GiveChange, IncludeInBalance, IncludeTipInBalance, IsValidForSale, IsValidForPurchase,
                OpenCashDrawer, RegisterTip, AllowOverPaid, AllowExtraInformation, ButtonText, Color, ExtractTipFromCashdrawer, Priority,
                RequireCustomer, MaxAllowedPayment, IsValidForPhoneOrder, IsRefundVoucher, IsValidForRefund, DeletionDate, Rate,
                PaymentId, AgoraPaymentId, CurrencyType, IsFractional)
            SELECT p.Name, p.GiveChange, p.IncludeInBalance, 0, p.IsValidForSale, p.IsValidForPurchase,
                   p.OpenCashDrawer, p.RegisterTip, p.AllowOverPaid, p.AllowExtraInformation, N'0xFF000000', N'0xFF000000', p.ExtractTipFromCashdrawer, p.Priority,
                   p.RequireCustomer, p.MaxAllowedPayment, 0, 0, 0, NULL, 1,
                   p.Id, p.Id, 1, 0
            FROM dbo.PaymentMethod p JOIN @Agora a ON a.Id = p.Id
            WHERE NOT EXISTS (SELECT 1 FROM dbo.LETMetodoPagos m WHERE m.AgoraPaymentId = p.Id);

            UPDATE m SET Name = p.Name, GiveChange = p.GiveChange, AllowOverPaid = p.AllowOverPaid, RequireCustomer = p.RequireCustomer, Priority = p.Priority
            FROM dbo.LETMetodoPagos m JOIN dbo.PaymentMethod p ON p.Id = m.AgoraPaymentId JOIN @Agora a ON a.Id = p.Id;

            UPDATE m SET DeletionDate = ISNULL(m.DeletionDate, GETDATE())
            FROM dbo.LETMetodoPagos m
            WHERE m.AgoraPaymentId IS NOT NULL AND NOT EXISTS (SELECT 1 FROM @Agora a WHERE a.Id = m.AgoraPaymentId);

            IF OBJECT_ID(N'dbo.Vat', N'U') IS NOT NULL
                MERGE dbo.LetImpuestos AS d
                USING @Propuesta AS o ON d.VatId = o.VatId
                WHEN MATCHED THEN
                    UPDATE SET Nombre      = o.Nombre,
                               TasaItbis   = CASE WHEN d.TasaAgora <> o.TasaAgora THEN o.TasaItbis ELSE d.TasaItbis END,
                               TasaPropina = CASE WHEN d.TasaAgora <> o.TasaAgora THEN o.TasaPropina ELSE d.TasaPropina END,
                               TasaAgora   = o.TasaAgora
                WHEN NOT MATCHED THEN
                    INSERT (VatId, Nombre, TasaAgora, TasaItbis, TasaPropina) VALUES (o.VatId, o.Nombre, o.TasaAgora, o.TasaItbis, o.TasaPropina);

            IF OBJECT_ID(N'dbo.SaleCenter', N'U') IS NOT NULL AND OBJECT_ID(N'dbo.LetCentroVentaDelivery', N'U') IS NOT NULL
                DELETE d FROM dbo.LetCentroVentaDelivery d WHERE NOT EXISTS (SELECT 1 FROM dbo.SaleCenter s WHERE s.Id = d.SaleCenterId);

            COMMIT TRANSACTION;
        END TRY
        BEGIN CATCH
            IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
            THROW;
        END CATCH
    END

    SELECT Tipo, Nombre, Cambio, Detalle FROM #Cambios ORDER BY Tipo, Cambio, Nombre;
END
GO
