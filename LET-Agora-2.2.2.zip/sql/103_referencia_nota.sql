﻿-- 103_referencia_nota.sql
-- dbo.LetFEReferencia: la factura original de una nota de credito se ubica por su serie y numero (los de dbo.Invoice), no solo por IdInvoice,
-- que puede repetirse en dbo.Factura (datos viejos o bases restauradas). Es la misma definicion que trae 005_efiscal.sql; se repite aqui para que
-- una actualizacion desde el portal (que no puede ejecutar 005, porque usa variables del instalador) la aplique.
IF OBJECT_ID(N'[dbo].[LetFEReferencia]') IS NULL EXEC (N'CREATE FUNCTION [dbo].[LetFEReferencia] () RETURNS TABLE AS RETURN SELECT 1 AS c')
GO
ALTER FUNCTION [dbo].[LetFEReferencia] (@Serie NVARCHAR(10), @Numero INT)
RETURNS TABLE
AS
RETURN
    SELECT TOP (1)
        o.Encf,
        o.Fecha,
        CONVERT(BIT, CASE WHEN o.Existe = 1 AND o.Encf LIKE 'E%' AND o.EstadoCola IN ('ACEPTADO', 'ACEPTADO_COND') THEN 1 ELSE 0 END) AS Lista,
        CONVERT(BIT, CASE WHEN o.Existe = 0 OR o.EstadoCola IS NULL OR o.EstadoCola IN ('RECHAZADO', 'ERROR', 'DESCARTADO') THEN 1 ELSE 0 END) AS Fatal,
        CASE
            WHEN o.Existe = 0 THEN N'No se encontro la factura original de esta devolucion en la integracion (se cerro fuera de esta caja o antes de instalar). Una nota de credito solo se puede emitir por e-Fiscal Cloud sobre una factura emitida por e-Fiscal Cloud.'
            WHEN o.EstadoCola IS NULL THEN N'La factura original (' + o.Documento + N', NCF ' + ISNULL(o.Encf, N'?') + N') no se emitio por e-Fiscal Cloud: la plataforma no la conoce y rechazaria la nota. Emita la nota por el proveedor con que se emitio la factura.'
            WHEN o.EstadoCola IN ('RECHAZADO', 'ERROR', 'DESCARTADO') THEN N'La factura original (' + o.Documento + N') esta en estado ' + o.EstadoCola + N': la nota de credito no se puede enviar. Corrija o anule primero la factura.'
            WHEN o.EstadoCola = 'DIFERIDO' THEN N'La factura original (' + o.Documento + N') es una operacion interna pendiente de fiscalizar: fiscalicela primero y la nota se envia sola'
            WHEN o.EstadoCola = 'REVISAR' THEN N'La factura original (' + o.Documento + N') esta retenida porque el RNC del comprador no es valido: corrijala en el reporte (puerto 9701) y la nota se envia sola'
            WHEN o.EstadoCola NOT IN ('ACEPTADO', 'ACEPTADO_COND') THEN N'Esperando que la DGII acepte la factura original (' + o.Documento + N', estado ' + o.EstadoCola + N')'
            WHEN o.Encf NOT LIKE 'E%' THEN N'Esperando el e-NCF de la factura original (' + o.Documento + N')'
            ELSE N''
        END AS Motivo
    FROM dbo.Factura nc
    OUTER APPLY (
        SELECT TOP (1) f.Serie, f.Numero, fc.NCF, q.Estado FROM dbo.Factura f
        INNER JOIN dbo.FacturaComprobanteFiscal fc ON fc.Serie = f.Serie AND fc.Numero = f.Numero
        LEFT JOIN dbo.LetFE_Cola q ON q.Serie = f.Serie AND q.Numero = f.Numero
        WHERE NOT (f.Serie = nc.Serie AND f.Numero = nc.Numero)
          AND (
                -- Lo normal: la factura original se ubica por su serie y numero (los de dbo.Invoice, donde apunta RelatedInvoiceId).
                -- Asi no se confunde si dbo.Factura trae IdInvoice repetidos (datos viejos, bases restauradas o de prueba).
                EXISTS (SELECT 1 FROM dbo.Invoice i WHERE i.Id = nc.RelatedInvoiceId AND i.Serie = f.Serie AND i.Number = f.Numero)
                -- Si dbo.Invoice no tiene esa factura se usa el IdInvoice como antes.
             OR (f.IdInvoice = nc.RelatedInvoiceId AND NOT EXISTS (SELECT 1 FROM dbo.Invoice i2 WHERE i2.Id = nc.RelatedInvoiceId))
              )
        ORDER BY fc.Id
    ) x
    CROSS APPLY (
        SELECT CASE WHEN x.Serie IS NULL THEN 0 ELSE 1 END AS Existe,
               x.NCF AS Encf,
               (SELECT CONVERT(CHAR(10), ff.Fecha, 105) FROM dbo.Factura ff WHERE ff.Serie = x.Serie AND ff.Numero = x.Numero) AS Fecha,
               x.Estado AS EstadoCola,
               x.Serie + N'-' + CAST(x.Numero AS NVARCHAR(12)) AS Documento
    ) o
    WHERE nc.Serie = @Serie AND nc.Numero = @Numero
GO
