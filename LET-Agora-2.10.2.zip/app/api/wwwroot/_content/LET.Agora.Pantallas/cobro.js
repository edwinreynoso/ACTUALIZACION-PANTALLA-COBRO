// Pantalla de cobro: lo minimo que tiene que pasar en el navegador.
// - El teclado numerico escribe sin ir al servidor.
// - Cada accion (forma de pago, quitar pago, comprobante) envia el formulario y el servidor
//   devuelve el panel ya dibujado; el calculo del cobro vive en C# (CalculoCobro).
// - Al cobrar: imprime en el servicio de impresion del equipo (si aplica) y le pide a Agora cerrar la ventana.
(() => {
    'use strict';

    const $ = id => document.getElementById(id);
    const ESPERA_IMPRESION = 20000;

    // ------------------------------------------------------------------ dialogos

    function abrir(dlg) {
        dlg.returnValue = '';
        if (!dlg.open) dlg.showModal();
    }

    document.addEventListener('click', e => {
        const boton = e.target.closest('[data-cerrar]');
        if (boton) boton.closest('dialog').close('');
    });

    function aviso(texto) {
        return new Promise(resolver => {
            const dlg = $('dlg-aviso');
            $('dlg-aviso-texto').textContent = texto;
            dlg.addEventListener('close', () => resolver(), { once: true });
            abrir(dlg);
            dlg.querySelector('[data-cerrar]').focus();
        });
    }

    // ------------------------------------------------------------------ teclados numericos

    // Solo digitos y un punto, con dos decimales como maximo (igual que CalculoCobro.LimpiarMonto).
    function limpiarMonto(texto) {
        let limpio = (texto || '').replace(/[^0-9.]/g, '');
        const punto = limpio.indexOf('.');
        if (punto >= 0) {
            limpio = limpio.slice(0, punto + 1) + limpio.slice(punto + 1).replace(/\./g, '').slice(0, 2);
        }
        return limpio.slice(0, 12);
    }

    const esCampoMonto = campo => campo.id === 'entrada' || campo.id === 'dlg-monto-valor';

    document.addEventListener('click', e => {
        const tecla = e.target.closest('[data-tecla]');
        if (!tecla || tecla.disabled) return;
        const campo = $(tecla.closest('[data-teclado-para]').dataset.tecladoPara);
        if (!campo || campo.disabled) return;

        const valor = tecla.dataset.tecla;
        let texto = valor === 'B' ? campo.value.slice(0, -1)
            : valor === 'C' ? ''
            : campo.value + valor;
        if (esCampoMonto(campo)) texto = limpiarMonto(texto);
        campo.value = texto.slice(0, campo.maxLength > 0 ? campo.maxLength : 60);
        if (campo.id === 'dlg-monto-valor') campo.dispatchEvent(new Event('input', { bubbles: true }));
        campo.focus();
    });

    document.addEventListener('input', e => {
        if (esCampoMonto(e.target)) {
            const limpio = limpiarMonto(e.target.value);
            if (limpio !== e.target.value) e.target.value = limpio;
        }
    });

    // ------------------------------------------------------------------ cerrar la ventana de Agora (precuenta)

    // Agora abre la pantalla en su visor: se le pide que la cierre y vuelva al ticket. Abierta fuera de Agora
    // (pruebas) no hay a quien pedirselo y la pagina se queda.
    const cerrarEnAgora = () => window.parent.postMessage({ type: 'agora:pos:close-window', applyFlow: 'none' }, '*');
    document.addEventListener('click', e => {
        if (e.target.closest('[data-cerrar-agora]')) cerrarEnAgora();
    });
    const cierreAutomatico = document.querySelector('[data-cerrar-agora-en]');
    if (cierreAutomatico) setTimeout(cerrarEnAgora, Number(cierreAutomatico.dataset.cerrarAgoraEn) || 1500);
    // Un solo envio: el boton de imprimir se desactiva al tocarlo (doble toque = dos precuentas).
    document.addEventListener('submit', e => {
        const boton = e.target.querySelector('[data-una-vez]');
        if (!boton) return;
        if (boton.disabled) { e.preventDefault(); return; }
        setTimeout(() => { boton.disabled = true; }, 0);
    });

    // ------------------------------------------------------------------ cobro

    const cobro = $('cobro');
    if (!cobro) return;

    const url = cobro.dataset.url;
    const form = $('cobro-form');
    const panel = $('panel');
    let ocupado = false;

    function enfocar() {
        const entrada = $('entrada');
        if (entrada && !entrada.disabled && !document.querySelector('dialog[open]')) {
            entrada.focus();
            entrada.setSelectionRange(entrada.value.length, entrada.value.length);
        }
    }

    function ponerEstado(texto) {
        const estado = $('estado');
        if (!estado) return;
        estado.innerHTML = '<span class="girando"></span><span></span>';
        estado.lastChild.textContent = texto;
    }

    function ocupar(si) {
        ocupado = si;
        cobro.classList.toggle('ocupado', si);
    }

    // Envia el formulario a una accion de la pagina y pone el panel que devuelve el servidor.
    async function enviar(accion, extra) {
        if (ocupado) return null;
        ocupar(true);
        try {
            const datos = new FormData(form);
            for (const [clave, valor] of Object.entries(extra || {})) datos.set(clave, valor);
            const respuesta = await fetch(`${url}?handler=${accion}`, { method: 'POST', body: datos });
            if (!respuesta.ok) throw new Error(`HTTP ${respuesta.status}`);
            panel.innerHTML = await respuesta.text();
            return respuesta;
        } catch (ex) {
            await aviso(`NO SE PUDO CONECTAR CON EL SERVIDOR ${ex.message}`);
            return null;
        } finally {
            ocupar(false);
        }
    }

    // Una accion y lo que el servidor pida despues: un aviso, el monto en moneda extranjera o el RNC.
    async function accion(nombre, extra) {
        const respuesta = await enviar(nombre, extra);
        if (!respuesta) return;

        const textoAviso = respuesta.headers.get('X-Aviso');
        if (textoAviso) await aviso(decodeURIComponent(textoAviso));

        const pideMonto = respuesta.headers.get('X-Pide-Monto');
        if (pideMonto) {
            const h = nombre => decodeURIComponent(respuesta.headers.get(nombre) || '');
            const info = {
                pesos: h('X-Pide-Monto-Pesos'), pesosNum: parseFloat(h('X-Pide-Monto-PesosNum')), moneda: h('X-Pide-Monto-Moneda'),
                simbolo: h('X-Pide-Monto-Simbolo'), tasa: parseFloat(h('X-Pide-Monto-Tasa')), equivalente: h('X-Pide-Monto-Eq')
            };
            const monto = await pedirMonto(h('X-Pide-Monto-Titulo'), info);
            if (monto) await accion('Monto', { metodoId: pideMonto, monto });
        }

        const pideRnc = respuesta.headers.get('X-Pide-Rnc');
        if (pideRnc) {
            const cliente = await pedirRnc();
            if (cliente) {
                ponerCliente(cliente);
                await accion('Comprobante', { elegidoId: pideRnc });
            }
        }

        enfocar();
    }

    function ponerCliente(cliente) {
        form.elements['Rnc'].value = cliente.rnc;
        form.elements['RazonSocial'].value = cliente.razon;
    }

    panel.addEventListener('click', async e => {
        const boton = e.target.closest('[data-accion]');
        if (!boton || boton.disabled || ocupado) return;

        switch (boton.dataset.accion) {
            case 'metodo':
                return accion('Metodo', { metodoId: boton.dataset.id });
            case 'quitar':
                return accion('Quitar', { indice: boton.dataset.indice });
            case 'comprobante':
                return accion('Comprobante', { elegidoId: boton.dataset.id });
            case 'cliente': {
                const cliente = await pedirRnc();
                if (cliente) {
                    ponerCliente(cliente);
                    await accion('Refrescar');
                }
                return;
            }
            case 'pasajero':
                if (await pedirPasajero()) await accion('Refrescar');
                return;
            case 'cobrar':
                return cobrar();
            case 'volver':
                // Sin cobrar (el ticket sigue abierto en Agora). Si se abrio con el ticket en pantalla de Agora
                // se cierra la ventana y se vuelve a ese ticket; la lista trae tambien los tickets en espera.
                if (cobro.dataset.boton === '1' && window.parent !== window) {
                    window.parent.postMessage({ type: 'agora:pos:close-window', applyFlow: 'none' }, '*');
                } else {
                    location.href = urlLista();
                }
                return;
        }
    });

    panel.addEventListener('keydown', e => {
        if (e.target.id !== 'entrada') return;
        if (e.key === 'Enter' || e.key === 'NumpadEnter') {
            e.preventDefault();
            panel.querySelector('.tecla-ent')?.click();
        } else if (e.key === 'Escape') {
            e.target.value = '';
        }
    });

    // ------------------------------------------------------------------ cobrar, imprimir y cerrar

    // sinPasajero: el cajero ya vio el recordatorio de duty free y decidio facturar sin todos los datos.
    async function cobrar(sinPasajero) {
        if (ocupado) return;
        ocupar(true);
        ponerEstado('PROCESANDO EL COBRO...');

        let resultado;
        try {
            const datos = new FormData(form);
            if (sinPasajero) datos.set('SinPasajero', 'true');
            const respuesta = await fetch(`${url}?handler=Procesar`, { method: 'POST', body: datos });
            if (!respuesta.ok) throw new Error(`HTTP ${respuesta.status}`);
            resultado = await respuesta.json();
        } catch (ex) {
            resultado = { ok: false, mensaje: `NO SE PUDO CONECTAR CON EL SERVIDOR ${ex.message}` };
        }

        // Tienda duty free: faltan datos del pasajero. Nada se envio a Agora todavia.
        if (!resultado.ok && resultado.pidePasajero) {
            ocupar(false);
            const decision = await recordatorioPasajero(resultado.mensaje);
            if (decision === 'facturar') return cobrar(true);
            if (decision === 'completar' && await pedirPasajero()) {
                await accion('Refrescar');
                return cobrar();
            }
            await accion('Refrescar');
            return;
        }

        if (!resultado.ok) {
            ocupar(false);
            await aviso(resultado.mensaje);
            // Si Agora ya recibio pagos el panel queda bloqueado; Cobrar sigue desde donde quedo.
            await accion('Refrescar');
            return;
        }

        // Imprimir antes de cerrar: al cerrar la ventana Agora destruye el iframe.
        if (resultado.imprimir && resultado.factura) {
            ponerEstado('IMPRIMIENDO...');
            const impresion = await imprimir(resultado.factura);
            if (!impresion.ok) await aviso(`LA FACTURA SE REGISTRO PERO NO SE PUDO IMPRIMIR ${impresion.mensaje}`);
        }

        cerrar();
    }

    // Lista de tickets sin perder la caja que mando el boton de Agora.
    function urlLista() {
        const caja = form.elements['pos_id']?.value;
        return '/cobro?lista=1' + (caja ? '&pos_id=' + encodeURIComponent(caja) : '');
    }

    function cerrar() {
        window.parent.postMessage({ type: 'agora:pos:close-window', applyFlow: 'afterClose' }, '*');
        // Abierta fuera de Agora (pruebas): si nadie cierra la ventana, vuelve a la lista.
        if (window.parent === window) {
            setTimeout(() => { location.href = urlLista(); }, 1500);
        }
    }

    // El servicio de impresion corre en el equipo del cajero; se conecta al abrir para ganar tiempo.
    const socketUrl = cobro.dataset.socket;
    let socket = null;

    function conectarImpresion() {
        return new Promise((resolver, rechazar) => {
            if (socket && socket.readyState === WebSocket.OPEN) return resolver(socket);
            try {
                socket = new WebSocket(`ws://${socketUrl}/servicioimpresion`);
            } catch (ex) {
                return rechazar(ex);
            }
            const espera = setTimeout(() => {
                rechazar(new Error('EL SERVICIO DE IMPRESION NO RESPONDIO A TIEMPO'));
                try { socket.close(); } catch { /* ya cerrado */ }
            }, ESPERA_IMPRESION);
            socket.onopen = () => { clearTimeout(espera); resolver(socket); };
            socket.onerror = () => { clearTimeout(espera); rechazar(new Error('EL SERVICIO DE IMPRESION NO ESTA DISPONIBLE')); };
        });
    }

    async function imprimir(factura) {
        try {
            const s = await conectarImpresion();
            const respuesta = await new Promise((resolver, rechazar) => {
                const espera = setTimeout(() => rechazar(new Error('EL SERVICIO DE IMPRESION NO RESPONDIO A TIEMPO')), ESPERA_IMPRESION);
                s.onmessage = e => {
                    clearTimeout(espera);
                    try { resolver(JSON.parse(e.data)); } catch (ex) { rechazar(ex); }
                };
                s.onclose = () => { clearTimeout(espera); rechazar(new Error('EL SERVICIO DE IMPRESION CERRO LA CONEXION')); };
                s.send(JSON.stringify(factura));
            });
            const exito = respuesta.Exito ?? respuesta.exito;
            return exito ? { ok: true } : { ok: false, mensaje: respuesta.Mensaje ?? respuesta.mensaje ?? '' };
        } catch (ex) {
            return { ok: false, mensaje: ex.message };
        }
    }

    if (socketUrl) conectarImpresion().catch(() => { /* se reintenta al imprimir */ });

    // ------------------------------------------------------------------ monto en moneda extranjera

    const dos = n => n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

    // Explica el cobro en moneda extranjera: pendiente en pesos (resaltado), que escriba cuanto entrega en esa moneda y la conversion,
    // que se va actualizando mientras escribe.
    function explicarMonto(info) {
        const pesos = $('dlg-monto-pesos'), pide = $('dlg-monto-pide'), conv = $('dlg-monto-conv');
        if (!info || !(info.tasa > 0)) { pesos.hidden = pide.hidden = conv.hidden = true; return; }
        $('dlg-monto-pesos-valor').textContent = 'RD$ ' + info.pesos;
        pide.textContent = 'Escriba cuántos ' + info.moneda + ' entrega el cliente';
        pesos.hidden = pide.hidden = conv.hidden = false;
        const actualizar = () => {
            const escrito = parseFloat(($('dlg-monto-valor').value || '').replace(',', '.'));
            if (!(escrito > 0)) {
                conv.textContent = 'Para cubrir los RD$ ' + info.pesos + ' se necesitan ' + info.simbolo + ' ' + info.equivalente + ' (RD$ ' + info.pesos + ' ÷ tasa ' + info.tasa + ').';
                return;
            }
            const entregado = Math.round(escrito * info.tasa * 100) / 100;
            const resto = Math.round((info.pesosNum - entregado) * 100) / 100;
            conv.textContent = info.simbolo + ' ' + dos(escrito) + ' × tasa ' + info.tasa + ' = RD$ ' + dos(entregado) + (resto > 0
                ? '. Quedan RD$ ' + dos(resto) + ' pendientes.'
                : resto < 0 ? '. Sobran RD$ ' + dos(-resto) + ' (cambio).' : '. Cubre el pendiente exacto.');
        };
        $('dlg-monto-valor').oninput = actualizar;
        $('dlg-monto').actualizarConversion = actualizar;
        actualizar();
    }

    function pedirMonto(titulo, info) {
        return new Promise(resolver => {
            const dlg = $('dlg-monto');
            const campo = $('dlg-monto-valor');
            $('dlg-monto-titulo').textContent = titulo;
            campo.value = '';
            explicarMonto(info);
            dlg.addEventListener('close', () => resolver(dlg.returnValue === 'ok' ? campo.value : null), { once: true });
            abrir(dlg);
            campo.focus();
        });
    }

    function aceptarMonto() {
        if ($('dlg-monto-valor').value) $('dlg-monto').close('ok');
    }

    $('dlg-monto-aceptar').addEventListener('click', aceptarMonto);
    $('dlg-monto-valor').addEventListener('keydown', e => {
        if (e.key === 'Enter' || e.key === 'NumpadEnter') { e.preventDefault(); aceptarMonto(); }
    });

    // ------------------------------------------------------------------ pasajero (tienda duty free)

    const camposPasajero = [
        ['pasajero-nombre', 'PasajeroNombre'],
        ['pasajero-pasaporte', 'PasajeroPasaporte'],
        ['pasajero-nacionalidad', 'PasajeroNacionalidad'],
        ['pasajero-vuelo', 'PasajeroVuelo']
    ];

    // Abre el dialogo con lo que ya se escribio; al aceptar lo deja en el formulario. Devuelve si se acepto.
    function pedirPasajero() {
        return new Promise(resolver => {
            const dlg = $('dlg-pasajero');
            for (const [id, nombre] of camposPasajero) $(id).value = form.elements[nombre]?.value || '';
            dlg.addEventListener('close', () => {
                const ok = dlg.returnValue === 'ok';
                if (ok) {
                    for (const [id, nombre] of camposPasajero) {
                        if (form.elements[nombre]) form.elements[nombre].value = $(id).value.trim().toUpperCase();
                    }
                }
                resolver(ok);
            }, { once: true });
            abrir(dlg);
            // El primer campo vacio, para seguir donde se quedo.
            (camposPasajero.map(([id]) => $(id)).find(c => !c.value) || $('pasajero-nombre')).focus();
        });
    }

    $('pasajero-aceptar')?.addEventListener('click', () => $('dlg-pasajero').close('ok'));
    // Enter pasa al siguiente campo; en el ultimo acepta.
    $('dlg-pasajero')?.addEventListener('keydown', e => {
        if (e.key !== 'Enter' && e.key !== 'NumpadEnter') return;
        const indice = camposPasajero.findIndex(([id]) => id === e.target.id);
        if (indice < 0) return;
        e.preventDefault();
        if (indice < camposPasajero.length - 1) $(camposPasajero[indice + 1][0]).focus();
        else $('dlg-pasajero').close('ok');
    });

    // Recordatorio al cobrar sin todos los datos: 'completar', 'facturar' o '' (cerro el dialogo).
    function recordatorioPasajero(texto) {
        return new Promise(resolver => {
            const dlg = $('dlg-sin-pasajero');
            $('dlg-sin-pasajero-texto').textContent = texto;
            dlg.addEventListener('close', () => resolver(dlg.returnValue), { once: true });
            abrir(dlg);
            $('sin-pasajero-completar').focus();
        });
    }

    $('sin-pasajero-completar')?.addEventListener('click', () => $('dlg-sin-pasajero').close('completar'));
    $('sin-pasajero-facturar')?.addEventListener('click', () => $('dlg-sin-pasajero').close('facturar'));

    // ------------------------------------------------------------------ cliente del comprobante (RNC)

    const dlgRnc = $('dlg-rnc');
    const resultados = $('rnc-resultados');
    let rncSeleccion = null;
    let rncUltimaBusqueda = '';

    function pedirRnc() {
        return new Promise(resolver => {
            rncSeleccion = null;
            rncUltimaBusqueda = '';
            $('rnc-texto').value = '';
            resultados.innerHTML = '';
            $('rnc-seleccionar').disabled = true;
            $('rnc-buscar').hidden = false;
            $('rnc-nuevo').hidden = true;
            dlgRnc.addEventListener('close', () => resolver(dlgRnc.returnValue === 'ok' ? rncSeleccion : null), { once: true });
            abrir(dlgRnc);
            $('rnc-texto').focus();
        });
    }

    function aceptarRnc(cliente) {
        if (!cliente) return;
        rncSeleccion = cliente;
        dlgRnc.close('ok');
    }

    async function buscarRnc() {
        const texto = $('rnc-texto').value.trim();
        rncSeleccion = null;
        $('rnc-seleccionar').disabled = true;
        resultados.innerHTML = '<div class="cargando"><span class="girando"></span></div>';
        try {
            const respuesta = await fetch(`${url}?handler=Rnc&texto=${encodeURIComponent(texto)}`);
            if (!respuesta.ok) throw new Error(`HTTP ${respuesta.status}`);
            resultados.innerHTML = await respuesta.text();
        } catch (ex) {
            resultados.innerHTML = '<div class="alerta alerta-error"></div>';
            resultados.firstChild.textContent = `NO SE PUDO CONECTAR CON EL SERVIDOR ${ex.message}`;
        }
        rncUltimaBusqueda = texto;
        const encontrados = resultados.querySelectorAll('.resultado');
        // Un solo resultado: queda seleccionado para aceptar con Enter o "Seleccionar".
        if (encontrados.length === 1) marcarRnc(encontrados[0]);
    }

    function marcarRnc(elemento) {
        resultados.querySelectorAll('.resultado.seleccionado').forEach(r => r.classList.remove('seleccionado'));
        elemento.classList.add('seleccionado');
        rncSeleccion = { rnc: elemento.dataset.rnc, razon: elemento.dataset.razon };
        $('rnc-seleccionar').disabled = false;

        resultados.querySelector('.rnc-estado')?.remove();
        if (elemento.dataset.estado) {
            const alerta = document.createElement('div');
            alerta.className = 'alerta alerta-aviso rnc-estado';
            alerta.textContent = `Este RNC figura como ${elemento.dataset.estado} en la DGII.`;
            resultados.appendChild(alerta);
        }
    }

    $('rnc-boton-buscar').addEventListener('click', buscarRnc);
    $('rnc-seleccionar').addEventListener('click', () => aceptarRnc(rncSeleccion));
    $('rnc-texto').addEventListener('keydown', e => {
        if (e.key !== 'Enter' && e.key !== 'NumpadEnter') return;
        e.preventDefault();
        // Enter con un resultado ya seleccionado lo confirma; si no, busca.
        if (rncSeleccion && $('rnc-texto').value.trim() === rncUltimaBusqueda) aceptarRnc(rncSeleccion);
        else buscarRnc();
    });
    resultados.addEventListener('click', e => {
        const elemento = e.target.closest('.resultado');
        if (elemento) marcarRnc(elemento);
    });
    resultados.addEventListener('dblclick', e => {
        const elemento = e.target.closest('.resultado');
        if (elemento) { marcarRnc(elemento); aceptarRnc(rncSeleccion); }
    });

    $('rnc-abrir-nuevo').addEventListener('click', () => {
        // Se aprovecha lo que el usuario ya escribio en la busqueda.
        const texto = $('rnc-texto').value.trim();
        const esNumero = /^\d+$/.test(texto);
        $('nuevo-rnc').value = esNumero ? texto : '';
        $('nuevo-razon').value = esNumero ? '' : texto.toUpperCase();
        $('nuevo-nombre').value = $('nuevo-direccion').value = $('nuevo-telefono').value = '';
        $('nuevo-mensaje').hidden = true;
        $('rnc-buscar').hidden = true;
        $('rnc-nuevo').hidden = false;
        (esNumero ? $('nuevo-razon') : $('nuevo-rnc')).focus();
    });

    $('rnc-volver').addEventListener('click', () => {
        $('rnc-nuevo').hidden = true;
        $('rnc-buscar').hidden = false;
        $('rnc-texto').focus();
    });

    $('rnc-guardar').addEventListener('click', async () => {
        const boton = $('rnc-guardar');
        const mensaje = $('nuevo-mensaje');
        boton.disabled = true;
        mensaje.hidden = true;
        try {
            const datos = new FormData();
            datos.set('nuevoRnc', $('nuevo-rnc').value);
            datos.set('nuevaRazon', $('nuevo-razon').value);
            datos.set('nuevoNombre', $('nuevo-nombre').value);
            datos.set('nuevaDireccion', $('nuevo-direccion').value);
            datos.set('nuevoTelefono', $('nuevo-telefono').value);
            const respuesta = await fetch(`${url}?handler=RegistrarRnc`, { method: 'POST', body: datos });
            if (!respuesta.ok) throw new Error(`HTTP ${respuesta.status}`);
            const r = await respuesta.json();
            if (r.ok) {
                aceptarRnc({ rnc: r.rnc, razon: r.razon });
                return;
            }
            mensaje.textContent = r.mensaje;
        } catch (ex) {
            mensaje.textContent = `NO SE PUDO CONECTAR CON EL SERVIDOR ${ex.message}`;
        } finally {
            boton.disabled = false;
        }
        mensaje.hidden = false;
    });

    // ------------------------------------------------------------------ al abrir

    (async () => {
        const avisos = JSON.parse(cobro.dataset.avisos || '[]');
        for (const texto of avisos) await aviso(texto);
        enfocar();
    })();
})();
